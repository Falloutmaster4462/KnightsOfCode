/* ══════════════════════════════════════════════
   MATIES-OS — Curriculum Graph Data & Logic
   ══════════════════════════════════════════════ */
const GRAPH_NODES=[
  /* ── YEAR 1 ── */
  {id:'CS114',label:'CS 114',name:'Intro to Computer Science 1',year:1,color:'#61223b',credits:16,sem:'S1',desc:'Foundations of programming using Python: variables, control flow, functions, basic I/O. Introduction to computational thinking and algorithmic problem decomposition.'},
  {id:'CS144',label:'CS 144',name:'Intro to Computer Science 2',year:1,color:'#61223b',credits:16,sem:'S2',desc:'Object-oriented programming in Java: classes, inheritance, polymorphism. Recursion, introductory data structures (arrays, linked lists). Software development practices.'},
  {id:'WIS114',label:'WIS 114',name:'Mathematics 114',year:1,color:'#61223b',credits:16,sem:'S1',desc:'Differential calculus, limits, continuity, sequences. Linear algebra: matrices, determinants, eigenvalues. Introduction to mathematical proof.'},
  {id:'WIS144',label:'WIS 144',name:'Mathematics 144',year:1,color:'#61223b',credits:16,sem:'S2',desc:'Integral calculus, differential equations. Discrete mathematics: logic, sets, relations, functions, combinatorics, graph theory basics. Mathematical induction.'},
  {id:'FIS114',label:'FIS 114',name:'Physics 114',year:1,color:'#61223b',credits:16,sem:'S1',desc:'Classical mechanics, kinematics, dynamics. Electromagnetism fundamentals. Waves and optics. Lab component. Provides physical intuition for hardware and circuits.'},
  {id:'FIS144',label:'FIS 144',name:'Physics 144',year:1,color:'#61223b',credits:16,sem:'S2',desc:'Thermodynamics, statistical physics, quantum mechanics introduction. Electric circuits, semiconductor fundamentals. Bridges physics to digital electronics.'},
  {id:'STAT144',label:'STAT 144',name:'Intro to Statistics',year:1,color:'#61223b',credits:12,sem:'S2',desc:'Descriptive statistics, probability theory, random variables, common distributions (normal, binomial, Poisson). Introduction to statistical inference and data visualisation.'},
  {id:'CS124',label:'CS 124',name:'Digital Systems',year:1,color:'#61223b',credits:12,sem:'S1',desc:'Boolean algebra, logic gates, combinational and sequential circuits. Number systems (binary, hex, BCD). Flip-flops, registers, counters. Introduction to hardware description.'},
  /* ── YEAR 2 ── */
  {id:'CS214',label:'CS 214',name:'Data Structures & Algorithms',year:2,color:'#a07a30',credits:16,sem:'S1',desc:'Abstract data types: stacks, queues, heaps, trees, hash tables, graphs. Sorting algorithms (merge, quick, heap). Algorithm analysis: Big-O, recurrence relations. Graph traversals: BFS, DFS, Dijkstra, Kruskal.'},
  {id:'CS224',label:'CS 224',name:'Theoretical Computer Science',year:2,color:'#a07a30',credits:16,sem:'S1',desc:'Formal languages, regular expressions, finite automata (DFA/NFA). Context-free grammars, pushdown automata. Introduction to Turing machines. Chomsky hierarchy.'},
  {id:'CS244',label:'CS 244',name:'Computer Architecture & OS',year:2,color:'#a07a30',credits:16,sem:'S2',desc:'ISA design, RISC vs CISC, assembly language (x86/ARM). Memory hierarchy, caching, virtual memory. Operating system concepts: processes, scheduling, IPC, file systems, device drivers.'},
  {id:'CS254',label:'CS 254',name:'Software Construction',year:2,color:'#a07a30',credits:16,sem:'S2',desc:'Software engineering practices: version control (Git), testing methodologies (unit, integration), documentation, code reviews. Design patterns: creational, structural, behavioural. UML modelling.'},
  {id:'WIS214',label:'WIS 214',name:'Mathematics 214',year:2,color:'#a07a30',credits:16,sem:'S1',desc:'Abstract algebra: groups, rings, fields, homomorphisms. Number theory: modular arithmetic, GCD, primality. Foundations for cryptography and error-correcting codes.'},
  {id:'WIS244',label:'WIS 244',name:'Numerical Methods',year:2,color:'#a07a30',credits:16,sem:'S2',desc:'Numerical integration, ODE solvers, root-finding algorithms (Newton-Raphson, bisection), interpolation, least-squares fitting. Implemented in Python/MATLAB. Floating-point arithmetic and error analysis.'},
  {id:'STAT244',label:'STAT 244',name:'Mathematical Statistics',year:2,color:'#a07a30',credits:16,sem:'S2',desc:'Estimation theory (MLE, Bayesian), hypothesis testing, confidence intervals. Linear regression, ANOVA. Multivariate distributions. Statistical computing with R.'},
  {id:'CS234',label:'CS 234',name:'Computer Graphics Fundamentals',year:2,color:'#a07a30',credits:12,sem:'S2',desc:'2D/3D transformations, homogeneous coordinates, rasterisation, ray casting. OpenGL/Vulkan introduction, shaders, texture mapping. Covers foundations for graphics and vision tracks.',track:['graphics']},
  /* ── YEAR 3 ── */
  {id:'CS313',label:'CS 313',name:'Computer Networks',year:3,color:'#1a6040',credits:16,sem:'S1',desc:'OSI and TCP/IP models, routing protocols (OSPF, BGP), IP addressing (IPv4/IPv6), DNS, HTTP/2. Socket programming in C/Python. Network performance analysis and Wireshark labs.',track:['security','systems']},
  {id:'CS314',label:'CS 314',name:'Concurrent & Parallel Programming',year:3,color:'#1a6040',credits:16,sem:'S1',desc:'POSIX threads, mutex, semaphores, monitors, lock-free data structures. Parallel patterns: map-reduce, pipeline, work-stealing. OpenMP and MPI for HPC. Deadlock detection and prevention.',track:['systems']},
  {id:'CS315',label:'CS 315',name:'Machine Learning',year:3,color:'#1a6040',credits:16,sem:'S1',desc:'Supervised learning: linear/logistic regression, SVMs, decision trees, random forests. Unsupervised: k-means, PCA, autoencoders. Feed-forward neural networks. Model evaluation: cross-validation, bias-variance tradeoff. Scikit-learn and PyTorch labs.',track:['ai','data']},
  {id:'CS323',label:'CS 323',name:'Programming Language Concepts',year:3,color:'#1a6040',credits:16,sem:'S1',desc:'Language paradigms: imperative, functional, logic. Type systems, type inference, polymorphism. Operational and denotational semantics. Lambda calculus. Haskell and Prolog practicals.',track:['theory']},
  {id:'CS343',label:'CS 343',name:'Databases & Information Systems',year:3,color:'#1a6040',credits:16,sem:'S1',desc:'Relational model, ER diagrams, normalisation (1NF–BCNF). SQL (advanced queries, views, transactions, indexing). NoSQL: MongoDB, Redis. Web APIs (REST/GraphQL). Query optimisation.',track:['data']},
  {id:'CS344',label:'CS 344',name:'Software Engineering',year:3,color:'#1a6040',credits:16,sem:'S2',desc:'Agile methodologies (Scrum, Kanban), SDLC models. Requirements engineering, use cases, domain modelling. Software architecture patterns (MVC, hexagonal, event-driven). CI/CD, containerisation, code quality metrics.',track:['honours']},
  {id:'CS345',label:'CS 345',name:'Computability & Formal Languages',year:3,color:'#1a6040',credits:16,sem:'S2',desc:'Turing machines, Church-Turing thesis, halting problem, undecidability. Complexity classes: P, NP, NP-complete, PSPACE. Reductions, Cook-Levin theorem. Approximation algorithms overview.',track:['theory','honours']},
  {id:'CS353',label:'CS 353',name:'Computer Security Fundamentals',year:3,color:'#1a6040',credits:16,sem:'S2',desc:'Threat modelling, vulnerability analysis, exploitation basics (buffer overflow, SQL injection, XSS). Defensive programming, secure coding practices. Penetration testing methodology. Compliance and risk frameworks (ISO 27001).',track:['security']},
  {id:'CS354',label:'CS 354',name:'Computer Vision & Image Processing',year:3,color:'#1a6040',credits:16,sem:'S2',desc:'Image formation, filtering (Gaussian, Sobel), feature detection (SIFT, ORB), homography and stereo vision. CNNs for classification and detection (YOLO, ResNet). SLAM introduction. OpenCV and PyTorch labs.',track:['ai','graphics']},
  {id:'CS363',label:'CS 363',name:'Human-Computer Interaction',year:3,color:'#1a6040',credits:12,sem:'S2',desc:'User-centred design, usability heuristics, prototyping (wireframes, Figma). Cognitive models, Fitts Law, GOMS. Accessibility (WCAG 2.2), inclusive design. User studies and statistical analysis of results.'},
  {id:'CS373',label:'CS 373',name:'Embedded Systems',year:3,color:'#1a6040',credits:12,sem:'S1',desc:'Microcontroller architecture (ARM Cortex-M), real-time operating systems (FreeRTOS), interrupt handling, DMA. Sensor interfaces: I2C, SPI, UART, CAN. Energy-efficient design and IoT protocols (MQTT, CoAP).',track:['systems']},
  /* ── YEAR 4 (HONOURS) ── */
  {id:'CS411',label:'CS 411',name:'Advanced Algorithms',year:4,color:'#1a3a70',credits:20,sem:'S1',desc:'Network flows (Ford-Fulkerson, push-relabel), linear programming, dynamic programming (advanced), string algorithms (Aho-Corasick, suffix arrays). Approximation algorithms, randomised algorithms, competitive programming techniques.',track:['honours','ai','security','theory']},
  {id:'CS413',label:'CS 413',name:'Research Methodology',year:4,color:'#1a3a70',credits:10,sem:'S1',desc:'Scientific writing (LaTeX), systematic literature reviews, research ethics. Experimental design, statistical analysis of results, peer review process. Research proposal writing and oral presentation skills.',track:['honours']},
  {id:'CS415',label:'CS 415',name:'Deep Learning',year:4,color:'#1a3a70',credits:20,sem:'S1',desc:'Convolutional architectures (ResNet, EfficientNet), sequence models (LSTM, GRU, Transformers), attention mechanisms. Training techniques: batch normalisation, dropout, learning rate scheduling. Distributed training on GPU clusters. PyTorch advanced.',track:['ai','honours']},
  {id:'CS416',label:'CS 416',name:'Network Security & Forensics',year:4,color:'#1a3a70',credits:20,sem:'S1',desc:'Advanced penetration testing, malware analysis, reverse engineering. Digital forensics: disk, memory, network artefacts. Intrusion detection systems, SIEM. CTF (Capture the Flag) practicals. Incident response planning.',track:['security','honours']},
  {id:'CS421',label:'CS 421',name:'Natural Language Processing',year:4,color:'#1a3a70',credits:20,sem:'S2',desc:'Linguistic foundations, tokenisation, POS tagging, NER, dependency parsing. Word2Vec, BERT, GPT architectures. Sequence-to-sequence models, attention, transformers. African languages NLP, code-switching. HuggingFace practicals.',track:['ai','honours']},
  {id:'CS422',label:'CS 422',name:'Reinforcement Learning',year:4,color:'#1a3a70',credits:20,sem:'S2',desc:'MDPs, Bellman equations, dynamic programming. Model-free methods: Q-learning, SARSA. Policy gradient methods: REINFORCE, PPO, A3C. Multi-agent RL, inverse RL. Gymnasium/MuJoCo practicals.',track:['ai','honours']},
  {id:'CS431',label:'CS 431',name:'High-Performance Computing',year:4,color:'#1a3a70',credits:20,sem:'S1',desc:'Parallel architectures: multi-core, GPU (CUDA), FPGAs. Performance profiling, roofline model, cache optimisation. MPI advanced patterns, collective communication. Access to CHPC Lengau supercomputer cluster.',track:['systems','honours']},
  {id:'CS441',label:'CS 441',name:'Advanced Software Engineering',year:4,color:'#1a3a70',credits:20,sem:'S2',desc:'Distributed systems architecture, CAP theorem, consensus protocols (Raft, Paxos). Microservices, service meshes (Istio), API gateways. Kubernetes, Helm, observability (Prometheus, Grafana). Software reliability engineering.',track:['systems','honours']},
  {id:'CS490',label:'CS 490',name:'Honours Research Project',year:4,color:'#1a3a70',credits:40,sem:'Ann',desc:'Original 40-credit research project supervised by a faculty member. Includes literature review, methodology design, implementation, evaluation, and dissertation. Presented at the Annual CS Research Symposium.',track:['honours']},
  /* ── YEAR 5 (POSTGRAD / MSc) ── */
  {id:'CS448',label:'CS 448',name:'Advanced Machine Learning',year:5,color:'#420f27',credits:20,sem:'S1',desc:'Generative models (GANs, VAEs, diffusion models), Bayesian deep learning, neural architecture search, meta-learning, few-shot learning. Cutting-edge research papers. Students present papers in seminar format.',track:['ai']},
  {id:'CS449',label:'CS 449',name:'Bioinformatics Algorithms',year:5,color:'#420f27',credits:20,sem:'S1',desc:'Sequence alignment (Smith-Waterman, BLAST), hidden Markov models for gene prediction, phylogenetic reconstruction (maximum likelihood, Bayesian). Genome assembly (de Bruijn graphs), variant calling pipelines. H3Africa data access.',track:['bio']},
  {id:'CS450',label:'CS 450',name:'Applied Cryptography',year:5,color:'#420f27',credits:20,sem:'S2',desc:'Public-key infrastructure (RSA, ECC, Diffie-Hellman), post-quantum cryptography (CRYSTALS-Kyber, Dilithium), zero-knowledge proofs, secure multi-party computation. Protocol design and formal security proofs. Blockchain security.',track:['security']},
  {id:'CS451',label:'CS 451',name:'Formal Verification',year:5,color:'#420f27',credits:20,sem:'S2',desc:'Isabelle/HOL interactive theorem proving, Coq introduction. Temporal logic (LTL, CTL), model checking (SPIN, NuSMV). Program verification with Hoare logic, separation logic. Smart contract and hardware verification case studies.',track:['theory']},
  {id:'CS452',label:'CS 452',name:'Cloud & Distributed Systems',year:5,color:'#420f27',credits:20,sem:'S2',desc:'Distributed storage (Dynamo, Cassandra, Spanner), stream processing (Kafka, Flink), serverless computing, edge computing. Byzantine fault tolerance, CRDTs. Cloud provider architectures (AWS, GCP, Azure). Research project component.',track:['systems']},
  {id:'CS453',label:'CS 453',name:'Advanced Computer Vision',year:5,color:'#420f27',credits:20,sem:'S1',desc:'3D reconstruction (NeRF, Gaussian splatting), video understanding, multi-modal models (CLIP, DALL-E). Scene understanding, autonomous driving perception. Real-time systems on edge hardware (Jetson). Research seminar format.',track:['graphics','ai']},
  {id:'CS460',label:'CS 460',name:'MSc Research Project',year:5,color:'#420f27',credits:90,sem:'Ann',desc:'Substantial original research contribution leading to a publishable MSc dissertation. Full-time research supervised by a faculty member, co-supervised by external collaborator. Culminates in public defence (viva voce).',track:['honours','masters']},
  /* ── YEAR 6 (MSc COURSEWORK) ── */
  {id:'CS501',label:'CS 501',name:'Advanced Research Topics',year:6,color:'#6b2fa0',credits:20,sem:'S1',desc:'Intensive reading group covering frontier research across CS subfields. Students present and critique top-venue papers (NeurIPS, ICML, IEEE S&P, SOSP, STOC). Develops research taste and scholarly communication skills.',track:['masters']},
  {id:'CS502',label:'CS 502',name:'MSc Thesis Proposal',year:6,color:'#6b2fa0',credits:20,sem:'S1',desc:'Guided preparation of a full MSc research proposal. Includes literature survey, problem statement, methodology, timeline, and ethical clearance. Oral defence before supervisory panel. Required before thesis registration.',track:['masters']},
  {id:'CS510',label:'CS 510',name:'Advanced AI Systems',year:6,color:'#6b2fa0',credits:20,sem:'S2',desc:'Large language models, foundation models, alignment and RLHF, agent architectures, multi-modal systems. Covers OpenAI, DeepMind, and Anthropic research. Students replicate and extend published results.',track:['masters','ai']},
  {id:'CS511',label:'CS 511',name:'Advanced Security Research',year:6,color:'#6b2fa0',credits:20,sem:'S2',desc:'State-of-the-art in post-quantum cryptography, zero-knowledge systems, hardware security (SGX, TrustZone), side-channel attacks. Students complete a research mini-project and CCS/IEEE S&P submission workshop.',track:['masters','security']},
  {id:'CS512',label:'CS 512',name:'Advanced Distributed Systems',year:6,color:'#6b2fa0',credits:20,sem:'S2',desc:'Consistency models, transactional memory, coordination-free databases, geo-distributed systems. CRDT deep dive, verified distributed protocols. Students build a mini distributed system with formal correctness argument.',track:['masters','systems']},
  {id:'CS560',label:'CS 560',name:'MSc Dissertation',year:6,color:'#6b2fa0',credits:120,sem:'Ann',desc:'The central MSc research product. An original, significant contribution to knowledge in the chosen subfield, written up as a dissertation and defended orally. Supervised by a faculty member, with external examiner assessment.',track:['masters']},
  /* ── YEAR 7 (PhD) ── */
  {id:'CS601',label:'CS 601',name:'PhD Research Seminar',year:7,color:'#1a0a2e',credits:0,sem:'Ann',desc:'Weekly seminar series for PhD students. Each student presents their research annually to the full department. Invited external speakers from top universities and industry research labs. Mandatory attendance throughout PhD.',track:['phd']},
  {id:'CS602',label:'CS 602',name:'PhD Proposal & Candidacy',year:7,color:'#1a0a2e',credits:0,sem:'S1',desc:'Formal PhD proposal defence before a candidacy committee. Includes problem motivation, related work mastery, proposed methodology, preliminary results, and a two-year work plan. Passing confirms PhD candidacy status.',track:['phd']},
  {id:'CS610',label:'CS 610',name:'PhD Research in AI',year:7,color:'#1a0a2e',credits:0,sem:'Ann',desc:'Independent doctoral research in AI/ML targeting NeurIPS, ICML, ICLR, or Nature Machine Intelligence. Includes lab meetings, paper reviews, and collaboration with international partners.',track:['phd','ai']},
  {id:'CS611',label:'CS 611',name:'PhD Research in Security',year:7,color:'#1a0a2e',credits:0,sem:'Ann',desc:'Doctoral research in cybersecurity and cryptography targeting IEEE S&P, ACM CCS, USENIX Security, or NDSS. Includes responsible disclosure ethics and industry collaboration with CCS.',track:['phd','security']},
  {id:'CS612',label:'CS 612',name:'PhD Research in Systems',year:7,color:'#1a0a2e',credits:0,sem:'Ann',desc:'Doctoral research in HPC and distributed systems with access to CHPC Lengau supercomputer. Targets OSDI, SOSP, EuroSys, or SC. May include hardware/software co-design.',track:['phd','systems']},
  {id:'CS690',label:'CS 690',name:'PhD Thesis',year:7,color:'#1a0a2e',credits:360,sem:'Ann',desc:'An original and substantial contribution to CS knowledge. Examined by two external examiners and defended in a public viva voce. NRF registration required. Expected duration: 3–4 years full-time.',track:['phd']},
];

const GRAPH_LINKS=[
  /* Y1→Y1 */
  {source:'WIS114',target:'WIS144'},
  {source:'FIS114',target:'FIS144'},
  /* Y1→Y2 */
  {source:'CS114',target:'CS144'},{source:'CS114',target:'CS214'},
  {source:'CS144',target:'CS214'},{source:'CS144',target:'CS244'},
  {source:'CS124',target:'CS244'},{source:'CS124',target:'CS234'},
  {source:'WIS114',target:'WIS214'},{source:'WIS114',target:'WIS244'},
  {source:'WIS144',target:'WIS214'},{source:'WIS144',target:'STAT244'},
  {source:'FIS114',target:'WIS244'},{source:'FIS144',target:'CS244'},
  {source:'STAT144',target:'STAT244'},{source:'CS114',target:'CS224'},
  {source:'WIS144',target:'CS224'},{source:'CS144',target:'CS254'},
  /* Y2→Y3 */
  {source:'CS214',target:'CS313'},{source:'CS244',target:'CS313'},
  {source:'CS214',target:'CS314'},{source:'CS244',target:'CS314'},
  {source:'CS214',target:'CS315'},{source:'STAT244',target:'CS315'},
  {source:'WIS114',target:'CS315'},{source:'CS214',target:'CS323'},
  {source:'CS224',target:'CS323'},{source:'CS214',target:'CS343'},
  {source:'CS254',target:'CS343'},{source:'CS214',target:'CS344'},
  {source:'CS254',target:'CS344'},{source:'CS214',target:'CS345'},
  {source:'CS224',target:'CS345'},{source:'WIS214',target:'CS345'},
  {source:'CS313',target:'CS353'},{source:'CS244',target:'CS353'},
  {source:'CS214',target:'CS354'},{source:'CS234',target:'CS354'},
  {source:'CS254',target:'CS363'},{source:'CS244',target:'CS373'},
  {source:'CS214',target:'CS373'},
  /* Y3→Y4 */
  {source:'CS214',target:'CS411'},{source:'CS345',target:'CS411'},
  {source:'CS323',target:'CS411'},{source:'CS344',target:'CS413'},
  {source:'CS315',target:'CS415'},{source:'CS354',target:'CS415'},
  {source:'CS353',target:'CS416'},{source:'CS313',target:'CS416'},
  {source:'CS315',target:'CS421'},{source:'CS354',target:'CS421'},
  {source:'CS315',target:'CS422'},{source:'CS411',target:'CS422'},
  {source:'CS314',target:'CS431'},{source:'CS244',target:'CS431'},
  {source:'CS344',target:'CS441'},{source:'CS313',target:'CS441'},
  {source:'CS314',target:'CS441'},
  /* Y4→Y4 (project) */
  {source:'CS411',target:'CS490'},{source:'CS413',target:'CS490'},
  {source:'CS421',target:'CS490'},{source:'CS441',target:'CS490'},
  {source:'CS415',target:'CS490'},{source:'CS416',target:'CS490'},
  /* Y4→Y5 */
  {source:'CS415',target:'CS448'},{source:'CS422',target:'CS448'},
  {source:'CS315',target:'CS449'},{source:'CS411',target:'CS449'},
  {source:'CS353',target:'CS450'},{source:'WIS214',target:'CS450'},
  {source:'CS345',target:'CS451'},{source:'CS323',target:'CS451'},
  {source:'CS314',target:'CS452'},{source:'CS441',target:'CS452'},
  {source:'CS415',target:'CS453'},{source:'CS354',target:'CS453'},
  {source:'CS490',target:'CS460'},
  /* Y5→Y6 (MSc) */
  {source:'CS460',target:'CS501'},{source:'CS460',target:'CS502'},
  {source:'CS448',target:'CS510'},{source:'CS460',target:'CS510'},
  {source:'CS450',target:'CS511'},{source:'CS460',target:'CS511'},
  {source:'CS452',target:'CS512'},{source:'CS460',target:'CS512'},
  {source:'CS501',target:'CS560'},{source:'CS502',target:'CS560'},
  {source:'CS510',target:'CS560'},{source:'CS511',target:'CS560'},
  {source:'CS512',target:'CS560'},
  /* Y6→Y7 (PhD) */
  {source:'CS560',target:'CS601'},{source:'CS560',target:'CS602'},
  {source:'CS602',target:'CS610'},{source:'CS510',target:'CS610'},
  {source:'CS602',target:'CS611'},{source:'CS511',target:'CS611'},
  {source:'CS602',target:'CS612'},{source:'CS512',target:'CS612'},
  {source:'CS601',target:'CS690'},{source:'CS602',target:'CS690'},
  {source:'CS610',target:'CS690'},{source:'CS611',target:'CS690'},
  {source:'CS612',target:'CS690'},
];

const TRACK_COLORS={ai:'#82CCAE',security:'#dc4405',systems:'#64c8d4',honours:'#caa258',data:'#b48ae0',bio:'#7ecdc8',theory:'#f5a623',graphics:'#ff7eb3',masters:'#6b2fa0',phd:'#c0392b',all:null};
let _graphSim=null, _graphHighlight='all';

function initCurrGraph(){
  const container=document.getElementById('curr-graph-container');
  if(!container||typeof d3==='undefined')return;
  const svg=d3.select('#curr-graph-svg');
  const W=container.clientWidth, H=container.clientHeight||720;
  svg.attr('width',W).attr('height',H);
  svg.selectAll('*').remove();

  const isDark=!document.getElementById('MATIES-root').classList.contains('light-mode');
  const textColor=isDark?'#caa258':'#61223b';
  const linkColor=isDark?'rgba(202,162,88,0.2)':'rgba(97,34,59,0.2)';

  const g=svg.append('g');

  // Zoom — store reference for external zoom controls
  const zoomBehavior=d3.zoom().scaleExtent([0.2,4]).on('zoom',e=>g.attr('transform',e.transform));
  svg.call(zoomBehavior);
  window._graphZoomRef=zoomBehavior;
  window._graphSvg=svg;
  window._graphG=g;

  // Double-click background to reset zoom
  svg.on('dblclick.zoom',null).on('dblclick',()=>{
    svg.transition().duration(500).call(zoomBehavior.transform,d3.zoomIdentity.translate(W/2,H/2).scale(0.85));
  });

  // Single-click on background to deselect
  svg.on('click',(e)=>{
    if(e.target.tagName==='svg'||e.target===g.node()){
      // Reset all node/link visuals
      d3.selectAll('.graph-node circle')
        .attr('opacity',1)
        .attr('stroke',isDark?'rgba(202,162,88,0.45)':'rgba(202,162,88,0.65)')
        .attr('stroke-width',1.5)
        .style('filter',isDark?'drop-shadow(0 0 6px rgba(97,34,59,0.7))':'none');
      d3.selectAll('#curr-graph-svg line')
        .attr('opacity',0.55)
        .attr('stroke',d=>getLinkColor(d))
        .attr('stroke-width',1.4)
        .attr('marker-end',null);
      // Reset sidebar panel to idle state
      const codeEl=document.getElementById('gmd-code');
      const nameEl=document.getElementById('gmd-name');
      const detailBtn=document.getElementById('gmd-detail-btn');
      if(codeEl){codeEl.textContent='CS 000';codeEl.style.opacity='0.4';}
      if(nameEl){nameEl.textContent='Click any node to inspect';nameEl.style.opacity='0.5';nameEl.style.fontSize='0.9rem';}
      const crEl=document.getElementById('gmd-cr');
      const yrEl=document.getElementById('gmd-yr');
      if(crEl){crEl.textContent='—';crEl.style.opacity='0.4';}
      if(yrEl){yrEl.textContent='—';yrEl.style.opacity='0.4';}
      const prereqEl=document.getElementById('gmd-prereqs');
      const unlockEl=document.getElementById('gmd-unlocks');
      const trackEl=document.getElementById('gmd-tracks');
      if(prereqEl) prereqEl.innerHTML='<span style="font-family:\'Share Tech Mono\',monospace;font-size:0.98rem;color:var(--su-gold-d);opacity:0.6;">None</span>';
      if(unlockEl) unlockEl.innerHTML='<span style="font-family:\'Share Tech Mono\',monospace;font-size:0.98rem;color:var(--su-gold-d);opacity:0.6;">None</span>';
      if(trackEl) trackEl.innerHTML='<span style="font-family:\'Share Tech Mono\',monospace;font-size:0.98rem;color:var(--su-gold-d);opacity:0.6;">General</span>';
      if(detailBtn){detailBtn.style.opacity='0.4';detailBtn.style.pointerEvents='none';detailBtn.onclick=null;}
      document.getElementById('graph-module-detail')?.classList.remove('visible');
      // Clear selected module and reset sidebar bars + filter buttons to "All"
      window._selectedGraphModule=null;
      // Reset track filter buttons → All
      document.querySelectorAll('.graph-filter-btn:not(.graph-year-btn)').forEach(b=>b.classList.remove('active'));
      const allTrackBtn=document.querySelector('.graph-filter-btn:not(.graph-year-btn)');
      if(allTrackBtn) allTrackBtn.classList.add('active');
      // Reset year filter buttons → All
      document.querySelectorAll('.graph-year-btn').forEach(b=>b.classList.remove('active'));
      const allYearBtn=document.querySelector('.graph-year-btn');
      if(allYearBtn) allYearBtn.classList.add('active');
      // Update sidebar counts back to full-graph state (real counts, 0 shown as 0)
      if(typeof window._updateGraphSidebar==='function') window._updateGraphSidebar('all',0);
    }
  });

  // Arrow marker
  const defs=svg.append('defs');
  defs.append('marker')
    .attr('id','arrow').attr('viewBox','0 -4 8 8').attr('refX',28).attr('refY',0)
    .attr('markerWidth',6).attr('markerHeight',6).attr('orient','auto')
    .append('path').attr('d','M0,-4L8,0L0,4').attr('fill',isDark?'rgba(202,162,88,0.45)':'rgba(97,34,59,0.35)');
  defs.append('marker')
    .attr('id','arrow-active').attr('viewBox','0 -4 8 8').attr('refX',28).attr('refY',0)
    .attr('markerWidth',7).attr('markerHeight',7).attr('orient','auto')
    .append('path').attr('d','M0,-4L8,0L0,4').attr('fill','#caa258');

  // Compute downstream depth for node sizing
  const depthMap={};
  GRAPH_NODES.forEach(n=>{depthMap[n.id]=GRAPH_LINKS.filter(l=>(l.source===n.id||l.source?.id===n.id)).length;});
  const maxDepth=Math.max(...Object.values(depthMap));

  // Compute link colors: use track color if both endpoints share a track
  function getLinkColor(link){
    const srcId=link.source?.id||link.source;
    const tgtId=link.target?.id||link.target;
    const src=GRAPH_NODES.find(n=>n.id===srcId);
    const tgt=GRAPH_NODES.find(n=>n.id===tgtId);
    if(!src||!tgt) return linkColor;
    const sharedTracks=(src.track||[]).filter(t=>(tgt.track||[]).includes(t));
    if(sharedTracks.length){
      const c=TRACK_COLORS[sharedTracks[0]];
      if(c) return c+'55';
    }
    return linkColor;
  }

  const link=g.append('g').selectAll('line').data(GRAPH_LINKS).join('line')
    .attr('stroke',d=>getLinkColor(d)).attr('stroke-width',1.4)
    .attr('id',d=>`link-${d.source}-${d.target}`)
    .attr('opacity',0.55);

  const node=g.append('g').selectAll('g').data(GRAPH_NODES).join('g')
    .attr('class','graph-node').attr('cursor','pointer')
    .call(d3.drag().on('start',dragStart).on('drag',dragged).on('end',dragEnd));

  node.append('circle')
    .attr('r',d=>{
      const depth=depthMap[d.id]||0;
      const base=d.year>=7?35:d.year===6?33:d.year>=5?29:d.year===4?27:22;
      return base + Math.min(8, depth*1.7);
    })
    .attr('fill',d=>d.color)
    .attr('stroke',isDark?'rgba(202,162,88,0.45)':'rgba(202,162,88,0.65)')
    .attr('stroke-width',1.5)
    .style('filter',isDark?'drop-shadow(0 0 6px rgba(97,34,59,0.7))':'none');

  node.append('text')
    .attr('text-anchor','middle').attr('dy','0.35em')
    .attr('font-family','Share Tech Mono, monospace').attr('font-size','7.5px')
    .attr('fill',isDark?'#dfc07e':'#faf7f2').attr('pointer-events','none')
    .text(d=>d.id);

  // Tooltip
  const tooltip=document.getElementById('graph-node-tooltip');
  node.on('mouseover',(e,d)=>{
    if(!tooltip) return;
    tooltip.style.display='block';
    tooltip.style.left=(e.offsetX+15)+'px'; tooltip.style.top=(e.offsetY-10)+'px';
    tooltip.innerHTML=`<strong style="color:#caa258;font-size:0.8rem;">${d.id}</strong><br><span style="color:#fff;">${d.name||d.label}</span><br><span style="color:rgba(202,162,88,0.6);font-size:0.81rem;">${d.credits}cr · ${d.sem} · Y${d.year}</span>${d.track?`<br><span style="color:#82CCAE;font-size:0.98rem;">${d.track.join(', ')}</span>`:''}`;
  }).on('mousemove',(e)=>{
    if(!tooltip) return;
    tooltip.style.left=(e.offsetX+15)+'px'; tooltip.style.top=(e.offsetY-10)+'px';
  }).on('mouseout',()=>{if(tooltip) tooltip.style.display='none';});

  node.on('dblclick',(e,d)=>{
    e.stopPropagation();
    // Double-click: focus module in sidebar then immediately open full details modal
    if(window.graphFocusModule) window.graphFocusModule(d.id);
    const detailBtn=document.getElementById('gmd-detail-btn');
    if(detailBtn && detailBtn.onclick) detailBtn.onclick();
  });

  node.on('click',(e,d)=>{
    e.stopPropagation();
    // Update sidebar detail panel
    if(window.graphFocusModule) { window.graphFocusModule(d.id); return; }
    const YEAR_NAMES={1:'Year 1 — Foundation',2:'Year 2 — Core',3:'Year 3 — Specialisation',4:'Year 4 — Honours',5:'Postgraduate (MSc/PhD)',6:'MSc Coursework',7:'PhD Research'};
    const prereqIds=GRAPH_LINKS.filter(l=>(l.target===d.id||l.target?.id===d.id)).map(l=>l.source?.id||l.source);
    const prereqNodes=GRAPH_NODES.filter(n=>prereqIds.includes(n.id));
    const postreqIds=GRAPH_LINKS.filter(l=>(l.source===d.id||l.source?.id===d.id)).map(l=>l.target?.id||l.target);
    const postreqNodes=GRAPH_NODES.filter(n=>postreqIds.includes(n.id));
    const prereqHtml=prereqNodes.length
      ? prereqNodes.map(n=>`<span style="display:inline-flex;align-items:center;gap:4px;background:rgba(97,34,59,0.18);border:1px solid rgba(202,162,88,0.25);color:var(--su-gold);font-family:'Share Tech Mono',monospace;font-size:0.90rem;padding:4px 10px;border-radius:3px;margin:2px;">${n.label} — ${n.name}</span>`).join('')
      : `<span style="color:rgba(202,162,88,0.5);font-family:'Share Tech Mono',monospace;font-size:0.98rem;">None — Entry-level module</span>`;
    const postreqHtml=postreqNodes.length
      ? postreqNodes.map(n=>`<span style="display:inline-flex;align-items:center;gap:4px;background:rgba(26,96,64,0.15);border:1px solid rgba(130,204,174,0.25);color:var(--su-green);font-family:'Share Tech Mono',monospace;font-size:0.90rem;padding:4px 10px;border-radius:3px;margin:2px;">${n.label}</span>`).join('')
      : `<span style="color:rgba(202,162,88,0.4);font-family:'Share Tech Mono',monospace;font-size:0.98rem;">Terminal module</span>`;
    document.getElementById('m-modal-content').innerHTML=`
      <div style="margin-bottom:20px;">
        <div style="font-family:'Share Tech Mono',monospace;font-size:0.7rem;color:var(--su-gold-d);margin-bottom:4px;">${YEAR_NAMES[d.year]||'Module Details'} · ${d.sem==='Ann'?'Full Year':d.sem==='S1'?'Semester 1':'Semester 2'}</div>
        <h2 style="font-family:'Raleway',sans-serif;font-weight:800;color:var(--su-maroon);font-size:1.5rem;margin:0;">${d.id} — ${d.name}</h2>
      </div>
      <p class="m-p" style="margin-bottom:16px;">${d.desc}</p>
      <div class="m-grid3" style="margin:16px 0;">
        <div class="m-stat" style="padding:14px;"><span class="num" style="font-size:1.6rem;">${d.credits}</span><div class="lbl">Credits</div></div>
        <div class="m-stat" style="padding:14px;"><span class="num" style="font-size:1.4rem;">${YEAR_NAMES[d.year]?.split('—')[0]||'Y'+d.year}</span><div class="lbl">Year Level</div></div>
        <div class="m-stat" style="padding:14px;"><span class="num" style="font-size:1.4rem;">${d.sem==='Ann'?'Full Yr':d.sem}</span><div class="lbl">Semester</div></div>
      </div>
      ${d.track?`<div style="margin-top:8px;">${d.track.map(t=>`<span class="m-tag gold">${t.toUpperCase()} TRACK</span>`).join('')}</div>`:''}
      <div class="m-infobox" style="margin-top:14px;">
        <div style="font-family:'Share Tech Mono',monospace;font-size:0.81rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">⬆ Prerequisites (must pass first)</div>
        <div style="display:flex;flex-wrap:wrap;gap:4px;">${prereqHtml}</div>
      </div>
      <div class="m-infobox" style="margin-top:10px;border-left-color:var(--su-green);">
        <div style="font-family:'Share Tech Mono',monospace;font-size:0.81rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">⬇ Unlocks (modules this opens)</div>
        <div style="display:flex;flex-wrap:wrap;gap:4px;">${postreqHtml}</div>
      </div>
    `;
    document.getElementById('m-modal').classList.add('open');
    triggerGlitch();
  });

  if(_graphSim) _graphSim.stop();
  _graphSim=d3.forceSimulation(GRAPH_NODES)
    .force('link',d3.forceLink(GRAPH_LINKS).id(d=>d.id).distance(65).strength(0.5))
    .force('charge',d3.forceManyBody().strength(-240))
    .force('center',d3.forceCenter(W/2,H/2))
    .force('y',d3.forceY(d=>(d.year-1)*(H/7.0)+60).strength(0.55))
    .force('x',d3.forceX(W/2).strength(0.04))
    .force('collision',d3.forceCollide(37))
    .on('tick',()=>{
      link.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y)
          .attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);
      node.attr('transform',d=>`translate(${d.x},${d.y})`);
    });

  function dragStart(e,d){if(!e.active)_graphSim.alphaTarget(0.3).restart();d.fx=d.x;d.fy=d.y;}
  function dragged(e,d){d.fx=e.x;d.fy=e.y;}
  function dragEnd(e,d){if(!e.active)_graphSim.alphaTarget(0);d.fx=null;d.fy=null;}

  // Apply initial highlight
  graphHighlight(_graphHighlight,null,true);
}
window.initCurrGraph=initCurrGraph;

window.graphHighlight=function(track,btnEl,silent){
  _graphHighlight=track;
  window._selectedGraphModule=null; // Clear single-module mode
  // Reset year highlight when a track is selected
  _graphYearHighlight=0;
  document.querySelectorAll('.graph-year-btn').forEach(b=>b.classList.remove('active'));
  const allYearBtn=document.querySelector('.graph-year-btn[onclick*="0,"]');
  if(allYearBtn) allYearBtn.classList.add('active');
  // Update track buttons
  document.querySelectorAll('.graph-filter-btn:not(.graph-year-btn)').forEach(b=>b.classList.remove('active'));
  if(btnEl) btnEl.classList.add('active');
  else {
    const btns=document.querySelectorAll('.graph-filter-btn:not(.graph-year-btn)');
    btns.forEach(b=>{ if(b.getAttribute('onclick')&&b.getAttribute('onclick').includes(`'${track}'`)) b.classList.add('active'); });
  }
  if(!silent) triggerGlitch();
  if(typeof d3==='undefined'||!document.getElementById('curr-graph-svg')) return;

  const isDark=!document.getElementById('MATIES-root').classList.contains('light-mode');
  const nodes=d3.selectAll('.graph-node circle');
  const links=d3.selectAll('#curr-graph-svg line');

  if(track==='all'){
    nodes.attr('opacity',1).attr('stroke','rgba(202,162,88,0.5)').attr('stroke-width',1.5).style('filter',isDark?'drop-shadow(0 0 6px rgba(97,34,59,0.6))':'none');
    links.attr('opacity',0.5).attr('stroke',isDark?'rgba(202,162,88,0.2)':'rgba(97,34,59,0.2)').attr('marker-end',null);
    if(typeof window._updateGraphSidebar==='function') window._updateGraphSidebar('all',0);
    return;
  }
  const trackNodes=GRAPH_NODES.filter(n=>n.track&&n.track.includes(track)).map(n=>n.id);
  // Also add prerequisites
  const prereqs=new Set(trackNodes);
  let changed=true;
  while(changed){changed=false;GRAPH_LINKS.forEach(l=>{if(prereqs.has(l.target)&&!prereqs.has(l.source)){prereqs.add(l.source);changed=true;}});}
  const trackColor=TRACK_COLORS[track]||'#caa258';

  nodes.each(function(d){
    const inTrack=prereqs.has(d.id);
    d3.select(this).attr('opacity',inTrack?1:0.18)
      .attr('stroke',inTrack?trackColor:'rgba(202,162,88,0.2)')
      .attr('stroke-width',inTrack?3:1)
      .style('filter',inTrack?`drop-shadow(0 0 10px ${trackColor})`:'none');
  });
  links.each(function(d){
    const inTrack=prereqs.has(d.source.id||d.source)&&prereqs.has(d.target.id||d.target);
    d3.select(this).attr('opacity',inTrack?0.9:0.06).attr('stroke',inTrack?trackColor:'rgba(202,162,88,0.1)').attr('stroke-width',inTrack?2:1).attr('marker-end',null);
  });
  if(typeof window._updateGraphSidebar==='function') window._updateGraphSidebar(track,0);
};

const YEAR_COLORS={1:'#61223b',2:'#a07a30',3:'#1a6040',4:'#1a3a70',5:'#420f27',6:'#6b2fa0',7:'#1a0a2e'};
let _graphYearHighlight=0;

window.graphHighlightYear=function(year,btnEl){
  _graphYearHighlight=year;
  window._selectedGraphModule=null; // Clear single-module mode
  // Update year buttons
  document.querySelectorAll('.graph-year-btn').forEach(b=>b.classList.remove('active'));
  if(btnEl) btnEl.classList.add('active');

  // Clear track highlight when switching to year mode (unless showing all)
  if(year!==0){
    // Deactivate track filter buttons
    document.querySelectorAll('.graph-filter-btn:not(.graph-year-btn)').forEach(b=>b.classList.remove('active'));
    _graphHighlight='all';
  }

  triggerGlitch();
  if(typeof d3==='undefined'||!document.getElementById('curr-graph-svg')) return;

  const isDark=!document.getElementById('MATIES-root').classList.contains('light-mode');
  const nodes=d3.selectAll('.graph-node circle');
  const links=d3.selectAll('#curr-graph-svg line');

  if(year===0){
    // Show all — restore default appearance
    nodes.attr('opacity',1).attr('stroke','rgba(202,162,88,0.5)').attr('stroke-width',1.5).style('filter',isDark?'drop-shadow(0 0 6px rgba(97,34,59,0.6))':'none');
    links.attr('opacity',0.5).attr('stroke',isDark?'rgba(202,162,88,0.2)':'rgba(97,34,59,0.2)').attr('stroke-width',1.2).attr('marker-end',null);
    if(typeof window._updateGraphSidebar==='function') window._updateGraphSidebar('all',0);
    return;
  }

  const yearColor=YEAR_COLORS[year]||'#caa258';
  nodes.each(function(d){
    const inYear=(d.year===year);
    d3.select(this)
      .attr('opacity',inYear?1:0.15)
      .attr('stroke',inYear?yearColor:'rgba(202,162,88,0.1)')
      .attr('stroke-width',inYear?3:1)
      .style('filter',inYear?`drop-shadow(0 0 12px ${yearColor}88)`:'none');
  });
  links.each(function(d){
    const srcYear=(d.source.year||0)===year;
    const tgtYear=(d.target.year||0)===year;
    const active=srcYear||tgtYear;
    d3.select(this)
      .attr('opacity',active?0.8:0.05)
      .attr('stroke',active?yearColor:'rgba(202,162,88,0.08)')
      .attr('stroke-width',active?2:1)
      .attr('marker-end',null);
  });
  if(typeof window._updateGraphSidebar==='function') window._updateGraphSidebar('all',year);
};

/* ══════════════════════════════════════════════════
   HACKATHON EASTER EGG
   ══════════════════════════════════════════════════ */
