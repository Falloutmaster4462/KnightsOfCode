/* ══════════════════════════════════════════════
   MATIES-OS — Shared Data & Constants
   ══════════════════════════════════════════════ */

const NAV_ICONS={'1':'🏛','2':'👥','3':'📄','4':'🎓','5':'📚','6':'🔬','7':'📰','8':'📅','9':'🎒','10':'📬','11':'🧠','12':'🕸'};

const PAGE_ROUTES = {
  1: 'overview',
  2: 'staff',
  3: 'publications',
  4: 'programmes',
  5: 'courses',
  6: 'research',
  7: 'news',
  8: 'events',
  9: 'students',
  10: 'contact',
  11: 'advisor',
  12: 'graph'
};

const ROUTE_TO_NUM = Object.fromEntries(Object.entries(PAGE_ROUTES).map(([k,v])=>[v,Number(k)]));

const PAGE_META = {
  1: { title: 'Department Overview', desc: 'Department of Computer Science — Stellenbosch University. Africa\'s leading CS department since 1968.' },
  2: { title: 'Academic Staff', desc: 'Meet the faculty and researchers of the CS Department at Stellenbosch University.' },
  3: { title: 'Publications', desc: 'Research publications and output from the CS Department at Stellenbosch University.' },
  4: { title: 'Programmes', desc: 'Undergraduate and postgraduate degree programmes in Computer Science at Stellenbosch University.' },
  5: { title: 'Course Catalogue', desc: 'Full module listings for all CS programmes at Stellenbosch University.' },
  6: { title: 'Research Groups', desc: 'Research groups, labs and centres at the CS Department, Stellenbosch University.' },
  7: { title: 'News', desc: 'Latest news and announcements from the CS Department at Stellenbosch University.' },
  8: { title: 'Events', desc: 'Upcoming events and seminars at the CS Department, Stellenbosch University.' },
  9: { title: 'Student Hub', desc: 'Student resources, FAQs, forms and community for CS students at Stellenbosch University.' },
  10: { title: 'Contact', desc: 'Contact details, location and directions for the CS Department at Stellenbosch University.' },
  11: { title: 'Degree Advisor', desc: 'Smart personalised degree pathway planner for CS students at Stellenbosch University.' },
  12: { title: 'Curriculum Graph', desc: 'Interactive prerequisite graph for all CS modules at Stellenbosch University.' },
};
