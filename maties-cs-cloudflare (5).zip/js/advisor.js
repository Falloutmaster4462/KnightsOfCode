/* ══════════════════════════════════════════════
   MATIES-OS — Degree Advisor Logic
   ══════════════════════════════════════════════ */
window.advToggle=function(el){el.classList.toggle('selected');};
window.advSingle=function(el,groupId){
  document.querySelectorAll(`#${groupId} .adv-chip,#${groupId} .v4-adv-chip`).forEach(c=>c.classList.remove('selected'));
  el.classList.add('selected');
};

const ADVISOR_DATA={
  ai:{track:{name:'AI & Machine Learning Honours Track',desc:'Focus on CS 315, CS 415, CS 448. Research project with AIRL. Leads to MSc/PhD in ML.',lab:'🤖 AI Research Lab (AIRL)',supervisor:'Prof. M. Dlamini'}},
  security:{track:{name:'Cybersecurity Honours Track',desc:'Focus on CS 313, CS 353, CS 416, CS 450 (Cryptography). Research project with CCS.',lab:'🔐 Centre for Cybersecurity (CCS)',supervisor:'Prof. R. Botha'}},
  data:{track:{name:'Data Science & Analytics Track',desc:'Combine CS 315, STAT 244, CS 343. Strong BDatSci pathway. Capstone in data engineering.',lab:'🤖 AI Research Lab + Statistics Dept',supervisor:'Prof. M. Dlamini / Statistics Faculty'}},
  systems:{track:{name:'Systems & HPC Honours Track',desc:'Focus on CS 244, CS 314, CS 431, CS 452. Access to CHPC Lengau supercomputer.',lab:'⚡ High-Performance Computing Group',supervisor:'Assoc. Prof. L. Engelbrecht'}},
  bio:{track:{name:'Bioinformatics Honours Track',desc:'Focus on CS 449, CS 315, genomics research. SARChI Chair supervision. H3Africa data access.',lab:'🧬 Computational Biology Group (CBG)',supervisor:'Prof. S. Naidoo'}},
  theory:{track:{name:'Theory & Formal Methods Track',desc:'Focus on CS 345, CS 323, CS 451, CS 411. Isabelle/HOL theorem proving. Collaboration with INRIA France.',lab:'📐 Formal Methods Group',supervisor:'Assoc. Prof. T. Mokoena'}},
  graphics:{track:{name:'Graphics & Vision Honours Track',desc:'Focus on CS 234, CS 354, CS 453. Industry ties with local studios and AR/VR firms.',lab:'🎮 Computer Graphics & Vision Lab',supervisor:'Dr. P. Hendricks / Dr. Sithole'}},
};

// Full module database for year planner
const ADV_YEAR_PLAN={
  beginner:{
    y1:[
      {code:'CS114',name:'Intro to CS 1',cr:16,sem:'S1'},
      {code:'CS124',name:'Digital Systems',cr:12,sem:'S1'},
      {code:'WIS114',name:'Mathematics 114',cr:16,sem:'S1'},
      {code:'FIS114',name:'Physics 114',cr:16,sem:'S1'},
      {code:'CS144',name:'Intro to CS 2',cr:16,sem:'S2'},
      {code:'WIS144',name:'Mathematics 144',cr:16,sem:'S2'},
      {code:'STAT144',name:'Intro Statistics',cr:12,sem:'S2'},
      {code:'FIS144',name:'Physics 144',cr:16,sem:'S2'},
    ],
    y2:[
      {code:'CS214',name:'Data Structures & Algorithms',cr:16,sem:'S1'},
      {code:'CS224',name:'Theoretical CS',cr:16,sem:'S1'},
      {code:'WIS214',name:'Mathematics 214',cr:16,sem:'S1'},
      {code:'CS244',name:'Architecture & OS',cr:16,sem:'S2'},
      {code:'CS254',name:'Software Construction',cr:16,sem:'S2'},
      {code:'STAT244',name:'Mathematical Statistics',cr:16,sem:'S2'},
    ],
  },
  intermediate:{
    y2:[
      {code:'CS214',name:'Data Structures & Algorithms',cr:16,sem:'S1'},
      {code:'CS224',name:'Theoretical CS',cr:16,sem:'S1'},
      {code:'WIS214',name:'Mathematics 214',cr:16,sem:'S1'},
      {code:'CS244',name:'Architecture & OS',cr:16,sem:'S2'},
      {code:'CS254',name:'Software Construction',cr:16,sem:'S2'},
      {code:'STAT244',name:'Mathematical Statistics',cr:16,sem:'S2'},
    ],
    y3_core:[
      {code:'CS214',name:'DSA (if not done)',cr:16,sem:'S1'},
      {code:'CS315',name:'Machine Learning',cr:16,sem:'S1'},
      {code:'CS344',name:'Software Engineering',cr:16,sem:'S2'},
      {code:'CS345',name:'Computability',cr:16,sem:'S2'},
    ],
  },
  advanced:{
    y4:[
      {code:'CS411',name:'Advanced Algorithms',cr:20,sem:'S1'},
      {code:'CS413',name:'Research Methodology',cr:10,sem:'S1'},
      {code:'CS490',name:'Honours Research Project',cr:40,sem:'Ann'},
    ],
  },
  postgrad:{
    pg:[
      {code:'CS460',name:'MSc Research Project',cr:90,sem:'Ann'},
      {code:'CS413',name:'Research Methodology',cr:10,sem:'S1'},
    ],
  },
};

const ADV_TRACK_MODS={
  ai:{
    y3:[{code:'CS315',name:'Machine Learning',cr:16,sem:'S1'},{code:'CS354',name:'Computer Vision',cr:16,sem:'S2'}],
    y4:[{code:'CS415',name:'Deep Learning',cr:20,sem:'S1'},{code:'CS421',name:'NLP',cr:20,sem:'S2'},{code:'CS422',name:'Reinforcement Learning',cr:20,sem:'S2'}],
    y5:[{code:'CS448',name:'Advanced Machine Learning',cr:20,sem:'S1'},{code:'CS453',name:'Advanced Computer Vision',cr:20,sem:'S1'}],
  },
  security:{
    y3:[{code:'CS313',name:'Computer Networks',cr:16,sem:'S1'},{code:'CS353',name:'Security Fundamentals',cr:16,sem:'S2'}],
    y4:[{code:'CS411',name:'Advanced Algorithms',cr:20,sem:'S1'},{code:'CS416',name:'Network Security & Forensics',cr:20,sem:'S1'}],
    y5:[{code:'CS450',name:'Applied Cryptography',cr:20,sem:'S2'}],
  },
  data:{
    y3:[{code:'CS315',name:'Machine Learning',cr:16,sem:'S1'},{code:'CS343',name:'Databases & IS',cr:16,sem:'S1'}],
    y4:[{code:'CS415',name:'Deep Learning',cr:20,sem:'S1'},{code:'CS421',name:'NLP',cr:20,sem:'S2'}],
    y5:[{code:'CS448',name:'Advanced Machine Learning',cr:20,sem:'S1'}],
  },
  systems:{
    y3:[{code:'CS313',name:'Computer Networks',cr:16,sem:'S1'},{code:'CS314',name:'Concurrent Programming',cr:16,sem:'S1'},{code:'CS373',name:'Embedded Systems',cr:12,sem:'S1'}],
    y4:[{code:'CS431',name:'High-Performance Computing',cr:20,sem:'S1'},{code:'CS441',name:'Advanced Software Engineering',cr:20,sem:'S2'}],
    y5:[{code:'CS452',name:'Cloud & Distributed Systems',cr:20,sem:'S2'}],
  },
  bio:{
    y3:[{code:'CS315',name:'Machine Learning',cr:16,sem:'S1'},{code:'CS343',name:'Databases & IS',cr:16,sem:'S1'}],
    y4:[{code:'CS415',name:'Deep Learning',cr:20,sem:'S1'},{code:'CS411',name:'Advanced Algorithms',cr:20,sem:'S1'}],
    y5:[{code:'CS449',name:'Bioinformatics Algorithms',cr:20,sem:'S1'}],
  },
  theory:{
    y3:[{code:'CS323',name:'Programming Language Concepts',cr:16,sem:'S1'},{code:'CS345',name:'Computability',cr:16,sem:'S2'}],
    y4:[{code:'CS411',name:'Advanced Algorithms',cr:20,sem:'S1'}],
    y5:[{code:'CS451',name:'Formal Verification',cr:20,sem:'S2'}],
  },
  graphics:{
    y2:[{code:'CS234',name:'Computer Graphics Fundamentals',cr:12,sem:'S2'}],
    y3:[{code:'CS354',name:'Computer Vision',cr:16,sem:'S2'}],
    y4:[{code:'CS415',name:'Deep Learning',cr:20,sem:'S1'}],
    y5:[{code:'CS453',name:'Advanced Computer Vision',cr:20,sem:'S1'}],
  },
};

const CAREER_OUTCOMES={
  ai:{
    industry:[
      {role:'ML Engineer',salary:'R600–900k',cos:'Google ZA, AWS, Microsoft'},
      {role:'AI Product Lead',salary:'R700k–1.2M',cos:'Investec, Standard Bank AI'},
      {role:'Computer Vision Engineer',salary:'R550–850k',cos:'Tencent, Naspers'},
    ],
    research:[
      {role:'Postdoc Researcher',salary:'R250–400k',cos:'SU, UCT, CSIR, Meraka'},
      {role:'AI Research Scientist',salary:'R1–2M (intl)',cos:'DeepMind, Meta AI, Anthropic'},
    ],
    startup:[
      {role:'CTO / AI Startup Founder',salary:'Equity + R400–900k',cos:'Startup ecosystems SA, Berlin, London'},
    ],
    phd:[
      {role:'PhD Candidate → Lecturer',salary:'R250–500k+',cos:'SU, UCT, Wits, UKZN'},
    ],
  },
  security:{
    industry:[
      {role:'Security Analyst',salary:'R450–750k',cos:'Deloitte, PwC, KPMG Cyber'},
      {role:'Penetration Tester',salary:'R500–800k',cos:'SensePost, I-TEC, Liquid Intelligent'},
      {role:'CISO',salary:'R900k–1.8M',cos:'FNB, Absa, Standard Bank'},
    ],
    research:[
      {role:'Cryptography Researcher',salary:'R300–500k (SA) / R1.5M+ (intl)',cos:'NCPF, CRISES, CSIR'},
    ],
    startup:[
      {role:'Security Product Founder',salary:'Equity + R400–700k',cos:'Cybercellar, SilverSky-style'},
    ],
    phd:[
      {role:'Lecturer in Security',salary:'R300–600k',cos:'All SA universities'},
    ],
  },
  data:{
    industry:[
      {role:'Data Scientist',salary:'R550–1M',cos:'Capitec, Discovery, MTN'},
      {role:'Quantitative Analyst',salary:'R700k–1.5M',cos:'PSG, Coronation, Ninety One'},
      {role:'ML Platform Engineer',salary:'R600–900k',cos:'BCX, Dimension Data'},
    ],
    research:[
      {role:'Research Data Scientist',salary:'R350–600k',cos:'SANSA, Stats SA, CSIR'},
    ],
    startup:[
      {role:'Data Product CDO/Founder',salary:'Equity + R500k',cos:'Data platforms, InsurTech, FinTech'},
    ],
    phd:[
      {role:'Postgraduate Researcher',salary:'R250–450k',cos:'SU Statistics/CS, NRF bursary'},
    ],
  },
  systems:{
    industry:[
      {role:'Systems/Cloud Architect',salary:'R580–1M',cos:'AWS, MTN, Huawei SA'},
      {role:'DevOps/SRE',salary:'R500–850k',cos:'Takealot, Naspers, BCX'},
      {role:'HPC Engineer',salary:'R550–900k',cos:'CHPC, SARAO, Arm, Nvidia'},
    ],
    research:[
      {role:'HPC Research Engineer',salary:'R350–600k',cos:'CHPC Lengau, CSIR, iThemba LABS'},
    ],
    startup:[
      {role:'Infrastructure Startup CTO',salary:'Equity + R450–750k',cos:'Cloud infra, DevOps tooling'},
    ],
    phd:[
      {role:'Lecturer / Researcher',salary:'R300–550k',cos:'SU EE/CS, UCT, WITS'},
    ],
  },
  bio:{
    industry:[
      {role:'Bioinformatician',salary:'R420–720k',cos:'Mediclinic, Roche, MRC SA'},
      {role:'Pharma Data Scientist',salary:'R480–800k',cos:'Pfizer SA, Aspen, Discovery'},
    ],
    research:[
      {role:'Genomics Researcher',salary:'R280–500k',cos:'H3Africa, SAMRC, Wellcome SA'},
    ],
    startup:[
      {role:'Health-Tech Founder',salary:'Equity + R350–600k',cos:'BioAfrica ecosystem'},
    ],
    phd:[
      {role:'Computational Biology PhD',salary:'R220–400k',cos:'SU, UCT, NIH funding'},
    ],
  },
  theory:{
    industry:[
      {role:'Formal Methods Engineer',salary:'R480–780k',cos:'Siemens, Bosch, Arm Ltd'},
      {role:'Programming Language Engineer',salary:'R600–1M (intl)',cos:'JetBrains, Google PL, Mozilla'},
    ],
    research:[
      {role:'Theory / Logic Researcher',salary:'R300–500k',cos:'INRIA, MPI-SWS, SU'},
    ],
    startup:[
      {role:'Verification Tooling Founder',salary:'Equity + R400–650k',cos:'Formal verification startups'},
    ],
    phd:[
      {role:'CS Theory Lecturer',salary:'R300–550k',cos:'SU, UCT, Wits'},
    ],
  },
  graphics:{
    industry:[
      {role:'Game Developer',salary:'R350–650k',cos:'Ubisoft SA, local studios'},
      {role:'Computer Vision Engineer',salary:'R500–800k',cos:'Tesla, Mobileye (remote), local AI'},
      {role:'VR/AR Engineer',salary:'R450–750k',cos:'Meta SA, Immersive Tech firms'},
    ],
    research:[
      {role:'Vision Researcher',salary:'R300–550k',cos:'SU, CSIR, Disney Research'},
    ],
    startup:[
      {role:'XR/Games Startup CTO',salary:'Equity + R350–600k',cos:'SA Games dev ecosystem'},
    ],
    phd:[
      {role:'Graphics/Vision Researcher',salary:'R280–500k',cos:'SU, UCT, international partner labs'},
    ],
  },
};

window.generateAdvice=function(){
  const sel=s=>[...document.querySelectorAll(s)];
  const getVal=s=>document.querySelector(s)?.dataset.val;
  const interests=sel('#adv-interests .a5-chip.on,#adv-interests .a5-chip.selected').map(c=>c.dataset.val);
  const goal=getVal('#adv-goal .a5-chip.on,#adv-goal .a5-chip.selected')||'industry';
  const skill=getVal('#adv-skill .a5-chip.on,#adv-skill .a5-chip.selected')||'2';
  const math=getVal('#adv-math .a5-chip.on,#adv-math .a5-chip.selected')||'medium';
  const horizon=getVal('#adv-horizon .a5-chip.on,#adv-horizon .a5-chip.selected')||'global';
  const teamwork=getVal('#adv-teamwork .a5-chip.on,#adv-teamwork .a5-chip.selected')||'mixed';
  const project=getVal('#adv-project .a5-chip.on,#adv-project .a5-chip.selected')||'build';
  const sectors=sel('#adv-sector .a5-chip.on,#adv-sector .a5-chip.selected').map(c=>c.dataset.val);
  const school=getVal('#adv-school .a5-chip.on,#adv-school .a5-chip.selected')||'maths';
  const time=getVal('#adv-time .a5-chip.on,#adv-time .a5-chip.selected')||'balanced';
  const langs=sel('#adv-lang .a5-chip.on,#adv-lang .a5-chip.selected').map(c=>c.dataset.val);
  const postgradIntent=getVal('#adv-postgrad-intent .a5-chip.on,#adv-postgrad-intent .a5-chip.selected')||'industry-d';
  const funding=getVal('#adv-funding .a5-chip.on,#adv-funding .a5-chip.selected')||'self';
  const electives=sel('#adv-elective .a5-chip.on,#adv-elective .a5-chip.selected').map(c=>c.dataset.val);

  if(!interests.length){
    document.getElementById('advisor-result').innerHTML=`<div class="m-infobox alert" style="margin-top:16px;">⚠ Please select at least one interest area (Step 01) before generating your pathway.</div>`;
    return;
  }
  triggerGlitch();

  const primary=interests[0];
  const data=ADVISOR_DATA[primary]||ADVISOR_DATA.ai;

  // Build year-by-year module plan
  function dedup(arr){const seen=new Set();return arr.filter(m=>{if(seen.has(m.code))return false;seen.add(m.code);return true;});}

  const baseY1=ADV_YEAR_PLAN.beginner.y1;
  const baseY2=ADV_YEAR_PLAN.beginner.y2;
  const trackY2=interests.flatMap(i=>ADV_TRACK_MODS[i]?.y2||[]);
  const trackY3=interests.flatMap(i=>ADV_TRACK_MODS[i]?.y3||[]);
  const coreY3=[
    {code:'CS344',name:'Software Engineering',cr:16,sem:'S2'},
    {code:'CS345',name:'Computability',cr:16,sem:'S2'},
  ];
  const trackY4=interests.flatMap(i=>ADV_TRACK_MODS[i]?.y4||[]);
  const honoursY4=[
    {code:'CS411',name:'Advanced Algorithms',cr:20,sem:'S1'},
    {code:'CS413',name:'Research Methodology',cr:10,sem:'S1'},
    {code:'CS490',name:'Honours Research Project',cr:40,sem:'Ann'},
  ];
  const trackY5=interests.flatMap(i=>ADV_TRACK_MODS[i]?.y5||[]);

  const plans={
    y1: dedup(baseY1),
    y2: dedup([...baseY2,...trackY2]),
    y3: dedup([...coreY3,...trackY3]),
    y4: dedup([...honoursY4,...trackY4]).slice(0,6),
    y5: dedup([...trackY5,{code:'CS460',name:'MSc Research Project',cr:90,sem:'Ann'}]).slice(0,4),
  };

  function creditsFor(mods){return mods.reduce((s,m)=>s+m.cr,0);}

  const YEAR_COLORS_ADV={y1:'#61223b',y2:'#a07a30',y3:'#1a6040',y4:'#1a3a70',y5:'#420f27'};

  function yearCard(label,mods,ykey){
    const cr=creditsFor(mods);
    const maxCr=ykey==='y5'?120:ykey==='y4'?120:128;
    const pct=Math.min(100,Math.round(cr/maxCr*100));
    const rows=mods.map(m=>`
      <div class="adv-mod-row">
        <span class="adv-mod-code" onclick="advHighlightOnGraph('${m.code}')" title="Click to highlight on graph">${m.code}</span>
        <span class="adv-mod-name">${m.name}</span>
        <span class="adv-mod-cr">${m.cr}cr · ${m.sem||'—'}</span>
      </div>`).join('');
    return `
      <div class="adv-year-card">
        <div class="adv-year-hdr" style="background:${YEAR_COLORS_ADV[ykey]||'#420f27'}">${label} · ${cr} credits</div>
        <div class="adv-year-body">
          ${rows}
          <div class="adv-credit-bar" style="margin-top:8px;"><div class="adv-credit-fill" style="width:${pct}%"></div></div>
          <div style="font-family:'Share Tech Mono',monospace;font-size:0.98rem;color:var(--su-gold-d);margin-top:4px;">${cr}/${maxCr} credits (${pct}%)</div>
        </div>
      </div>`;
  }

  // Career outcomes
  const outcomes=(CAREER_OUTCOMES[primary]||CAREER_OUTCOMES.ai)[goal]||(CAREER_OUTCOMES[primary]||CAREER_OUTCOMES.ai).industry;
  const outcomeCards=outcomes.map(o=>`
    <div class="adv-outcome-card">
      <div class="adv-outcome-role">${o.role}</div>
      <div class="adv-outcome-salary">💰 ${o.salary} p.a.</div>
      <div class="adv-outcome-co">🏢 ${o.co}</div>
    </div>`).join('');

  // Skill profile bars
  const skillProfile=[
    {name:'Programming Depth',pct: skill==='postgrad'?95:skill==='advanced'?85:skill==='intermediate'?65:40,color:'#82CCAE'},
    {name:'Mathematics',pct: math==='high'?90:math==='medium'?65:40,color:'#caa258'},
    {name:'Systems Thinking',pct: interests.includes('systems')||interests.includes('security')?80:45,color:'#64c8d4'},
    {name:'Research Ability',pct: goal==='phd'||goal==='research'?85:skill==='advanced'||skill==='postgrad'?60:30,color:'#b48ae0'},
    {name:'Data Literacy',pct: interests.includes('data')||interests.includes('ai')||interests.includes('bio')?82:40,color:'#f5a623'},
    {name:'Domain Specialisation',pct: interests.length>=3?75:interests.length===2?55:35,color:'#dc4405'},
  ];
  const profileBars=skillProfile.map(s=>`
    <div style="margin-bottom:10px;">
      <div style="display:flex;justify-content:space-between;font-family:'Share Tech Mono',monospace;font-size:0.81rem;color:var(--su-gold-d);margin-bottom:4px;"><span>${s.name}</span><span>${s.pct}%</span></div>
      <div class="adv-skill-bar"><div class="adv-skill-fill" style="width:${s.pct}%;background:${s.color};"></div></div>
    </div>`).join('');

  // All recommended module IDs for graph highlight
  const allHighlightIds=[...plans.y1,...plans.y2,...plans.y3,...plans.y4,...plans.y5].map(m=>m.code);
  window._advisorHighlightIds=allHighlightIds;
  // Store full plan context for graph page dynamic sidebar
  window._advisorPlan={
    interests, goal, skill, horizon, primary,
    moduleIds: allHighlightIds,
    plans,
    trackLabel:{ai:'🤖 AI / ML',security:'🔐 Security',systems:'⚡ Systems',data:'📊 Data',bio:'🧬 Bioinformatics',theory:'📐 Theory',graphics:'🎮 Graphics',honours:'🎓 Honours'}[primary]||(primary.charAt(0).toUpperCase()+primary.slice(1)),
    goalLabel:{industry:'Industry',research:'Research',startup:'Startup',phd:'PhD'}[goal]||goal,
    totalModules: allHighlightIds.length,
    totalCredits: [...plans.y1,...plans.y2,...plans.y3,...plans.y4].reduce((s,m)=>s+m.cr,0),
  };
  // Refresh graph sidebar panel if graph page is currently mounted
  if(typeof window._updateAdvisorGraphPanel==='function') window._updateAdvisorGraphPanel();

  const labs=[...new Set(interests.map(i=>ADVISOR_DATA[i]?.track?.lab).filter(Boolean))];
  const supervisors=[...new Set(interests.map(i=>ADVISOR_DATA[i]?.track?.supervisor).filter(Boolean))];

  // Horizon note
  const horizonNote={
    local:'🇿🇦 <strong>South African Market:</strong> Strong tech hubs in Cape Town (Techstars, Silicon Cape), Johannesburg (JSE FinTech corridor), and Stellenbosch (Innovus). Key employers: FNB, Absa, Standard Bank (digital), MTN, Vodacom, Naspers/Prosus, Takealot, CSIR, SARS IT, and fast-growing local startups like Yoco, Ozow, and WhereIsMyTransport.',
    africa:'🌍 <strong>Pan-African Opportunity:</strong> Andela (engineering talent network), Flutterwave, Paystack, MTN Group Pan-Africa, H3Africa bioinformatics network, AU tech bodies, and AfriLabs innovation hubs. Lagos, Nairobi, Accra, and Kigali are growing tech cities alongside Cape Town.',
    eu:'🇪🇺 <strong>Europe / UK Pathway:</strong> SU Honours is well-regarded in Europe. UK Graduate Visa (2 years post-study work right, no sponsorship needed). Netherlands Highly Skilled Migrant Visa (HSM — fast, employer-sponsored). Germany (Job Seeker Visa, no offer needed, 6-month window). Key employers: ASML, SAP, Booking.com, Spotify, DeepMind, ARM, Siemens. NB: German BSc/BEng equivalence — Honours often required for direct Masters admission.',
    us:'🇺🇸 <strong>North America Pathway:</strong> US H-1B lottery (employer-sponsored, highly competitive — plan 2+ years ahead). OPT/STEM OPT via a US Masters is the typical route (3 years work authorisation). Canada Express Entry: 67+ points with SU degree is achievable — LMIA job offer adds 200 points. Key employers: Google, Meta, Amazon, Microsoft, Stripe, Databricks. Strong LeetCode prep essential from Year 3.',
    global:'🌐 <strong>Fully Remote / Global:</strong> An SU CS degree with Honours is internationally competitive. Remote-first employers: GitLab, Automattic, Basecamp, Zapier, Netlify, HuggingFace. Freelance platforms: Toptal (rigorous vetting), Turing.com, Andela. Strong GitHub presence + portfolio of deployed projects is more important than location for remote roles.',
  }[horizon]||'';

  // Sector-specific notes
  const sectorInsights={
    fintech:'💳 <strong>FinTech SA:</strong> FNB, Absa, Capitec digital, Investec, and neobanks like TymeBank highly value CS graduates with distributed systems, cryptography, and data engineering skills. Recommended modules: CS 313 (Networks), CS 353 (Security), CS 343 (Databases), CS 450 (Cryptography). CFA Level 1 complement is noted positively for quant/algorithmic roles.',
    health:'🏥 <strong>Health Tech SA:</strong> Discovery Health IT, Mediclinic, private hospital groups, and bioinformatics firms need CS grads who can work with HL7/FHIR standards, medical imaging ML, and POPIA-compliant data systems. CS 315 (ML), CS 449 (Bioinformatics), and CS 343 (Databases) are most relevant.',
    gov:'🏛 <strong>Government / Public Sector:</strong> CSIR, SARS IT, DHA digital transformation, SABC, Eskom digital. Security clearance may be required for some roles. DPSA and OCIO often advertise. SA Digital Government is under-resourced — high impact opportunity. CS 353 (Security) and CS 344 (Software Engineering) strongly recommended.',
    tech:'💻 <strong>Big Tech / FAANG:</strong> Google, Meta, AWS, Microsoft, Qualcomm have SA presence or hire remotely. Highly competitive — require exceptional DSA skills. LeetCode preparation from Year 3 onwards essential. System Design interviews from Year 4. CS 411 (Advanced Algorithms), CS 431 (HPC), and CS 441 (Advanced SE) directly relevant.',
    telco:'📡 <strong>Telecoms:</strong> MTN, Vodacom, Telkom, and BCX seek systems engineers, HPC specialists, and network security professionals. 5G, edge computing, and IoT skills in high demand. CS 313 (Networks), CS 314 (Concurrent), CS 373 (Embedded) are directly applicable.',
    academia:'🎓 <strong>Academia:</strong> NRF rating system rewards publication output. Start publishing in Year 4 Honours project. Conferences: SATNAC (SA), IEEE, ACM. Lecturing posts require PhD. Apply for NRF Thuthuka or Scarce Skills bursaries by September of Honours year.',
    defence:'🛡 <strong>Defence / Intelligence:</strong> SANDF Cyber Command, State Security Agency, ARMSCOR. Requires South African citizenship and security vetting. CS 353 (Security), CS 416 (Network Security), CS 450 (Cryptography) are directly relevant. Niche but growing sector in SA.',
    energy:'⚡ <strong>Energy / Climate Tech:</strong> Eskom ICT, CSIR Energy, private renewable energy companies (Red Cap, Scatec), climate data platforms. Strong systems (CS 431) and data (CS 315, CS 343) focus recommended. SA has strong solar/wind sector where digital engineering is growing.',
  };
  const sectorHtml=sectors.length?sectors.map(s=>sectorInsights[s]?`<div style="padding:12px 14px;margin-bottom:8px;background:rgba(202,162,88,0.05);border-left:3px solid var(--su-gold-d);border-radius:0 3px 3px 0;font-family:'Raleway',sans-serif;font-size:1.10rem;line-height:1.75;color:var(--page-text2);">${sectorInsights[s]}</div>`:'').join(''):'<div class="m-infobox" style="margin:0;font-size:1.10rem;">Select sector preferences in Step 07 for targeted employer and industry insights.</div>';

  // Study strategy
  const studyStrategies={
    fast:'⚡ <strong>Fast-Track Strategy:</strong> Stick to required core modules, avoid elective overload. Use semester gaps for internships. Apply for Honours early (August of Year 3). Aim for 70%+ in CS 214 — your GPA gates Honours admission.',
    balanced:'⚖ <strong>Balanced Strategy:</strong> Take 1–2 electives per semester that align with your track. Complete at least one research project or conference paper before Honours. Internship in Year 3 summer highly recommended.',
    deep:'🔬 <strong>Deep Expertise Strategy:</strong> Load up on track-specific modules. Consider an extra elective per year for breadth. Co-author with a supervisor from Year 3. Target international conferences (CVPR, NeurIPS, IEEE) for your Honours dissertation output.',
  };
  const studyStrategy=studyStrategies[time]||studyStrategies.balanced;

  // Teamwork insight
  const workInsights={
    solo:'Your preference for deep solo focus aligns well with research, formal verification, or core algorithm engineering. Leverage this in your Honours project — pick a clearly scoped independent research topic. Consider open-source contributions to build portfolio.',
    mixed:'A mixed work preference is the most common in industry and academia. You will thrive in agile teams while still producing individual technical contributions. Excellent fit for full-stack, platform engineering, or ML research roles.',
    team:'Collaborative preference is valued in product companies, consulting, and startup environments. You will excel at Scrum-based delivery, system design, and cross-functional roles like engineering management, DevOps, or tech lead positions.',
    lead:'Leadership preference is valuable but benefits from 2–3 years of deep technical work first. Focus on technical excellence in Years 1–3, then leverage CS 344 (Software Engineering) and CS 413 (Research Methodology) to develop project leadership skills.',
  };
  const workInsight=workInsights[teamwork]||workInsights.mixed;

  // Project type advice
  const projectAdvice={
    build:'🔨 <strong>Engineering-first:</strong> Your Honours project should have a substantial software artefact. Think: novel system, tool, framework, or deployed application. CS 490 supervisors who suit this style include those in Systems, Security, and Graphics groups. Industry partnerships (co-supervised with company) are available.',
    research:'🔬 <strong>Research-first:</strong> Aim for a publishable contribution — a novel algorithm, empirical study, or theoretical result. Target the SU CS Research Symposium and SATNAC/IEEE for submission. Strong alignment with AI, Theory, and Bioinformatics supervisors.',
    analyse:'📊 <strong>Analysis-first:</strong> Strong fit for Data Science, Security, and Bioinformatics tracks. Your Honours project could involve dataset construction, benchmark evaluation, or empirical comparison of existing methods. CS 413 Research Methodology is essential.',
    design:'🎨 <strong>Design-first:</strong> HCI + CS 363 is your core foundation. Honours project could be a user study, interactive system evaluation, or accessibility research. Collaboration with the Industrial Engineering or Information Science departments is possible.',
    prove:'📐 <strong>Formal methods-first:</strong> Strong alignment with Theory track. CS 451 (Formal Verification) and Isabelle/HOL are your tools. Collaboration with INRIA France and the Formal Methods Group possible for exceptional students.',
  };
  const projectTip=projectAdvice[project]||projectAdvice.build;

  // School background warning
  const schoolNotes={
    maths:'✓ Your Maths + Physics background is strong — standard entry path. Focus on hitting ≥70% in WIS 114 Semester 1 to stay on track for all CS + Maths modules.',
    'maths-only':'⚠ Without Physics, watch out for FIS 114 in first semester — it\'s a requirement and can be challenging. Attend all tutorials. The Physics Department runs bridging sessions before semester start.',
    'maths-low':'⚠ A Maths result below 60% puts CS 114 and WIS 114 at risk. Strongly consider attending the SU Science Faculty bridging programme in January. Contact the CS undergraduate office for a baseline assessment.',
    matlit:'🚨 Mathematical Literacy does not meet the prerequisite for most CS modules — WIS 114 requires Pure Maths. You will need to complete a bridging/extended curriculum programme. Consult the Faculty of Science Registrar immediately.',
    ib:'🌐 IB/A-Levels: IB HL Maths (6+) and IB HL Physics typically satisfy prerequisites. A-Level Maths A/B with Further Maths is ideal. Contact the SU Registrar for direct credit recognition — you may be exempt from some Year 1 modules.',
  };
  const schoolNote=schoolNotes[school]||schoolNotes.maths;

  // Funding advice
  const fundingAdvice={
    self:'💰 Self-funded: Check SU Bursary portal (beurs.sun.ac.za) each March — merit bursaries for CS students with 65%+ averages. CS Dept sometimes has departmental bursaries for Honours students. Apply for NSFAS early even if unsure of eligibility.',
    nsfas:'📋 NSFAS: Ensure your allowances cover accommodation and textbooks — the CS Dept textbook list is on the portal. NSFAS does not cover Honours laptop requirements directly — apply for additional departmental support. Maintain satisfactory academic progress (SAP) to avoid suspension.',
    bursary:'🏆 Corporate bursary: Your bursary provider may have return-of-service obligations — factor this into your postgrad and career plans. Ask about sponsoring your Honours year explicitly. Many SA corporates (FNB, Investec, Standard Bank) sponsor Honours and MSc students.',
    nrf:'🔬 NRF funded: Apply annually via the NRF Online Submission System (September deadline). Keep your supervisor informed. NRF top-up bursaries are available — ask your supervisor. International conference travel grants available separately via DAAD, NRF, and SU Postgrad Office.',
    'part-time':'⚡ Need income: Consider SU tutoring/demonstrator positions (CS Dept advertises internally in January). Freelance platforms (Upwork, Toptal-prep level) are viable from Year 3. Part-time employment during semester is manageable at ≤15hrs/week — more risks academic performance.',
    seeking:'🔍 Seeking funding: Priority actions: (1) Apply for NSFAS by 30 November, (2) Contact CS Dept administrator for departmental bursaries, (3) Apply to Sasol, Eskom, and Standard Bank bursary programs (August deadlines), (4) Check the SU Bursary portal monthly.',
  };
  const fundingNote=fundingAdvice[funding]||fundingAdvice.self;

  // Elective-specific flags
  const electiveFlags={
    hci:'🖱 <strong>HCI:</strong> Take CS 363 (Human-Computer Interaction) in Y3 S2. Consider cross-faculty modules in Industrial Engineering (user research methods). Figma + user testing skills are industry-valued.',
    embedded:'🔧 <strong>Embedded/IoT:</strong> CS 373 (Embedded Systems, Y3 S1) is your core. Supplement with personal projects on Arduino/Raspberry Pi/ESP32. Link to Systems or Robotics Honours tracks.',
    blockchain:'🔗 <strong>Blockchain/Web3:</strong> No dedicated module exists — build via CS 450 (Cryptography) + self-study. Ethereum/Solidity, ZK proofs, and Layer 2 scaling are the current frontier. Strong portfolio piece for FinTech roles.',
    nlp:'💬 <strong>NLP:</strong> CS 421 (Natural Language Processing, Y4 S2) is your core Honours module. Supplement with HuggingFace course and African language NLP datasets (Masakhane project).',
    quantum:'⚛ <strong>Quantum Computing:</strong> No dedicated SU CS module — pursue via Qiskit/IBM Quantum Learning independently. CS 345 (Computability) and CS 224 (Theoretical CS) are your theoretical foundations. Growing field — early mover advantage.',
    ethics:'⚖ <strong>AI Ethics / Law:</strong> No dedicated module — pursue via Philosophy or Law cross-faculty electives, or the AI Ethics Professional Certificate (online). Essential for policy, consulting, and NGO career paths.',
    robotics:'🤖 <strong>Robotics:</strong> CS 373 (Embedded) + CS 354 (Computer Vision) + ROS2 self-study. SU Mechanical Engineering has a robotics lab — cross-faculty collaboration possible. Strong hardware engineering complement.',
    'open-source':'🌐 <strong>Open-Source:</strong> Start contributing from Year 2. Target beginner-friendly issues on GitHub (good-first-issue label). By Year 3: aim to be a regular contributor to 1–2 projects in your track. Open-source portfolio is increasingly as valuable as academic record.',
  };
  const electiveHtml=electives.length?`<div style="display:flex;flex-direction:column;gap:8px;">${electives.map(e=>electiveFlags[e]?`<div style="padding:10px 14px;background:rgba(202,162,88,0.04);border-radius:3px;font-family:'Raleway',sans-serif;font-size:1.10rem;line-height:1.7;color:var(--page-text2);">${electiveFlags[e]}</div>`:'').join('')}</div>`:'';

  // Language ecosystem advice
  const langEcosystem={
    python:'🐍 <strong>Python:</strong> Dominates ML, data science, scripting, and bioinformatics. Use pyenv + conda environments. Key libs: NumPy, PyTorch, FastAPI, scikit-learn, Pydantic. Production-grade Python: type hints, pytest, GitHub Actions.',
    cpp:'⚙ <strong>C/C++:</strong> Language of systems, games, embedded, and HPC. Master STL, RAII, CMake, and sanitisers (ASan, UBSan). Rust is the modern memory-safe alternative — both are excellent foundations. Used heavily in CS 244, CS 314, CS 431.',
    java:'☕ <strong>Java/Kotlin:</strong> Enterprise staples at SA banks (Java Spring Boot) and Android development. Strong type system. Kotlin is fully interoperable and cleaner for new projects. Used in CS 114/CS 144.',
    rust:'🦀 <strong>Rust:</strong> Growing rapidly in systems programming, WebAssembly, and blockchain. Cargo ecosystem is excellent. Ownership model eliminates entire classes of bugs. Recommended if you like C++ but want memory safety and modern tooling.',
    js:'🌐 <strong>JS/TypeScript:</strong> Runs the web. Essential for frontend, full-stack (Node.js), and increasingly backend (Deno, Bun). Pair with React, Next.js, or SvelteKit. TypeScript is essentially mandatory for large codebases.',
    r:'📊 <strong>R/Julia:</strong> Languages of statistical computing and scientific simulation. Excellent for data analysis (tidyverse), bioinformatics (Bioconductor), and numerical methods. Julia is faster and growing for HPC applications.',
    haskell:'λ <strong>Haskell/OCaml/Prolog:</strong> Core to the Theory track. Used in CS 323 (PL Concepts). Functional programming skills transfer directly to modern Scala, F#, and Rust. Prolog used in logic programming labs.',
    go:'🐹 <strong>Go/Elixir:</strong> Go is Google\'s production language — excellent for cloud-native microservices, CLI tools, and Kubernetes operators. Elixir/Erlang for fault-tolerant distributed systems. Strong niche in infrastructure engineering.',
  };
  const langHtml=langs.length?langs.map(l=>langEcosystem[l]?`<div style="padding:10px 14px;margin-bottom:6px;background:rgba(202,162,88,0.04);border-radius:3px;font-family:'Raleway',sans-serif;font-size:1.10rem;line-height:1.65;color:var(--page-text2);">${langEcosystem[l]}</div>`:'').join(''):`<div style="font-family:'Share Tech Mono',monospace;font-size:0.98rem;color:var(--su-gold-d);">No language preference selected — start with Python for breadth, C++ for depth.</div>`;

  // Postgrad pathway
  const postgradPathways={
    msc:'<strong>MSc (Coursework):</strong> 1 year of taught modules + mini-dissertation. Lower research burden, useful for industry transition. 120 credits. Competitive for NRF funding (R120k p.a.). Apply via SU Postgrad Office by August.',
    'msc-r':'<strong>MSc (Research):</strong> Full research dissertation over 1.5–2 years. Requires supervisor and approved research proposal. Leads naturally to PhD. NRF bursary R120k p.a. DAAD and Fulbright fellowships also available. Apply by August/September.',
    'phd-d':'<strong>PhD (Direct):</strong> 3–4 years, full research, supervisor required. Requires strong Honours project (≥70%). NRF funding R160k p.a. Grants international standing — SU PhDs are accepted globally. Co-supervision with international partners (INRIA, TU Delft, CMU) possible.',
    'industry-d':'<strong>Industry Direct:</strong> Honours qualifies for most SA industry roles. Start applying in August of Honours year. CS Society vacancy mailing list (vacvac@cs.sun.ac.za) and LinkedIn SA Tech group are primary channels. Expect 3–6 month job search timeline.',
    undecided:'<strong>Undecided:</strong> Keep options open — maintain your GPA above 65% throughout, build a strong GitHub portfolio, and approach at least one supervisor for an Honours project conversation in July of Year 3. You can decide on postgrad vs industry during your Honours year.',
  };
  const postgradPathway=postgradPathways[postgradIntent]||postgradPathways['industry-d'];

  document.getElementById('advisor-result').innerHTML=`
    <div class="adv-result">
      <div class="adv-result-header">
        <div class="adv-result-title">🎯 Your Personalised CS Pathway</div>
        <div class="adv-result-sub">GENERATED FOR: ${interests.map(i=>i.toUpperCase()).join(' + ')} &nbsp;·&nbsp; GOAL: ${goal.toUpperCase()} &nbsp;·&nbsp; LEVEL: ${skill.toUpperCase()} &nbsp;·&nbsp; HORIZON: ${horizon.toUpperCase()}</div>
      </div>
      <div class="adv-result-body">

        <!-- Year-by-year plan -->
        <div class="adv-section">
          <div class="adv-section-label">📅 Year-by-Year Module Plan — ${interests.map(i=>i.charAt(0).toUpperCase()+i.slice(1)).join(' + ')} Focus</div>
          <p style="font-family:'Raleway',sans-serif;font-size:1.10rem;color:var(--page-text2);margin-bottom:14px;line-height:1.7;">Your plan is customised based on your interest areas, career goal, and mathematics level. <strong>Click any module code</strong> to see it highlighted in the Curriculum Graph. Total degree: ~480 credits over 4 years (+ 90–120cr for MSc if applicable).</p>
          <div class="adv-year-grid">
            ${yearCard('Year 1 — Foundation (${creditsFor(plans.y1)}cr)',plans.y1,'y1')}
            ${yearCard('Year 2 — Core CS (${creditsFor(plans.y2)}cr)',plans.y2,'y2')}
            ${yearCard('Year 3 — Specialisation (${creditsFor(plans.y3)}cr)',plans.y3,'y3')}
            ${yearCard('Year 4 — Honours (${creditsFor(plans.y4)}cr)',plans.y4,'y4')}
            ${skill==='postgrad'?yearCard('Postgraduate MSc (${creditsFor(plans.y5)}cr)',plans.y5,'y5'):''}
          </div>
        </div>

        <!-- Critical milestones -->
        <div class="adv-section">
          <div class="adv-section-label">⚡ Critical Milestones &amp; Deadlines</div>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;">
            <div style="background:rgba(220,68,5,0.06);border:1px solid rgba(220,68,5,0.15);border-left:4px solid #dc4405;border-radius:0 4px 4px 0;padding:14px 16px;">
              <div style="font-family:'Share Tech Mono',monospace;font-size:0.75rem;color:#f07040;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">🔑 Y1 S2 Gateway</div>
              <div style="font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">Pass <strong>CS 114</strong> and <strong>CS 144</strong> with 50%+ to proceed to Year 2. These gate all downstream CS modules. If struggling, contact the undergraduate coordinator early.</div>
            </div>
            <div style="background:rgba(220,68,5,0.06);border:1px solid rgba(220,68,5,0.15);border-left:4px solid #dc4405;border-radius:0 4px 4px 0;padding:14px 16px;">
              <div style="font-family:'Share Tech Mono',monospace;font-size:0.75rem;color:#f07040;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">⚠ Y2 S1 Bottleneck</div>
              <div style="font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);"><strong>CS 214 Data Structures &amp; Algorithms</strong> is the most critical module in the degree — it unlocks virtually every Year 3 and 4 specialisation. Target 65%+ as this impacts Honours admission GPA.</div>
            </div>
            <div style="background:rgba(202,162,88,0.06);border:1px solid rgba(202,162,88,0.12);border-left:4px solid var(--su-gold-d);border-radius:0 4px 4px 0;padding:14px 16px;">
              <div style="font-family:'Share Tech Mono',monospace;font-size:0.75rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">📋 Y3 Honours Application</div>
              <div style="font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">Apply for Honours by <strong>31 August</strong> of Year 3. Email supervisor interest letters to your top 3 supervisors in <strong>July</strong>. Admission is competitive — minimum average of 60% in CS modules typically required.</div>
            </div>
            <div style="background:rgba(202,162,88,0.06);border:1px solid rgba(202,162,88,0.12);border-left:4px solid var(--su-gold-d);border-radius:0 4px 4px 0;padding:14px 16px;">
              <div style="font-family:'Share Tech Mono',monospace;font-size:0.75rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">📝 Y4 S1 Research Proposal</div>
              <div style="font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);"><strong>CS 413 Research Methodology</strong>: Submit your Honours dissertation proposal by Week 6 of Semester 1. Attend all proposal seminars — feedback is critical for scoping your 40-credit project.</div>
            </div>
            ${skill==='postgrad'?`<div style="background:rgba(26,96,64,0.06);border:1px solid rgba(26,96,64,0.15);border-left:4px solid #1a6040;border-radius:0 4px 4px 0;padding:14px 16px;">
              <div style="font-family:'Share Tech Mono',monospace;font-size:0.75rem;color:var(--su-green);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">🎓 MSc/PhD Funding</div>
              <div style="font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">NRF bursary deadline: <strong>September</strong> for the following year. Apply via the NRF Online Submission System. Masters: R120k p.a. · PhD: R160k p.a. CS Dept bursaries: email pg-cs@sun.ac.za by <strong>October</strong>.</div>
            </div>`:''}
            <div style="background:rgba(26,58,112,0.06);border:1px solid rgba(26,58,112,0.15);border-left:4px solid #1a3a70;border-radius:0 4px 4px 0;padding:14px 16px;">
              <div style="font-family:'Share Tech Mono',monospace;font-size:0.75rem;color:#5a8ae0;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">💼 Internship Window</div>
              <div style="font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">Internship applications open <strong>March</strong> (for December–January intake) and <strong>August</strong> (for June–July). Subscribe to the CS Society vacvac mailing list. First internship realistically achievable after Year 2.</div>
            </div>
          </div>
        </div>

        <!-- Study strategy -->
        <div class="adv-section">
          <div class="adv-section-label">📖 Your Study Strategy — ${time==='fast'?'Fast-Track':time==='deep'?'Deep Expertise':'Balanced'} Mode</div>
          <div class="m-infobox success" style="margin:0;">${studyStrategy}</div>
          <div style="margin-top:10px;padding:12px 16px;background:rgba(202,162,88,0.04);border-radius:4px;font-family:'Raleway',sans-serif;font-size:1.10rem;line-height:1.7;color:var(--page-text2);">
            <strong>Work style insight:</strong> ${workInsight}
          </div>
          <div style="margin-top:10px;padding:12px 16px;background:rgba(202,162,88,0.04);border-radius:4px;font-family:'Raleway',sans-serif;font-size:1.10rem;line-height:1.7;color:var(--page-text2);">
            ${projectTip}
          </div>
        </div>

        <!-- School background -->
        <div class="adv-section">
          <div class="adv-section-label">🏫 School Background Assessment</div>
          <div class="m-infobox ${school==='maths-low'||school==='matlit'?'alert':'success'}" style="margin:0;font-size:1.10rem;line-height:1.8;">${schoolNote}</div>
        </div>

        <!-- Funding -->
        <div class="adv-section">
          <div class="adv-section-label">💰 Funding Guidance — ${funding==='nsfas'?'NSFAS':funding==='bursary'?'Corporate Bursary':funding==='nrf'?'NRF / Postgrad':funding==='part-time'?'Part-Time Income':funding==='seeking'?'Seeking Funding':'Self-Funded'}</div>
          <div class="m-infobox" style="margin:0;font-size:1.10rem;line-height:1.8;">${fundingNote}</div>
        </div>

        <!-- Research groups -->
        <div class="adv-section">
          <div class="adv-section-label">🔬 Recommended Research Groups &amp; Supervisors</div>
          <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:12px;">
            ${labs.map(lab=>`<div class="adv-outcome-card" style="border-left-color:var(--su-green);">${lab}</div>`).join('')}
          </div>
          <div style="font-family:'Share Tech Mono',monospace;font-size:0.90rem;color:var(--su-gold-d);margin-top:6px;">
            Potential supervisors matching your profile: ${supervisors.join(' · ')||'Contact pg-cs@sun.ac.za for introductions'}
          </div>
          <div style="margin-top:12px;font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.7;color:var(--page-text2);">
            <strong>How to approach supervisors:</strong> Email a brief (max 3-paragraph) introduction in July/August of Year 3 including: (1) your academic record, (2) a specific research question you want to explore, and (3) why you want to work with them specifically. Research their recent publications on <a href="https://scholar.google.com" target="_blank" class="m-link">Google Scholar</a> first.
          </div>
        </div>

        <!-- Honours track -->
        <div class="adv-section">
          <div class="adv-section-label">🎓 Honours Track — ${data.track.name}</div>
          <div class="adv-outcome-card" style="border-left-color:var(--su-maroon);padding:18px 20px;">
            <div class="adv-outcome-role" style="font-size:1.25rem;margin-bottom:8px;">${data.track.name}</div>
            <div style="font-family:'Raleway',sans-serif;font-size:1.10rem;color:var(--page-text2);line-height:1.75;">${data.track.desc}</div>
            <div style="margin-top:12px;font-family:'Share Tech Mono',monospace;font-size:1.06rem;color:var(--su-gold-d);">CORE HONOURS MODULES: CS 411 Advanced Algorithms · CS 413 Research Methodology · CS 490 Research Project (40cr)</div>
          </div>
        </div>

        <!-- Post-honours pathway -->
        <div class="adv-section">
          <div class="adv-section-label">🚀 Post-Honours Pathway — ${postgradIntent.includes('msc')||postgradIntent==='phd-d'?'Postgraduate':'Industry'} Route</div>
          <div class="m-infobox" style="margin:0;font-size:1.10rem;line-height:1.8;">${postgradPathway}</div>
        </div>

        <!-- Career outcomes -->
        <div class="adv-section">
          <div class="adv-section-label">💼 Career Outcomes — ${goal.charAt(0).toUpperCase()+goal.slice(1)} Pathway (SA &amp; International)</div>
          <div class="adv-outcome-grid">${outcomeCards}</div>
        </div>

        <!-- Sector insights -->
        ${sectors.length?`<div class="adv-section">
          <div class="adv-section-label">🏢 Your Sector Intelligence — ${sectors.map(s=>s.charAt(0).toUpperCase()+s.slice(1)).join(', ')}</div>
          ${sectorHtml}
        </div>`:''}

        <!-- Geographic outlook -->
        ${horizonNote?`<div class="adv-section">
          <div class="adv-section-label">🌍 Geographic Outlook — ${horizon==='local'?'South Africa':horizon==='africa'?'Pan-Africa':'International'} Focus</div>
          <div class="m-infobox success" style="margin:0;font-size:1.10rem;line-height:1.8;">${horizonNote}</div>
        </div>`:''}

        <!-- Skill profile -->
        <div class="adv-section">
          <div class="adv-section-label">📊 Your Projected Skill Profile at Graduation</div>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:0;">
            ${profileBars}
          </div>
          <p style="font-family:'Raleway',sans-serif;font-size:1.03rem;color:var(--page-text2);margin:12px 0 0;line-height:1.65;">These projections are based on your stated interests, career goal, and current level. Percentages reflect likely standing relative to graduates across all tracks — not absolute mastery.</p>
        </div>

        <!-- Language ecosystem -->
        <div class="adv-section">
          <div class="adv-section-label">💻 Programming Language Ecosystem</div>
          ${langHtml}
          ${langs.length?`<div class="m-infobox" style="margin-top:10px;font-size:1.06rem;">Pro tip: SU CS modules primarily use Java (Y1–2), C/C++ (systems), Python (ML/data), and Haskell/Prolog (theory). Supplement with personal projects in your preferred stack.</div>`:''}
        </div>

        <!-- Elective interests -->
        ${electives.length?`<div class="adv-section">
          <div class="adv-section-label">🎯 Special Elective Interests — ${electives.map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(', ')}</div>
          ${electiveHtml}
        </div>`:''}

        <!-- Quick tips -->
        <div class="adv-section">
          <div class="adv-section-label">💡 Personalised Quick Tips</div>
          <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;">
            <div style="background:var(--page-bg2);border-radius:4px;padding:14px 16px;font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">
              <strong style="color:var(--page-maroon);">GitHub Portfolio:</strong> Start from Year 1. By Year 3, aim for 15+ repos with READMEs, tests, and CI/CD pipelines. Link on your CV — SA tech employers almost always check.
            </div>
            <div style="background:var(--page-bg2);border-radius:4px;padding:14px 16px;font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">
              <strong style="color:var(--page-maroon);">CS Society (CSS):</strong> Join from Day 1. Access to vacancy mailing list, hackathon team forming, peer tutoring, and industry speaker events. Monthly meetings, Tuesdays after 17:00.
            </div>
            <div style="background:var(--page-bg2);border-radius:4px;padding:14px 16px;font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">
              <strong style="color:var(--page-maroon);">LeetCode / Competitive:</strong> ${goal==='industry'||goal==='startup'||goal==='consulting'?'Start in Year 3 — FAANG and SA tech interviews lean heavily on DSA. Aim for 150+ Easy/Medium problems before applying.':'Less relevant for research paths — focus on project quality and publication output instead of interview prep.'}
            </div>
            <div style="background:var(--page-bg2);border-radius:4px;padding:14px 16px;font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">
              <strong style="color:var(--page-maroon);">Certifications:</strong> ${interests.includes('security')?'CompTIA Security+ by Year 3, then CEH or OSCP for Honours/postgrad — both recognised in SA and internationally.':interests.includes('systems')||interests.includes('data')?'AWS Cloud Practitioner (free via AWS Educate) is excellent. Google Professional ML Engineer for data/AI tracks.':'Google Professional ML Engineer or Azure AI Engineer — well recognised for AI/data tracks in SA and globally.'}
            </div>
            <div style="background:var(--page-bg2);border-radius:4px;padding:14px 16px;font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">
              <strong style="color:var(--page-maroon);">Honours GPA Gate:</strong> Most Honours programmes require a module average of 60–65% in CS modules. Your single most important GPA-protecting module is <strong>CS 214 Data Structures</strong> — treat it as the bottleneck it is.
            </div>
            <div style="background:var(--page-bg2);border-radius:4px;padding:14px 16px;font-family:'Raleway',sans-serif;font-size:1.06rem;line-height:1.65;color:var(--page-text2);">
              <strong style="color:var(--page-maroon);">Networking:</strong> Attend the annual SU CS Research Day (May), local tech meetups (Cape Town Deep Learning, Cape Town Security, Stellenbosch Dev Meetup), and virtual events (PyCon ZA, DevConf.ZA). LinkedIn with active posting from Year 2.
            </div>
          </div>
        </div>

        <div class="adv-cta-row">
          <button class="adv-cta-btn" onclick="advGoToGraph()">🕸 Highlight My Modules on Graph →</button>
          <button class="adv-cta-btn ghost" onclick="mOpenPage(6)">🔬 Research Groups →</button>
          <button class="adv-cta-btn ghost" onclick="mOpenPage(5)">📚 Course Catalogue →</button>
          <button class="adv-cta-btn ghost" onclick="mOpenPage(9)">👩‍💻 Student Hub →</button>
        </div>
      </div>
    </div>
  `;
  document.getElementById('advisor-result').scrollIntoView({behavior:'smooth',block:'start'});
};

window.advHighlightOnGraph=function(moduleCode){
  window._advisorHighlightIds=[moduleCode];
  mOpenPage(12);
  setTimeout(()=>advApplyGraphHighlight(),400);
};

window.advGoToGraph=function(){
  mOpenPage(12);
  setTimeout(()=>advApplyGraphHighlight(),400);
};

window.advApplyGraphHighlight=function(){
  if(!window._advisorHighlightIds||typeof d3==='undefined') return;
  const ids=new Set(window._advisorHighlightIds);
  // Also add prerequisites via GRAPH_LINKS
  let changed=true;
  while(changed){
    changed=false;
    GRAPH_LINKS.forEach(l=>{
      const tgt=l.target?.id||l.target;
      const src=l.source?.id||l.source;
      if(ids.has(tgt)&&!ids.has(src)){ids.add(src);changed=true;}
    });
  }
  const advisorColor='#caa258';
  const nodes=d3.selectAll('.graph-node circle');
  const links=d3.selectAll('#curr-graph-svg line');
  nodes.each(function(d){
    const inPath=ids.has(d.id);
    d3.select(this).attr('opacity',inPath?1:0.12)
      .attr('stroke',inPath?advisorColor:'rgba(202,162,88,0.15)')
      .attr('stroke-width',inPath?3.5:1)
      .style('filter',inPath?`drop-shadow(0 0 14px ${advisorColor})`:'none');
  });
  links.each(function(d){
    const srcId=d.source?.id||d.source;
    const tgtId=d.target?.id||d.target;
    const inPath=ids.has(srcId)&&ids.has(tgtId);
    d3.select(this).attr('opacity',inPath?0.95:0.04)
      .attr('stroke',inPath?advisorColor:'rgba(202,162,88,0.06)')
      .attr('stroke-width',inPath?2.5:1);
  });
  // Show notification
  const notif=document.createElement('div');
  notif.style.cssText='position:fixed;top:80px;right:20px;z-index:9999;background:var(--su-maroon);border:1px solid var(--su-gold);color:var(--su-gold);font-family:Share Tech Mono,monospace;font-size:0.75rem;padding:12px 18px;border-radius:4px;box-shadow:0 4px 20px rgba(0,0,0,0.5);animation:mBootFade 0.3s ease;';
  notif.textContent=`✓ Highlighting ${ids.size} recommended modules on graph`;
  document.body.appendChild(notif);
  setTimeout(()=>notif.remove(),3500);
};

/* ══════════════════════════════════════════════════
   CURRICULUM GRAPH (D3 Force)
   ══════════════════════════════════════════════════ */
