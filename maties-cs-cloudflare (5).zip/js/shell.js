/* ══════════════════════════════════════════════
   MATIES-OS — Shell: Terminal, Routing, Nav
   URL routing via History API for Cloudflare Pages
   ══════════════════════════════════════════════ */
'use strict';

/* ── TERMINAL ENGINE ── */
const termBody=document.getElementById('m-term-body');
function addLine(text,cls=''){
  return new Promise(resolve=>{
    const div=document.createElement('div');
    div.className='m-line '+cls;
    div.innerHTML=text;
    termBody.appendChild(div);
    termBody.scrollTop=termBody.scrollHeight;
    resolve(div);
  });
}

const menuItems=[
  {n:1,  v:'├── [01] Department Overview & Welcome'},
  {n:2,  v:'├── [02] Academic Staff & Faculty Profiles'},
  {n:3,  v:'├── [03] Publications & Research Output'},
  {n:4,  v:'├── [04] Programmes — Undergraduate & Postgraduate'},
  {n:5,  v:'├── [05] Course Catalogue / Module Listings'},
  {n:6,  v:'├── [06] Research Groups, Labs & Centres'},
  {n:7,  v:'├── [07] News, Announcements & Press Releases'},
  {n:8,  v:'├── [08] Events & Seminars Calendar'},
  {n:9,  v:'├── [09] Student Resources — FAQs, Forms & Links'},
  {n:10, v:'├── [10] Contact, Location & Directions'},
  {n:11, v:'├── [11] Degree Advisor — Smart Pathway Planner'},
  {n:12, v:'└── [12] Curriculum Prerequisite Graph'},
];

async function showMenu(){
  await addLine('');
  await addLine('┌──────────────────────────────────────────────────────────────┐','maroon');
  await addLine('│  STELLENBOSCH UNIVERSITY — DEPARTMENT OF COMPUTER SCIENCE     │','maroon');
  await addLine('│  Pursue. Discover. Together.                                  │','maroon');
  await addLine('└──────────────────────────────────────────────────────────────┘','maroon');
  await addLine('');
  await addLine('cs.sun.ac.za','bright');
  for(let i=0;i<menuItems.length;i++){
    const item=menuItems[i];
    await delay(80+i*20);
    const div=document.createElement('div');
    div.className='m-line selectable dim';
    // Split into tree prefix (non-clickable) and label text (clickable)
    const match = item.v.match(/^([├└─│\s]+)(\[.+)$/);
    if(match){
      const prefix = document.createTextNode(match[1]);
      const link = document.createElement('span');
      link.className = 'menu-link';
      link.textContent = match[2];
      link.addEventListener('click', () => mOpenPage(item.n));
      div.appendChild(prefix);
      div.appendChild(link);
    } else {
      div.textContent = item.v;
      div.addEventListener('click', () => mOpenPage(item.n));
    }
    termBody.appendChild(div);
    termBody.scrollTop=termBody.scrollHeight;
  }
  await addLine('');
  await addLine('─── Type [01–10] · "help" · Tab to autocomplete ───────────────','cyan');
  await addLine('─── "light" / "dark" to change theme · ESC returns to terminal ','cyan');
  await addLine('');
}

/* ── COMMAND HANDLER ── */
const pageAliases={
  'overview':1,'welcome':1,'about':1,'home':1,
  'staff':2,'faculty':2,'people':2,'professors':2,
  'publications':3,'papers':3,'pubs':3,'research':3,'output':3,
  'programmes':4,'programs':4,'degrees':4,'postgrad':4,'undergrad':4,
  'courses':5,'catalogue':5,'modules':5,'catalog':5,
  'labs':6,'groups':6,'centres':6,'centers':6,
  'news':7,'announcements':7,'press':7,
  'events':8,'seminars':8,'calendar':8,
  'resources':9,'students':9,'faq':9,'faqs':9,'forms':9,
  'contact':10,'location':10,'directions':10,'map':10,
  'advisor':11,'advice':11,'planner':11,'pathway':11,'plan':11,
  'graph':12,'curriculum':12,'prerequisites':12,'prereq':12,'network':12,
};
function resolvePageNum(cmd){
  const c=cmd.trim().toLowerCase().replace(/^(cd|open|go|cat|goto|nav)\s+/,'');
  const n=parseInt(c);if(!isNaN(n)&&n>=1&&n<=12)return n;
  if(pageAliases[c])return pageAliases[c];
  for(const key of Object.keys(pageAliases)){if(key.startsWith(c)&&c.length>=3)return pageAliases[key];}
  return null;
}

const cmdHistory=[];let histIdx=-1;
const promptInput=document.getElementById('m-prompt-input');
const hintEl=document.getElementById('m-autocomplete');
const bootTime=new Date();

const allCmds=['help','menu','clear','cls','ls','date','time','uptime','whoami','pwd','history','theme','light','dark','sudo hackathon',
  'cd overview','cd staff','cd publications','cd programmes','cd courses','cd labs','cd news','cd events','cd resources','cd contact','cd advisor','cd graph',
  '1','2','3','4','5','6','7','8','9','10','11','12'];

function getAutocomplete(val){
  if(!val||val.length<1)return '';
  return allCmds.find(c=>c.startsWith(val.toLowerCase())&&c!==val.toLowerCase())||'';
}

promptInput.addEventListener('keydown',e=>{
  if(e.key==='Enter'){
    const val=promptInput.value.trim();
    if(val){cmdHistory.unshift(val);histIdx=-1;}
    promptInput.value='';hintEl.textContent='';
    handleCommand(val);
  }else if(e.key==='ArrowUp'){e.preventDefault();if(histIdx<cmdHistory.length-1){histIdx++;promptInput.value=cmdHistory[histIdx];}}
  else if(e.key==='ArrowDown'){e.preventDefault();if(histIdx>0){histIdx--;promptInput.value=cmdHistory[histIdx];}else{histIdx=-1;promptInput.value='';}}
  else if(e.key==='Tab'){e.preventDefault();const hint=getAutocomplete(promptInput.value);if(hint)promptInput.value=hint;hintEl.textContent='';}
});
promptInput.addEventListener('input',()=>{
  const v=promptInput.value;
  hintEl.textContent=getAutocomplete(v)?getAutocomplete(v).slice(v.length):'';
});

async function handleCommand(cmd){
  if(!cmd)return;
  await addLine(`cs@sun:~$ ${cmd}`,'dim');
  const lower=cmd.trim().toLowerCase();
  if(lower==='date'||lower==='time'){
    const now=new Date();
    await addLine(now.toLocaleDateString('en-ZA',{weekday:'long',year:'numeric',month:'long',day:'numeric'})+'  '+now.toLocaleTimeString('en-ZA')+'  [SAST]','green');return;
  }
  if(lower==='uptime'){
    const secs=Math.floor((new Date()-bootTime)/1000);const m=Math.floor(secs/60),s=secs%60;
    await addLine(` up ${m}m ${s}s,  1 user,  load: 0.42`,'green');return;
  }
  if(lower==='history'){cmdHistory.forEach((c,i)=>addLine(`  ${String(cmdHistory.length-i).padStart(3)}  ${c}`,'dim'));return;}
  if(lower==='theme'||lower==='theme toggle'){mToggleTheme();const isL=R.classList.contains('light-mode');await addLine(`Theme: ${isL?'LIGHT':'DARK'} mode. Type "${isL?'dark':'light'}" to revert.`,isL?'bright':'green');return;}
  if(lower==='light'||lower==='theme light'){mToggleTheme(false);await addLine('☀️  Switched to LIGHT mode.','bright');return;}
  if(lower==='dark'||lower==='theme dark'){mToggleTheme(true);await addLine('🌙  Switched to DARK mode.','green');return;}
  if(lower==='whoami'){await addLine('visitor@cs.sun.ac.za','green');return;}
  if(lower==='pwd'){await addLine('/cs/sun.ac.za/public','green');return;}
  if(lower==='help'||lower==='?'){
    const lines=[
      '┌──────────────────────────────────────────────────────────┐',
      '│  MATIES-OS COMMANDS                                        │',
      '├──────────────────────────────────────────────────────────┤',
      '│  1–10 / 01–10    Open page by number                     │',
      '│  cd <page>       cd staff, cd events, cd pubs …          │',
      '│  ls              List all pages                           │',
      '│  menu            Redisplay navigation tree                │',
      '│  clear / cls     Clear terminal                           │',
      '│  date / time     Current date and time (SAST)             │',
      '│  uptime          Session uptime since page load           │',
      '│  history         Show command history                     │',
      '│  light / dark    Switch colour theme                      │',
      '│  theme           Toggle light / dark mode                 │',
      '│  whoami / pwd    Current user / directory                 │',
      '│  Tab             Autocomplete command                     │',
      '│  ↑↓ arrows       Navigate command history                 │',
      '│  ESC             Return to terminal from page view        │',
      '└──────────────────────────────────────────────────────────┘',
    ];
    for(const l of lines)await addLine(l,l.includes('│')&&!l.includes('┌')&&!l.includes('└')&&!l.includes('COMMANDS')&&!l.includes('──')?'cyan':'maroon');
    return;
  }
  if(lower==='menu'){await showMenu();return;}
  if(lower==='clear'||lower==='cls'){termBody.innerHTML='';await showMenu();return;}
  if(lower==='sudo hackathon'||lower==='hackathon'){triggerHackathon();await addLine('🏆 [ACHIEVEMENT UNLOCKED] sudo hackathon — Welcome to hackathon mode!','green');return;}
  if(lower==='ls'||lower==='ls -la'||lower==='dir'){
    const now=new Date();const ds=now.toLocaleDateString('en-ZA',{day:'2-digit',month:'short'});
    await addLine('total 10','dim');
    for(const[n,p]of Object.entries(pages)){
      const live=[1,2,3,6].includes(Number(n))?'  [LIVE]':'';
      await addLine(`drwxr-xr-x  ${String(n).padStart(2,'0')}_${p.label.toLowerCase().replace(/ /g,'_')}  ${ds}  ${p.fullLabel}${live}`,'green');
    }
    return;
  }
  const resolved=resolvePageNum(cmd);
  if(resolved){await addLine(`Opening [${String(resolved).padStart(2,'0')}] ${pages[resolved].fullLabel}…`,'green');await delay(110);triggerGlitch();mOpenPage(resolved);return;}
  await addLine(`bash: ${cmd}: command not found`,'red');
  await addLine('Type "help" for commands, or a number 1–10 to open a page.','dim');
}

/* ── PAGE VIEW ── */
const pageView=document.getElementById('m-page');
const pageContent=document.getElementById('m-content');
const terminal=document.getElementById('m-terminal');
const navBar=document.getElementById('m-nav-bar');
const breadcrumb=document.getElementById('m-breadcrumb');
const search=document.getElementById('m-search');
let currentPage=null;

/* NAV_ICONS defined in data.js */
function buildNavBar(active){
  navBar.innerHTML=Object.entries(pages).map(([n,p])=>{
    const slug = PAGE_ROUTES[n] || n;
    return `<a class="m-nav-btn ${Number(n)===active?'active':''}" href="/${slug}" onclick="mOpenPage(${n});return false;" title="${p.fullLabel||p.label}" role="button"><span class="m-nav-icon">${NAV_ICONS[n]||'📁'}</span><span class="m-nav-label">${p.label}</span></a>`;
  }).join('');
}

/* ── URL Routing ── */
const _canPushState = (function() {
  try {
    return window.self === window.top &&
           window.location.protocol !== 'about:' &&
           typeof history.pushState === 'function';
  } catch(e) { return false; }
})();

function _updateURL(n) {
  const slug = PAGE_ROUTES[n];
  if (!slug) return;
  const meta = PAGE_META[n] || {};
  const title = (meta.title ? meta.title + ' — ' : '') + 'CS Department, Stellenbosch University';
  document.title = title;
  let descEl = document.querySelector('meta[name="description"]');
  if (descEl && meta.desc) descEl.setAttribute('content', meta.desc);
  if (!_canPushState) return;
  const url = '/' + slug;
  if (window.location.pathname !== url) {
    try { history.pushState({ page: n }, title, url); } catch(e) { /* iframe/srcdoc context */ }
  }
}

function mOpenPage(n, _pushState=true){
  const page=pages[n];if(!page)return;
  currentPage=n;
  pageContent.innerHTML=page.render();
  buildNavBar(n);
  const slug = PAGE_ROUTES[n] || n;
  breadcrumb.innerHTML=`<span>/</span> <a href="/" onclick="mClosePage();return false;" style="color:inherit;text-decoration:none;">cs.sun.ac.za</a> <span>/</span> ${slug}`;
  pageView.classList.add('visible');
  terminal.classList.add('hidden');
  triggerGlitch();
  pageContent.scrollTop=0;
  if(_pushState) _updateURL(n);
  if(page.onMount)setTimeout(page.onMount,60);
}
window.mOpenPage=mOpenPage;

function mClosePage(){
  pageView.classList.remove('visible');
  terminal.classList.remove('hidden');
  triggerGlitch();
  if (_canPushState) {
    try { history.pushState({page:null}, 'Computer Science — Stellenbosch University', '/'); } catch(e) {}
  }
  document.title = 'Computer Science — Stellenbosch University';
  // If terminal is empty (e.g. deep-linked on refresh), populate it now
  if (!termBody.hasChildNodes()) {
    (async () => { await showMenu(); showPrompt(); })();
  }
  setTimeout(()=>promptInput.focus(),400);
}
window.mClosePage=mClosePage;

/* Handle browser back/forward */
window.addEventListener('popstate', e => {
  const n = e.state && e.state.page;
  if (n && pages[n]) {
    mOpenPage(n, false);
  } else {
    pageView.classList.remove('visible');
    terminal.classList.remove('hidden');
    // Ensure terminal has content when navigating back
    if (!termBody.hasChildNodes()) {
      (async () => { await showMenu(); showPrompt(); })();
    }
  }
});

/* Deep-link: open page from URL on load */
function _resolveDeepLink() {
  const path = window.location.pathname.replace(/^\//, '').replace(/\/$/, '');
  if (!path) return null;
  // Try slug match
  const num = ROUTE_TO_NUM[path];
  if (num) return num;
  // Try numeric
  const n = parseInt(path);
  if (!isNaN(n) && pages[n]) return n;
  return null;
}
window._resolveDeepLink = _resolveDeepLink;


/* In-page search */
search.addEventListener('input',()=>{
  const q=search.value.trim();
  pageContent.querySelectorAll('.m-search-hl').forEach(el=>{el.outerHTML=el.textContent;});
  if(!q||q.length<2)return;
  const walker=document.createTreeWalker(pageContent,NodeFilter.SHOW_TEXT);
  const matches=[];let node;
  while(node=walker.nextNode()){if(node.textContent.toLowerCase().includes(q.toLowerCase())&&!['SCRIPT','STYLE','INPUT'].includes(node.parentElement.tagName))matches.push(node);}
  matches.slice(0,30).forEach(n=>{
    const re=new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')})`,'gi');
    const sp=document.createElement('span');
    sp.innerHTML=n.textContent.replace(re,'<mark class="m-search-hl">$1</mark>');
    n.parentNode.replaceChild(sp,n);
  });
  const first=pageContent.querySelector('.m-search-hl');
  if(first)first.scrollIntoView({behavior:'smooth',block:'center'});
});

/* Pub filter */
window.mFilterPubs=async function(type,btn){
  document.querySelectorAll('#mpub-filter .m-nav-btn, .pg-sidebar-link').forEach(b=>b.classList.remove('active'));
  if(btn) btn.classList.add('active');
  const container=document.getElementById('mpubs-live');
  container.innerHTML=`<div class="m-loading"><div class="m-spinner"></div>Fetching publications…</div>`;
  const topicMap={
    recent:ALEX_BASE+'&sort=publication_date:desc&per-page=10&select=title,authorships,primary_location,publication_year,doi,cited_by_count,primary_topic',
    cited:ALEX_BASE+'&sort=cited_by_count:desc&per-page=10&select=title,authorships,primary_location,publication_year,doi,cited_by_count,primary_topic',
    ai:'https://api.openalex.org/works?filter=authorships.institutions.id:I26092322,title.search:machine+learning|deep+learning|neural+network|artificial+intelligence&sort=publication_date:desc&per-page=10&select=title,authorships,primary_location,publication_year,doi,cited_by_count,primary_topic',
    security:'https://api.openalex.org/works?filter=authorships.institutions.id:I26092322,title.search:cybersecurity|cryptography|security|malware|post-quantum&sort=publication_date:desc&per-page=10&select=title,authorships,primary_location,publication_year,doi,cited_by_count,primary_topic',
    bio:'https://api.openalex.org/works?filter=authorships.institutions.id:I26092322,title.search:bioinformatics|genomics|proteomics|computational+biology&sort=publication_date:desc&per-page=10&select=title,authorships,primary_location,publication_year,doi,cited_by_count,primary_topic',
  };
  await fetchPubs(topicMap[type]||topicMap.recent,'mpubs-live',10,true);
};

/* Keyboard shortcuts */
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){
    if(document.getElementById('m-modal').classList.contains('open')){mCloseModal();return;}
    if(pageView.classList.contains('visible')){mClosePage();return;}
  }
  if(['INPUT','TEXTAREA'].includes(document.activeElement.tagName))return;
  const k=parseInt(e.key);
  if(!isNaN(k)&&k>=1&&k<=9&&!e.ctrlKey&&!e.metaKey){mOpenPage(k);triggerGlitch();}
  if(e.key==='0'&&!e.ctrlKey&&!e.metaKey){mOpenPage(10);triggerGlitch();}
  if((e.key==='?'||e.key==='/')&&!pageView.classList.contains('visible')){promptInput.focus();promptInput.value='help';}
});

/* ── SHOW PROMPT ── */
function showPrompt(){
  const pa=document.getElementById('m-prompt-area');
  if(pa) pa.style.display='flex';
  setTimeout(()=>{ if(promptInput) promptInput.focus(); },100);
}

/* ── BOOT SEQUENCE ── */

/* ══ CHART.JS VISUALISATIONS ══ */
const PROG_DATA=[
  {label:'BSc CS',     nsc:65,duration:3,nqf:7, color:'#61223b'},
  {label:'BDatSci',   nsc:80,duration:4,nqf:7, color:'#1a3a70'},
  {label:'BScHons',   nsc:72,duration:1,nqf:8, color:'#a07a30'},
  {label:'MSc',       nsc:75,duration:2,nqf:9, color:'#1a6040'},
  {label:'MEng',      nsc:73,duration:2,nqf:9, color:'#dc4405'},
  {label:'PhD',       nsc:80,duration:4,nqf:10,color:'#420f27'},
];
let _progChart=null,_resChart=null;
function _chartColors(){
  const dark=!document.getElementById('MATIES-root').classList.contains('light-mode');
  return {text:dark?'#caa258':'#61223b',grid:dark?'rgba(202,162,88,0.12)':'rgba(97,34,59,0.1)'};
}
function initProgChart(){
  const el=document.getElementById('prog-chart');
  if(!el||typeof Chart==='undefined')return;
  if(_progChart){_progChart.destroy();_progChart=null;}
  const {text,grid}=_chartColors();
  _progChart=new Chart(el,{
    type:'bubble',
    data:{datasets:PROG_DATA.map(p=>({
      label:p.label,
      data:[{x:p.duration,y:p.nsc,r:p.nqf*2.8}],
      backgroundColor:p.color+'bb',borderColor:p.color,borderWidth:2
    }))},
    options:{
      responsive:true,maintainAspectRatio:false,
      plugins:{
        legend:{display:true,position:'right',labels:{color:text,font:{family:'Raleway',size:11},padding:6}},
        tooltip:{callbacks:{label:d=>{const p=PROG_DATA.find(x=>x.label===d.dataset.label);return p?`${p.label}: NSC≥${p.nsc}%, ${p.duration}yr, NQF${p.nqf}`:'';}}},
      },
      scales:{
        x:{title:{display:true,text:'Duration (years)',color:text,font:{family:'Raleway',size:11}},ticks:{color:text,stepSize:1},grid:{color:grid},min:0,max:5.5},
        y:{title:{display:true,text:'Min NSC %',color:text,font:{family:'Raleway',size:11}},ticks:{color:text},grid:{color:grid},min:55,max:88}
      }
    }
  });
}
function updateProgChart(val){
  const el=document.getElementById('nsc-val');
  if(el)el.textContent=val+'%';
  if(!_progChart||typeof Chart==='undefined')return;
  const n=Number(val);
  _progChart.data.datasets=PROG_DATA.filter(p=>p.nsc>=n).map(p=>({
    label:p.label,data:[{x:p.duration,y:p.nsc,r:p.nqf*2.8}],
    backgroundColor:p.color+'bb',borderColor:p.color,borderWidth:2
  }));
  _progChart.update();
}
function initResearchChart(){
  const el=document.getElementById('research-trends-chart');
  if(!el||typeof Chart==='undefined')return;
  if(_resChart){_resChart.destroy();_resChart=null;}
  const {text,grid}=_chartColors();
  _resChart=new Chart(el,{
    type:'line',
    data:{
      labels:['2019','2020','2021','2022','2023','2024'],
      datasets:[
        {label:'Publications',data:[52,58,61,65,68,70],borderColor:'#61223b',backgroundColor:'rgba(97,34,59,0.1)',tension:0.4,fill:true,pointRadius:4},
        {label:'Citations (×10)',data:[38,45,54,60,68,75],borderColor:'#caa258',backgroundColor:'rgba(202,162,88,0.08)',tension:0.4,fill:true,pointRadius:4},
        {label:'Intl. Collaborations',data:[8,10,12,14,17,19],borderColor:'#82CCAE',backgroundColor:'rgba(130,204,174,0.08)',tension:0.4,fill:true,pointRadius:4},
      ]
    },
    options:{
      responsive:true,maintainAspectRatio:false,
      plugins:{legend:{labels:{color:text,font:{family:'Raleway',size:11}}}},
      scales:{
        x:{ticks:{color:text},grid:{color:grid}},
        y:{ticks:{color:text},grid:{color:grid},min:0}
      }
    }
  });
}

/* ══ BOOT SEQUENCE ══ */
const BOOT_MSGS = [
  {t:200, txt:'[    0.001] MATIES-OS kernel loading...', cls:'info'},
  {t:400, txt:'[    0.048] CPU: Cortex-A72 × 8 @ 3.2GHz', cls:'info'},
  {t:620, txt:'[    0.112] Memory: 32768MB DDR5 ECC ✓', cls:'ok'},
  {t:840, txt:'[    0.201] Storage: NVMe SSD 2TB ✓', cls:'ok'},
  {t:1060,txt:'[    0.298] Network: 10GbE SU Campus Link ✓', cls:'ok'},
  {t:1300,txt:'[    0.445] Loading CS dept academic database...', cls:'info'},
  {t:1550,txt:'[    0.612] Curriculum graph: 47 nodes, 89 edges ✓', cls:'ok'},
  {t:1800,txt:'[    0.789] Research groups: 18 active ✓', cls:'ok'},
  {t:2100,txt:'[    0.934] Staff directory: 42 academics ✓', cls:'ok'},
  {t:2400,txt:'[    1.102] News feed: 3 unread items ✓', cls:'ok'},
  {t:2700,txt:'[    1.298] Publications index: 847 entries ✓', cls:'ok'},
  {t:3000,txt:'[    1.445] Booting MATIES-OS interface...', cls:'info'},
  {t:3300,txt:'[    1.601] All systems nominal. Welcome, Matie! 🎓', cls:'ok'},
];

const PROGRESS_STEPS = [
  {t:200,  pct:5,  label:'Kernel init...'},
  {t:600,  pct:18, label:'Hardware check...'},
  {t:1000, pct:32, label:'Loading databases...'},
  {t:1500, pct:50, label:'Academic data...'},
  {t:2000, pct:68, label:'Research index...'},
  {t:2500, pct:82, label:'Publications...'},
  {t:3000, pct:93, label:'Finalising...'},
  {t:3400, pct:100,label:'Complete!'},
];

function runBoot() {
  const msgContainer = document.getElementById('boot-msgs');
  const progressFill = document.getElementById('boot-progress-fill');
  const progressLabel = document.getElementById('boot-progress-label');
  const progressPct = document.getElementById('boot-progress-pct');
  const boot = document.getElementById('m-boot');

  // Skip to terminal immediately
  function finishBoot(){
    if(boot._done) return;
    boot._done = true;
    boot.classList.add('fade-out');
    setTimeout(async () => {
      boot.style.display = 'none';
      scheduleGlitch();
      document.getElementById('m-crt-beam').classList.add('crt-ready');
      document.getElementById('m-crt-page-beam').classList.add('crt-ready');
      await delay(120);

      // ── Always populate terminal so it's ready when user returns ──
      const now = new Date();
      const pad = n => String(n).padStart(2,'0');
      await addLine('MATIES-OS v4.3.0 LTS — Stellenbosch University Kernel','dim');
      await addLine('Copyright (c) 2025 Stellenbosch University — Dept of Computer Science','dim');
      await addLine('Pursue. Discover. Together.','dim');
      await addLine('');
      await addLine('Last login: '+now.toDateString()+' '+pad(now.getHours())+':'+pad(now.getMinutes())+':'+pad(now.getSeconds()),'dim');
      await addLine('');
      await showMenu();
      showPrompt();

      // ── Deep-link: if URL points to a page, open it on top ──
      const deepPage = _resolveDeepLink();
      if (deepPage) {
        mOpenPage(deepPage, false);
        if (_canPushState) {
          try { history.replaceState({ page: deepPage }, document.title, window.location.pathname); } catch(e) {}
        }
      }
    }, 500);
  }

  // Skip button
  const skipBtn = document.createElement('button');
  skipBtn.textContent = 'SKIP →';
  skipBtn.style.cssText = 'position:absolute;bottom:28px;right:32px;background:transparent;border:1px solid rgba(202,162,88,0.25);color:rgba(202,162,88,0.45);font-family:Share Tech Mono,monospace;font-size:0.68rem;letter-spacing:0.1em;padding:6px 14px;cursor:pointer;border-radius:2px;transition:all 0.2s;z-index:200;opacity:0;animation:fadeSlideUp 0.5s ease 1.2s forwards;';
  skipBtn.onmouseover = () => { skipBtn.style.borderColor='rgba(202,162,88,0.7)'; skipBtn.style.color='#caa258'; };
  skipBtn.onmouseout = () => { skipBtn.style.borderColor='rgba(202,162,88,0.25)'; skipBtn.style.color='rgba(202,162,88,0.45)'; };
  skipBtn.onclick = finishBoot;
  boot.appendChild(skipBtn);

  // Also skip on any keypress
  const skipKey = e => { if(!['INPUT','TEXTAREA'].includes(e.target.tagName)){ finishBoot(); document.removeEventListener('keydown',skipKey); }};
  document.addEventListener('keydown', skipKey);

  // Progress steps — tightened timing (was +2600 offset, now +800)
  const FAST_STEPS = [
    {t:100,  pct:8,  label:'Kernel init...'},
    {t:300,  pct:20, label:'Hardware check...'},
    {t:550,  pct:38, label:'Loading databases...'},
    {t:800,  pct:55, label:'Academic data...'},
    {t:1050, pct:72, label:'Research index...'},
    {t:1300, pct:88, label:'Publications...'},
    {t:1550, pct:96, label:'Finalising...'},
    {t:1800, pct:100,label:'Complete!'},
  ];
  FAST_STEPS.forEach(step => {
    setTimeout(() => {
      if(boot._done) return;
      progressFill.style.width = step.pct + '%';
      progressLabel.textContent = step.label;
      progressPct.textContent = step.pct + '%';
    }, step.t + 800);
  });

  // Boot messages — tightened timing
  const FAST_MSGS = [
    {t:200,  txt:'[    0.001] MATIES-OS kernel loading...',           cls:'info'},
    {t:450,  txt:'[    0.048] CPU: Cortex-A72 × 8 @ 3.2GHz',         cls:'info'},
    {t:650,  txt:'[    0.112] Memory: 32768MB DDR5 ECC ✓',            cls:'ok'},
    {t:850,  txt:'[    0.201] Storage: NVMe SSD 2TB ✓',               cls:'ok'},
    {t:1050, txt:'[    0.298] Network: 10GbE SU Campus Link ✓',        cls:'ok'},
    {t:1250, txt:'[    0.445] Curriculum graph: 47 nodes, 89 edges ✓', cls:'ok'},
    {t:1450, txt:'[    0.612] Staff directory: 42 academics ✓',        cls:'ok'},
    {t:1650, txt:'[    0.789] Publications index: 847 entries ✓',      cls:'ok'},
    {t:1850, txt:'[    1.102] Booting MATIES-OS interface...',          cls:'info'},
    {t:2050, txt:'[    1.298] All systems nominal. Welcome, Matie! 🎓', cls:'ok'},
  ];
  FAST_MSGS.forEach(msg => {
    setTimeout(() => {
      if(boot._done) return;
      const div = document.createElement('div');
      div.className = 'boot-msg ' + msg.cls;
      div.textContent = msg.txt;
      msgContainer.appendChild(div);
      msgContainer.scrollTop = msgContainer.scrollHeight;
    }, msg.t + 800);
  });

  // Auto-finish after ~3.2s total (was ~7s)
  setTimeout(finishBoot, 3200);
}

/* ══════════════════════════════════════════════════
   DEGREE ADVISOR LOGIC
   ══════════════════════════════════════════════════ */

function triggerHackathon(){
  // Strong glitch burst sequence
  const doGlitch=()=>{
    glitch.classList.remove('active','strong-glitch'); void glitch.offsetWidth;
    glitch.classList.add('active','strong-glitch');
    setTimeout(()=>glitch.classList.remove('active','strong-glitch'),400);
  };
  doGlitch();
  setTimeout(doGlitch,140);
  setTimeout(doGlitch,280);
  setTimeout(doGlitch,420);

  const overlay=document.getElementById('hackathon-overlay');
  overlay.classList.add('active');

  const stats=[
    {num:'72',lbl:'hours'},
    {num:'R5 000',lbl:'prize pool'},
    {num:'\u221e',lbl:'caffeine'},
  ];
  const grid=document.getElementById('hack-stats-grid');
  grid.innerHTML=stats.map((s,i)=>`
    <div class="hack-stat" style="animation-delay:${0.3+i*0.15}s">
      <span class="num">${s.num}</span><div class="lbl">${s.lbl}</div>
    </div>`).join('');

  // Confetti burst
  if(typeof confetti==='function'){
    const maroon='#61223b', gold='#caa258', green='#82CCAE';
    confetti({particleCount:120,spread:90,origin:{y:0.5},colors:[maroon,gold,green,'#ffffff']});
    setTimeout(()=>confetti({particleCount:60,spread:60,origin:{y:0.3},angle:45,colors:[gold,maroon]}),600);
    setTimeout(()=>confetti({particleCount:60,spread:60,origin:{y:0.3},angle:135,colors:[green,gold]}),900);
  }

  document.addEventListener('keydown',closeHackathon,{once:true});
}
window.triggerHackathon=triggerHackathon;

function closeHackathon(){
  document.getElementById('hackathon-overlay').classList.remove('active');
  document.removeEventListener('keydown',closeHackathon);
}
window.closeHackathon=closeHackathon;

/* ── App Entry Point ── */
// After boot, check for deep-link and open the matching page
const _origFinishBoot = typeof finishBoot !== 'undefined' ? finishBoot : null;
function runBootWithRouting() {
  runBoot();
}
runBootWithRouting();
