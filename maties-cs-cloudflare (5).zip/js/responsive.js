/* ══════════════════════════════════════════════════════════════════════
   MATIES-OS — Adaptive Responsive Engine  v1.0
   Detects device class, orientation, screen DPR, safe-area insets,
   applies data-attributes to #MATIES-root so CSS can react instantly,
   and re-initialises dynamic components (graph, charts) on resize.
   ══════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  const R = document.getElementById('MATIES-root');
  if (!R) return;

  /* ── 1. BREAKPOINT DEFINITIONS ────────────────────────────────────── */
  const BP = {
    xs:  479,   // phone portrait
    sm:  767,   // phone landscape / small tablet
    md:  1023,  // tablet
    lg:  1279,  // small desktop
    xl:  1535,  // desktop
    // xl+ = large desktop
  };

  /* ── 2. DEVICE CAPABILITY DETECTION ──────────────────────────────── */
  function detectDevice() {
    const w   = window.innerWidth;
    const h   = window.innerHeight;
    const dpr = window.devicePixelRatio || 1;
    const ua  = navigator.userAgent || '';
    const touch   = navigator.maxTouchPoints > 0 || 'ontouchstart' in window;
    const coarse  = window.matchMedia('(pointer: coarse)').matches;
    const hover   = window.matchMedia('(hover: hover)').matches;
    const landscape = w > h;
    const portrait  = !landscape;

    // Device class
    let deviceClass = 'desktop';
    if (w <= BP.xs)                    deviceClass = 'phone-xs';
    else if (w <= BP.sm)               deviceClass = 'phone';
    else if (w <= BP.md)               deviceClass = 'tablet';
    else if (w <= BP.lg)               deviceClass = 'laptop';
    else if (w <= BP.xl)               deviceClass = 'desktop';
    else                               deviceClass = 'wide';

    // Breakpoint tier for CSS
    let tier = 'xl';
    if (w <= BP.xs)       tier = 'xs';
    else if (w <= BP.sm)  tier = 'sm';
    else if (w <= BP.md)  tier = 'md';
    else if (w <= BP.lg)  tier = 'lg';

    // Detect foldable/split screen (very wide + touch)
    const foldable = touch && w >= 600 && w <= BP.md && dpr >= 2;

    // Detect notch / dynamic island (safe area env vars)
    const safeTop    = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--sat') || '0');
    const safeBottom = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--sab') || '0');
    const hasNotch   = safeTop > 20 || safeBottom > 20;

    // Detect high-DPR (retina) display
    const retina = dpr >= 2;

    // Reduced motion preference
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Dark/light OS preference
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    return { w, h, dpr, touch, coarse, hover, landscape, portrait,
             deviceClass, tier, foldable, hasNotch, retina,
             reducedMotion, prefersDark };
  }

  /* ── 3. APPLY DATA-ATTRIBUTES & CSS CUSTOM PROPERTIES ─────────────── */
  function applyToRoot(d) {
    // Data attributes — CSS selectors can use [data-tier="sm"] etc.
    R.setAttribute('data-tier',    d.tier);
    R.setAttribute('data-device',  d.deviceClass);
    R.setAttribute('data-orient',  d.landscape ? 'landscape' : 'portrait');
    R.setAttribute('data-touch',   d.touch  ? 'true' : 'false');
    R.setAttribute('data-retina',  d.retina ? 'true' : 'false');
    R.setAttribute('data-notch',   d.hasNotch ? 'true' : 'false');
    R.setAttribute('data-fold',    d.foldable ? 'true' : 'false');

    // CSS custom properties for fluid use in stylesheets
    R.style.setProperty('--vw',  d.w + 'px');
    R.style.setProperty('--vh',  d.h + 'px');
    R.style.setProperty('--dpr', d.dpr);

    // Safe-area passthrough
    R.style.setProperty('--safe-top',    'env(safe-area-inset-top, 0px)');
    R.style.setProperty('--safe-bottom', 'env(safe-area-inset-bottom, 0px)');
    R.style.setProperty('--safe-left',   'env(safe-area-inset-left, 0px)');
    R.style.setProperty('--safe-right',  'env(safe-area-inset-right, 0px)');

    // Fluid spacing scale based on viewport width
    const base = Math.max(14, Math.min(18, 14 + (d.w - 320) / 100));
    R.style.setProperty('--fluid-base', base + 'px');

    // Page padding: tighter on small screens
    const pagePadH = d.w <= BP.xs  ? 12
                   : d.w <= BP.sm  ? 16
                   : d.w <= BP.md  ? 24
                   : d.w <= BP.lg  ? 40
                   : 80;
    const pagePadV = d.w <= BP.xs  ? 14
                   : d.w <= BP.sm  ? 20
                   : d.w <= BP.md  ? 32
                   : 52;
    R.style.setProperty('--page-pad-h', pagePadH + 'px');
    R.style.setProperty('--page-pad-v', pagePadV + 'px');

    // Nav height: smaller on phones
    const navH = d.w <= BP.xs ? 48
               : d.w <= BP.sm ? 54
               : d.w <= BP.md ? 62
               : 72;
    R.style.setProperty('--nav-h', navH + 'px');

    // Topbar height
    const topH = d.w <= BP.xs ? 48
               : d.w <= BP.sm ? 52
               : 58;
    R.style.setProperty('--topbar-h', topH + 'px');

    // Card grid min width
    const cardMin = d.w <= BP.xs ? '140px'
                  : d.w <= BP.sm ? '160px'
                  : d.w <= BP.md ? '200px'
                  : '260px';
    R.style.setProperty('--card-min', cardMin);

    // Graph container height: fill remaining screen after topbar+nav
    const graphH = Math.max(300, d.h - topH - navH - 140);
    R.style.setProperty('--graph-h', graphH + 'px');

    // Modal max height
    const modalH = d.w <= BP.xs ? '95svh' : d.w <= BP.sm ? '88svh' : '86vh';
    R.style.setProperty('--modal-max-h', modalH);
  }

  /* ── 4. BODY CLASS SYNC ───────────────────────────────────────────── */
  function syncBodyClass(d) {
    const classes = ['is-xs','is-sm','is-md','is-lg','is-xl','is-wide',
                     'is-phone','is-tablet','is-desktop','is-touch',
                     'is-portrait','is-landscape','is-notch'];
    classes.forEach(c => document.body.classList.remove(c));

    document.body.classList.add('is-' + d.tier);
    if (d.touch)     document.body.classList.add('is-touch');
    if (d.landscape) document.body.classList.add('is-landscape');
    else             document.body.classList.add('is-portrait');
    if (d.hasNotch)  document.body.classList.add('is-notch');
    if (d.w <= BP.sm) document.body.classList.add('is-phone');
    else if (d.w <= BP.md) document.body.classList.add('is-tablet');
    else             document.body.classList.add('is-desktop');
  }

  /* ── 5. GRAPH RE-INITIALISE ON RESIZE ────────────────────────────── */
  let _graphReinit = null;
  function scheduleGraphReinit() {
    clearTimeout(_graphReinit);
    _graphReinit = setTimeout(() => {
      if (typeof window.initCurrGraph === 'function') {
        const container = document.getElementById('curr-graph-container');
        if (container && container.offsetParent !== null) {
          window.initCurrGraph();
        }
      }
    }, 250);
  }

  /* ── 6. CHART RE-RENDER ON RESIZE ────────────────────────────────── */
  let _chartReinit = null;
  function scheduleChartReinit() {
    clearTimeout(_chartReinit);
    _chartReinit = setTimeout(() => {
      if (typeof Chart !== 'undefined') {
        Chart.instances && Object.values(Chart.instances).forEach(c => {
          try { c.resize(); } catch(e) {}
        });
      }
    }, 300);
  }

  /* ── 7. MOBILE INPUT ZOOM PREVENTION ─────────────────────────────── */
  function fixInputZoom(d) {
    // On iOS, inputs with font-size < 16px cause auto-zoom. We patch it.
    if (!d.touch) return;
    const inputs = document.querySelectorAll('input, textarea, select');
    inputs.forEach(el => {
      const fs = parseFloat(getComputedStyle(el).fontSize);
      if (fs < 16) el.style.fontSize = '16px';
    });
  }

  /* ── 8. VIRTUAL VIEWPORT HEIGHT FIX (iOS Safari 100vh bug) ───────── */
  function fixVH() {
    // iOS Safari counts the address bar in 100vh — use innerHeight instead
    const realVH = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--real-vh', realVH + 'px');
  }

  /* ── 9. ORIENTATION CHANGE HANDLER ───────────────────────────────── */
  function handleOrientationChange() {
    // Wait for browser to finish rotating
    setTimeout(() => {
      run();
      fixVH();
      scheduleGraphReinit();
    }, 150);
  }

  /* ── 10. SCROLL PERFORMANCE ON MOBILE ────────────────────────────── */
  function optimiseScroll(d) {
    const content = document.getElementById('m-content');
    if (!content) return;
    if (d.touch) {
      content.style.webkitOverflowScrolling = 'touch';
      content.style.overscrollBehavior = 'contain';
    }
  }

  /* ── 11. MAIN RUN FUNCTION ────────────────────────────────────────── */
  function run() {
    const d = detectDevice();
    applyToRoot(d);
    syncBodyClass(d);
    fixVH();
    optimiseScroll(d);
    // Debounced side-effects
    scheduleGraphReinit();
    scheduleChartReinit();
    // Fix inputs after a tick (page content may not be rendered yet)
    requestAnimationFrame(() => fixInputZoom(d));
  }

  /* ── 12. EVENT LISTENERS ──────────────────────────────────────────── */
  let _resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(_resizeTimer);
    _resizeTimer = setTimeout(run, 80); // debounce — don't thrash on every px
  }, { passive: true });

  window.addEventListener('orientationchange', handleOrientationChange, { passive: true });

  // Also handle screen.orientation API where available
  if (screen.orientation) {
    screen.orientation.addEventListener('change', handleOrientationChange, { passive: true });
  }

  // MutationObserver: re-run fixInputZoom when new pages are injected into #m-content
  const contentEl = document.getElementById('m-content');
  if (contentEl) {
    const mo = new MutationObserver(() => {
      const d = detectDevice();
      if (d.touch) {
        requestAnimationFrame(() => fixInputZoom(d));
      }
    });
    mo.observe(contentEl, { childList: true, subtree: false });
  }

  /* ── 13. EXPOSE PUBLICLY ──────────────────────────────────────────── */
  window.MatiesResponsive = {
    run,
    detect: detectDevice,
    BP,
  };

  /* ── 14. INITIAL RUN ──────────────────────────────────────────────── */
  run();

})();
