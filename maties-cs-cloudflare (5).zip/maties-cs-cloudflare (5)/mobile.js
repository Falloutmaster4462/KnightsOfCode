/* ═══════════════════════════════════════════════════════════════════════
   MATIES-OS — Mobile Enhancement v3.0
   - Zero layout thrash: reads batched before writes
   - rAF-gated scroll handlers (no runaway listeners)
   - Single mOpenPage wrapper (not triple-chained)
   - Pointer Events API for lag-free pinch zoom
   - non-passive touchmove only where strictly needed
   - Minimal DOM mutation, no getComputedStyle in hot paths
   ═══════════════════════════════════════════════════════════════════════ */
'use strict';

/* ─── DEVICE CAPS ────────────────────────────────────────────────────── */
const MOB = {
  touch: navigator.maxTouchPoints > 0,
  small: () => window.innerWidth <= 768,
  reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches,
};

/* ─── SINGLE mOpenPage WRAPPER ───────────────────────────────────────── */
// Wrap ONCE. All features hook into _onPageOpen, not mOpenPage itself.
const _pageOpenCbs = [];
const _origOpen = window.mOpenPage;
window.mOpenPage = function(n, pushState) {
  const prev = window._mobCurrentPage;
  window._mobCurrentPage = n;
  const r = _origOpen ? _origOpen(n, pushState) : undefined;
  _pageOpenCbs.forEach(fn => fn(n, prev));
  return r;
};
function _onPageOpen(fn) { _pageOpenCbs.push(fn); }

/* ─── 1. VIRTUAL KEYBOARD ────────────────────────────────────────────── */
if (MOB.touch && window.visualViewport) {
  const vv         = window.visualViewport;
  const termBody   = document.getElementById('m-term-body');
  const promptArea = document.getElementById('m-prompt-area');
  let vvTick = false;

  vv.addEventListener('resize', () => {
    if (vvTick) return;
    vvTick = true;
    requestAnimationFrame(() => {
      vvTick = false;
      const kbH = window.innerHeight - vv.height;
      if (kbH > 100) {
        if (promptArea) {
          promptArea.style.transition = 'transform 0.18s ease';
          promptArea.style.transform  = `translateY(-${kbH}px)`;
        }
        if (termBody) {
          termBody.style.maxHeight = `${vv.height - 96}px`;
          requestAnimationFrame(() => { termBody.scrollTop = termBody.scrollHeight; });
        }
      } else {
        if (promptArea) { promptArea.style.transition = 'transform 0.18s ease'; promptArea.style.transform = ''; }
        if (termBody)   termBody.style.maxHeight = '';
      }
    });
  }, { passive: true });
}

/* ─── 2. SWIPE NAVIGATION ────────────────────────────────────────────── */
(function() {
  if (!MOB.touch) return;
  const pageView = document.getElementById('m-page');
  if (!pageView) return;

  let sx = 0, sy = 0, active = false;

  pageView.addEventListener('touchstart', e => {
    if (e.touches.length > 1) { active = false; return; }
    sx = e.touches[0].clientX;
    sy = e.touches[0].clientY;
    active = true;
  }, { passive: true });

  pageView.addEventListener('touchend', e => {
    if (!active || !e.changedTouches.length) return;
    active = false;
    const dx = e.changedTouches[0].clientX - sx;
    const dy = e.changedTouches[0].clientY - sy;
    if (Math.abs(dx) < 72 || Math.abs(dx) < Math.abs(dy) * 1.5) return;
    if (e.target.closest('#m-nav-bar,svg,canvas,.graph-toolbar,.mod-filter-tabs')) return;
    const cur  = window._mobCurrentPage || 1;
    const next = dx < 0 ? Math.min(cur + 1, 12) : Math.max(cur - 1, 1);
    if (next !== cur) window.mOpenPage(next);
  }, { passive: true });
})();

/* ─── 3. NAV BAR AUTO-CENTRE ─────────────────────────────────────────── */
(function() {
  const nav = document.getElementById('m-nav-bar');
  if (!nav) return;
  _onPageOpen(() => {
    if (!MOB.small()) return;
    requestAnimationFrame(() => {
      const active = nav.querySelector('.m-nav-btn.active');
      if (!active) return;
      const nW = nav.offsetWidth, bL = active.offsetLeft, bW = active.offsetWidth;
      nav.scrollTo({ left: bL - nW / 2 + bW / 2, behavior: 'smooth' });
    });
  });
})();

/* ─── 4. SCROLL POSITION MEMORY ─────────────────────────────────────── */
(function() {
  const page = document.getElementById('m-page');
  if (!page) return;
  const pos = {};
  _onPageOpen((n, prev) => {
    if (prev) pos[prev] = page.scrollTop;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      page.scrollTop = pos[n] || 0;
    }));
  });
})();

/* ─── 5. PULL-TO-REFRESH ─────────────────────────────────────────────── */
(function() {
  if (!MOB.touch) return;
  const tb = document.getElementById('m-term-body');
  if (!tb) return;
  let sy = 0, ind = null;
  tb.addEventListener('touchstart', e => { if (tb.scrollTop <= 2) sy = e.touches[0].clientY; }, { passive: true });
  tb.addEventListener('touchmove', e => {
    if (!sy) return;
    if (e.touches[0].clientY - sy > 48 && !ind) {
      ind = Object.assign(document.createElement('div'), { className: '_ptr-ind', textContent: '↓ release to refresh' });
      tb.appendChild(ind);
    }
  }, { passive: true });
  tb.addEventListener('touchend', e => {
    if (!sy) return;
    const dy = e.changedTouches[0].clientY - sy;
    sy = 0;
    if (ind) { ind.remove(); ind = null; }
    if (dy > 64 && typeof showMenu === 'function') showMenu();
  }, { passive: true });
})();

/* ─── 6. D3 GRAPH — LAG-FREE PINCH ZOOM ─────────────────────────────── */
function _initGraphTouch() {
  if (!MOB.small() || typeof d3 === 'undefined') return;
  const svgEl = document.getElementById('curr-graph-svg');
  if (!svgEl) return;

  // Prevent duplicate listeners when graph re-initialises (eg. navigation/orientation)
  if (svgEl._mobTouchInit) return;
  svgEl._mobTouchInit = true;

  const zoomG = svgEl.querySelector('g');
  if (zoomG) zoomG.style.willChange = 'transform';

  // Block page scroll during 2-finger pinch — must be non-passive
  svgEl.addEventListener('touchmove', e => {
    if (e.touches.length >= 2) e.preventDefault();
  }, { passive: false });

  // Pointer Events pinch — rAF-coalesced, rect cached at gesture start
  const ptrs = new Map();
  let lastDist = 0, rafId = null, pX, pY, pK;
  const rect = { l: 0, t: 0 };

  svgEl.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse') return;
    svgEl.setPointerCapture(e.pointerId);
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (ptrs.size === 2) {
      // Read layout ONCE per gesture start
      const r = svgEl.getBoundingClientRect();
      rect.l = r.left; rect.t = r.top;
    }
  }, { passive: true });

  svgEl.addEventListener('pointermove', e => {
    if (!ptrs.has(e.pointerId)) return;
    ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (ptrs.size < 2) return;

    const [a, b] = [...ptrs.values()];
    const dist = Math.hypot(b.x - a.x, b.y - a.y);
    if (!lastDist) { lastDist = dist; return; }

    const delta = dist / lastDist;
    lastDist = dist;

    const mx = (a.x + b.x) / 2 - rect.l;
    const my = (a.y + b.y) / 2 - rect.t;
    const t  = d3.zoomTransform(svgEl);
    pK = Math.max(0.08, Math.min(10, t.k * delta));
    pX = mx - (mx - t.x) * (pK / t.k);
    pY = my - (my - t.y) * (pK / t.k);

    if (!rafId) rafId = requestAnimationFrame(() => {
      rafId = null;
      if (typeof graphZoomTo === 'function') graphZoomTo(pX, pY, pK);
      else if (zoomG) zoomG.setAttribute('transform', `translate(${pX},${pY}) scale(${pK})`);
    });
  }, { passive: true });

  const _endPtr = e => {
    ptrs.delete(e.pointerId);
    if (ptrs.size < 2) lastDist = 0;
  };
  svgEl.addEventListener('pointerup',     _endPtr, { passive: true });
  svgEl.addEventListener('pointercancel', _endPtr, { passive: true });

  // Double-tap to reset
  let lastTap = 0;
  svgEl.addEventListener('pointerup', e => {
    if (e.pointerType !== 'touch' || ptrs.size) return;
    const now = Date.now();
    if (now - lastTap < 260 && typeof graphZoomReset === 'function') graphZoomReset();
    lastTap = now;
  }, { passive: true });

  // Long-press node → detail modal
  let lpTimer = null, lpDatum = null;
  d3.selectAll('.graph-node')
    .on('touchstart.lp', function(_, d) {
      lpDatum = d;
      lpTimer = setTimeout(() => {
        if (lpDatum !== d) return;
        if (typeof graphFocusModule === 'function') graphFocusModule(d.id);
        const btn = document.getElementById('gmd-detail-btn');
        if (btn?.onclick) setTimeout(() => btn.onclick(), 40);
        if (navigator.vibrate) navigator.vibrate(28);
      }, 580);
    }, { passive: true })
    .on('touchend.lp touchcancel.lp', () => { clearTimeout(lpTimer); lpDatum = null; })
    .on('touchmove.lp', () => { clearTimeout(lpTimer); lpDatum = null; }, { passive: true });

  // One-time hint
  if (!sessionStorage.getItem('_gh')) {
    sessionStorage.setItem('_gh', '1');
    const con = document.getElementById('curr-graph-container');
    if (con) {
      const h = Object.assign(document.createElement('div'), { className: '_graph-hint', textContent: '👆 Tap  ·  🤏 Pinch  ·  👆👆 Reset' });
      con.appendChild(h);
      setTimeout(() => h.remove(), 3000);
    }
  }
}

const _origInitGraph = window.initCurrGraph;
window.initCurrGraph = function(...args) {
  const r = _origInitGraph?.(...args);
  setTimeout(_initGraphTouch, 200);
  return r;
};

window.addEventListener('orientationchange', () => {
  setTimeout(() => { if (document.getElementById('curr-graph-svg')) _initGraphTouch(); }, 320);
}, { passive: true });

/* ─── 7. MODAL BOTTOM SHEET SWIPE ────────────────────────────────────── */
(function() {
  if (!MOB.touch) return;
  const modal = document.getElementById('m-modal');
  const box   = document.getElementById('m-modal-box');
  if (!modal || !box) return;
  let sy = 0, cy = 0, drag = false;

  box.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'touch') return;
    const top = box.getBoundingClientRect().top;
    if (e.clientY - top > 52) return;
    box.setPointerCapture(e.pointerId);
    sy = e.clientY; cy = 0; drag = true;
    box.style.transition = 'none';
  }, { passive: true });

  box.addEventListener('pointermove', e => {
    if (!drag) return;
    cy = Math.max(0, e.clientY - sy);
    box.style.transform = `translateY(${cy}px)`;
  }, { passive: true });

  box.addEventListener('pointerup', () => {
    if (!drag) return; drag = false;
    box.style.transition = 'transform 0.27s cubic-bezier(0.4,0,0.2,1)';
    if (cy > 110) {
      box.style.transform = 'translateY(100%)';
      setTimeout(() => { modal.classList.remove('open'); box.style.transform = ''; }, 255);
    } else {
      box.style.transform = '';
    }
    cy = 0;
  }, { passive: true });
})();

/* ─── 8. SCROLL-TO-TOP BUTTON ────────────────────────────────────────── */
(function() {
  if (!MOB.small()) return;
  const page = document.getElementById('m-page');
  if (!page) return;
  const btn = Object.assign(document.createElement('button'), { id: 'm-top-btn', textContent: '↑' });
  btn.setAttribute('aria-label', 'Scroll to top');
  document.body.appendChild(btn);
  btn.addEventListener('click', () => page.scrollTo({ top: 0, behavior: 'smooth' }), { passive: true });

  let raf = null, vis = false;
  page.addEventListener('scroll', () => {
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = null;
      const s = page.scrollTop > 280;
      if (s !== vis) { vis = s; btn.classList.toggle('visible', vis); }
    });
  }, { passive: true });
})();

/* ─── 9. HAPTIC ──────────────────────────────────────────────────────── */
const _haptic = ms => { if (MOB.touch && navigator.vibrate) navigator.vibrate(ms); };

document.addEventListener('pointerdown', e => {
  if (e.pointerType !== 'touch') return;
  const t = e.target;
  if (t.closest('.a5-gen-btn,#m-back-btn'))          _haptic(8);
  else if (t.closest('.a5-chip,.mod-tab,.m-nav-btn')) _haptic(4);
}, { passive: true });

/* ─── 10. RIPPLE ─────────────────────────────────────────────────────── */
(function() {
  if (!MOB.touch) return;
  document.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'touch') return;
    const t = e.target.closest('.mod-row,.pg-spotlight-card,.pg-mag-card,.adv-card');
    if (!t) return;
    const br = t.getBoundingClientRect();
    const el = Object.assign(document.createElement('div'), { className: '_ripple' });
    el.style.cssText = `left:${e.clientX - br.left}px;top:${e.clientY - br.top}px`;
    t.appendChild(el);
    setTimeout(() => el.remove(), 480);
  }, { passive: true });
})();

/* ─── 11. TOUCH-MODE A11Y ────────────────────────────────────────────── */
let _tm = false;
document.addEventListener('touchstart', () => { if (!_tm) { _tm = true; document.body.classList.add('touch-mode'); } }, { passive: true });
document.addEventListener('keydown',    () => { if ( _tm) { _tm = false; document.body.classList.remove('touch-mode'); } });

/* ─── 12. ADVISOR CHIP AUTO-SCROLL ──────────────────────────────────── */
document.addEventListener('pointerup', e => {
  if (!MOB.small() || e.pointerType !== 'touch') return;
  const chip = e.target.closest('.a5-chip');
  const next = chip?.closest('.adv-card')?.nextElementSibling;
  if (next?.classList.contains('adv-card'))
    setTimeout(() => next.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 120);
}, { passive: true });

/* ─── 13. GRAPH SIDEBAR ACCORDION ───────────────────────────────────── */
(function() {
  if (!MOB.small()) return;
  function setup() {
    document.querySelectorAll('.graph-panel').forEach((panel, i) => {
      if (i < 2 || panel.dataset.acc) return;
      panel.dataset.acc = '1';
      const header = panel.querySelector('.graph-panel-header');
      const body   = panel.querySelector('.graph-panel-body');
      if (!header || !body) return;
      if (i > 3) body.hidden = true;
      const arrow = Object.assign(document.createElement('span'), { className: '_acc-arrow', textContent: '▶' });
      header.appendChild(arrow);
      header.addEventListener('click', () => {
        body.hidden = !body.hidden;
        arrow.style.transform = body.hidden ? '' : 'rotate(90deg)';
      }, { passive: true });
    });
  }
  const obs = new MutationObserver((_, o) => {
    if (!document.querySelector('.graph-panel')) return;
    o.disconnect(); setTimeout(setup, 180);
  });
  obs.observe(document.getElementById('m-content') || document.body, { childList: true, subtree: false });
})();

/* ─── 14. FAST BOOT (returning visitors) ─────────────────────────────── */
(function() {
  if (!MOB.small()) return;
  const fill = document.getElementById('boot-progress-fill');
  if (!fill) return;
  if (!sessionStorage.getItem('_mv')) { sessionStorage.setItem('_mv', '1'); return; }
  let p = 0;
  const id = setInterval(() => { fill.style.width = (p = Math.min(p + 20, 100)) + '%'; if (p >= 100) clearInterval(id); }, 60);
})();

/* ─── 15. PROMPT PLACEHOLDER HINTS ──────────────────────────────────── */
(function() {
  if (!MOB.small()) return;
  const inp = document.getElementById('m-prompt-input');
  if (!inp) return;
  const hints = ['type 1–12 or a topic…','try: advisor','try: graph','try: courses','try: staff','try: news'];
  let i = 0;
  setInterval(() => { if (document.activeElement !== inp) inp.placeholder = hints[i = (i + 1) % hints.length]; }, 3800);
})();

/* ─── 16. GRAPH NODE HIT TARGETS ─────────────────────────────────────── */
function _growNodes() {
  if (!MOB.small() || typeof d3 === 'undefined') return;
  d3.selectAll('.graph-node circle').each(function() {
    const el = d3.select(this), r = parseFloat(el.attr('r') || 0);
    if (r > 0 && r < 34) el.attr('r', Math.min(r * 1.28, 30));
  });
}
window.addEventListener('load', () => setTimeout(_growNodes, 1200), { once: true, passive: true });

/* ─── 17. SEARCH BAR EXPAND ──────────────────────────────────────────── */
(function() {
  if (!MOB.small()) return;
  const s = document.getElementById('m-search');
  if (!s) return;
  s.addEventListener('focus', () => { s.style.width = 'calc(100vw - 136px)'; });
  s.addEventListener('blur',  () => setTimeout(() => { s.style.width = ''; }, 180));
})();

/* ─── 18. DEBUG OVERLAY ──────────────────────────────────────────────── */
if (location.search.includes('_mob_debug')) {
  const d = Object.assign(document.createElement('div'), {
    style: 'position:fixed;top:4px;left:4px;z-index:99999;font:10px monospace;background:rgba(0,0,0,.8);color:#0f0;padding:3px 7px;border-radius:4px;pointer-events:none',
  });
  document.body.appendChild(d);
  let f = 0, lt = performance.now();
  (function tick() {
    f++;
    const n = performance.now();
    if (n - lt > 1000) { d.textContent = `${f}fps${performance.memory ? ` · ${(performance.memory.usedJSHeapSize/1048576).toFixed(1)}MB` : ''}`; f = 0; lt = n; }
    requestAnimationFrame(tick);
  })();
}

console.log('[MATIES-OS] mobile v3.0 ✓');
