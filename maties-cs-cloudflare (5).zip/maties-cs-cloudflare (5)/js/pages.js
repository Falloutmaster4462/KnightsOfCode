/* ══════════════════════════════════════════════
   MATIES-OS — Page Content Definitions
   All 12 pages, rendered on demand
   ══════════════════════════════════════════════ */
const pages={
  1:{label:'Overview',fullLabel:'Department Overview & Welcome',render:()=>`
  <div class="pg-inner-wide">
    <!-- Hero Banner -->
    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Est. 1968 · Stellenbosch, Western Cape · cs.sun.ac.za</div>
      <h1>Department of<br>Computer Science</h1>
      <p class="pg-hero-sub">One of South Africa's leading academic computing departments — advancing the digital frontier through rigorous research, transformative teaching, and pan-African impact since 1968.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge">Top 3 in South Africa</span>
        <span class="pg-hero-badge">QS Top 400 Globally</span>
        <span class="pg-hero-badge">NRF A-Rated Researchers</span>
        <span class="pg-hero-badge">MATIES-OS v4.2.1</span>
      </div>
    </div>

    <!-- Bento Stats Grid -->
    <div class="pg-bento">
      <div class="pg-bento-cell col2 maroon">
        <span class="pg-bento-num white" id="ms1">0</span>
        <div class="pg-bento-lbl white">Academic Staff</div>
        <div class="pg-bento-accent"></div>
      </div>
      <div class="pg-bento-cell col2">
        <span class="pg-bento-num" id="ms2">0</span>
        <div class="pg-bento-lbl">Students Enrolled</div>
        <div class="pg-bento-accent"></div>
      </div>
      <div class="pg-bento-cell col2">
        <span class="pg-bento-num" id="ms3">0</span>
        <div class="pg-bento-lbl">Research Groups</div>
        <div class="pg-bento-accent"></div>
      </div>
      <div class="pg-bento-cell col2">
        <span class="pg-bento-num" id="ms4">0</span>
        <div class="pg-bento-lbl">Publications 2024</div>
        <div class="pg-bento-accent"></div>
      </div>
      <div class="pg-bento-cell col2">
        <span class="pg-bento-num" id="ms5">0</span>
        <div class="pg-bento-lbl">PhD Graduates 2024</div>
        <div class="pg-bento-accent"></div>
      </div>
      <div class="pg-bento-cell col2 gold">
        <span class="pg-bento-num white" id="ms6">0</span>
        <div class="pg-bento-lbl white">Industry Partners</div>
        <div class="pg-bento-accent"></div>
      </div>
      <!-- Wide about cell -->
      <div class="pg-bento-cell col3" style="border-top:4px solid var(--su-maroon);border-radius:2px;">
        <div style="font-family:'Share Tech Mono',monospace;font-size:0.58rem;color:var(--su-gold-d);letter-spacing:2.5px;text-transform:uppercase;margin-bottom:18px;opacity:0.8;">About the Department</div>
        <p style="font-family:'Raleway',sans-serif;font-size:1.02rem;color:var(--page-text2);line-height:1.9;margin:0;">The Department of Computer Science at Stellenbosch University is a vibrant academic community dedicated to excellence in teaching, research, and innovation. Situated in the heart of the Cape Winelands, we combine world-class academic rigour with a commitment to transformative impact across Africa and beyond.</p>
      </div>
      <div class="pg-bento-cell col3" style="border-top:4px solid var(--su-gold-d);border-radius:2px;">
        <div style="font-family:'Share Tech Mono',monospace;font-size:0.58rem;color:var(--su-gold-d);letter-spacing:2.5px;text-transform:uppercase;margin-bottom:18px;opacity:0.8;">Rankings & Recognition</div>
        <p style="font-family:'Raleway',sans-serif;font-size:1.02rem;color:var(--page-text2);line-height:1.9;margin:0 0 18px;">Consistently ranked <strong style="color:var(--page-maroon)">Top 3</strong> CS departments in South Africa. QS Subject Rankings 2024 — within top 400 globally. Home to 2 NRF A-rated researchers and a SARChI Research Chair.</p>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
          <span class="m-tag gold">NRF A-Rated</span>
          <span class="m-tag green">SARChI Chair</span>
          <span class="m-tag">QS Top 400</span>
          <span class="m-tag">Est. 1968</span>
        </div>
      </div>
    </div>

    <!-- Strategic Focus Areas - Feature Strip -->
    <div class="pg-section-label">Strategic Focus Areas</div>
    <div class="pg-feature-strip">
      <div class="pg-feature-row">
        <div class="pg-feature-num">01</div>
        <div class="pg-feature-title">🤖 Artificial Intelligence</div>
        <div class="pg-feature-body">Leading research in machine learning, NLP for African languages, and responsible AI systems with real-world impact. PI: Prof. Dlamini. Partners: Google DeepMind Africa, CSIR, DSI.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">02</div>
        <div class="pg-feature-title">🔐 Cybersecurity</div>
        <div class="pg-feature-body">Cryptography, post-quantum security, digital forensics, and network defence — in partnership with national security bodies. Government-accredited research centre.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">03</div>
        <div class="pg-feature-title">🧬 Bioinformatics</div>
        <div class="pg-feature-body">Computational genomics and proteomics with focus on Southern African populations and the H3Africa consortium. SARChI Research Chair.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">04</div>
        <div class="pg-feature-title">⚡ High-Performance Computing</div>
        <div class="pg-feature-body">Parallel algorithms, distributed systems, and GPU computing with access to CHPC national facilities. AWS and Azure research credits.</div>
      </div>
    </div>

    <!-- Latest Publications -->
    <div class="pg-section-label">Latest Publications</div>
    <div style="padding:0 80px 60px;">
      <div class="m-api-badge" style="margin-bottom:20px;">Live data · OpenAlex Academic API · Updated on page load</div>
      <div id="mpubs-overview"><div class="m-loading"><div class="m-spinner"></div>Fetching latest SU publications…</div></div>
    </div>
  </div>
  `,onMount:()=>{
    const targets=[35,1200,12,70,9,28];
    ['ms1','ms2','ms3','ms4','ms5','ms6'].forEach((id,i)=>{
      let v=0;const t=targets[i];const step=Math.ceil(t/40);
      const iv=setInterval(()=>{v=Math.min(v+step,t);const el=document.getElementById(id);if(el)el.textContent=(t>=100?'~':'')+v+(i===1?'+':'');if(v>=t)clearInterval(iv);},28);
    });
    fetchPubs(ALEX_BASE+'&sort=publication_date:desc&per-page=4&select=title,authorships,primary_location,publication_year,doi,cited_by_count,primary_topic','mpubs-overview',4);
  }},

  2:{label:'Staff',fullLabel:'Academic Staff & Faculty',render:()=>`
  <div class="pg-inner-wide">
    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Academic Faculty</div>
      <h1>Our People</h1>
      <p class="pg-hero-sub">Internationally recognised scholars shaping the future of computing. Click any card to view the full profile, contact details, and publications.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge">12 Academic Staff</span>
        <span class="pg-hero-badge">2 NRF A-Rated</span>
        <span class="pg-hero-badge">1 SARChI Chair</span>
        <span class="pg-hero-badge">Internationally Active</span>
      </div>
    </div>

    <div class="pg-section-label" style="margin-top:40px;">Professors</div>
    <div class="pg-mag-grid">
      <div class="pg-mag-card" onclick="openProfileModal('ProfAvanZyl')">
        <div class="pg-mag-avatar">AZ</div>
        <div class="pg-mag-role">Head of Department · Professor</div>
        <div class="pg-mag-name">Prof. A. van Zyl</div>
        <div class="pg-mag-areas">
          <span class="m-tag">Algorithms</span><span class="m-tag">Complexity</span><span class="m-tag">Theory</span>
        </div>
        <div class="pg-mag-info">Room 1.24 · avanzyl@cs.sun.ac.za<br>h-index: 32 · 89 publications · NRF A-Rated</div>
      </div>
      <div class="pg-mag-card" onclick="openProfileModal('ProfMDlamini')">
        <div class="pg-mag-avatar">MD</div>
        <div class="pg-mag-role">Professor · AI Research Lab Director</div>
        <div class="pg-mag-name">Prof. M. Dlamini</div>
        <div class="pg-mag-areas">
          <span class="m-tag">ML</span><span class="m-tag">AI Ethics</span><span class="m-tag">NLP</span>
        </div>
        <div class="pg-mag-info">Room 2.01 · mdlamini@cs.sun.ac.za<br>h-index: 28 · 74 publications · NRF A-Rated 2024</div>
      </div>
      <div class="pg-mag-card" onclick="openProfileModal('ProfRBotha')">
        <div class="pg-mag-avatar">RB</div>
        <div class="pg-mag-role">Professor · CCS Director</div>
        <div class="pg-mag-name">Prof. R. Botha</div>
        <div class="pg-mag-areas">
          <span class="m-tag">Cryptography</span><span class="m-tag">Security</span>
        </div>
        <div class="pg-mag-info">Room 1.08 · rbotha@cs.sun.ac.za<br>h-index: 24 · 61 publications · IEEE Senior Member</div>
      </div>
      <div class="pg-mag-card" onclick="openProfileModal('ProfSNaidoo')">
        <div class="pg-mag-avatar">SN</div>
        <div class="pg-mag-role">Professor · SARChI Chair</div>
        <div class="pg-mag-name">Prof. S. Naidoo</div>
        <div class="pg-mag-areas">
          <span class="m-tag">Bioinformatics</span><span class="m-tag">Genomics</span>
        </div>
        <div class="pg-mag-info">Room 3.15 · snaidoo@cs.sun.ac.za<br>h-index: 21 · 55 publications · H3Africa PI</div>
      </div>
    </div>

    <div class="pg-section-label">Associate Professors</div>
    <div class="pg-mag-grid">
      <div class="pg-mag-card" onclick="openProfileModal('AssocProfLEngelbrecht')">
        <div class="pg-mag-avatar">LE</div>
        <div class="pg-mag-role">Associate Professor · HPC Group Lead</div>
        <div class="pg-mag-name">Assoc. Prof. L. Engelbrecht</div>
        <div class="pg-mag-areas">
          <span class="m-tag">HPC</span><span class="m-tag">Distributed</span><span class="m-tag">Cloud</span>
        </div>
        <div class="pg-mag-info">Room 2.12 · lengelbrecht@cs.sun.ac.za<br>h-index: 14 · CHPC Advisory Board</div>
      </div>
      <div class="pg-mag-card" onclick="openProfileModal('AssocProfTMokoena')">
        <div class="pg-mag-avatar">TM</div>
        <div class="pg-mag-role">Associate Professor · Formal Methods Lead</div>
        <div class="pg-mag-name">Assoc. Prof. T. Mokoena</div>
        <div class="pg-mag-areas">
          <span class="m-tag">Formal Methods</span><span class="m-tag">Verification</span>
        </div>
        <div class="pg-mag-info">Room 2.08 · tmokoena@cs.sun.ac.za<br>h-index: 12 · INRIA collaboration</div>
      </div>
    </div>

    <div class="pg-section-label">Senior Lecturers & Lecturers</div>
    <div class="pg-mag-grid">
      <div class="pg-mag-card" onclick="openProfileModal('DrPHendricks')">
        <div class="pg-mag-avatar">PH</div>
        <div class="pg-mag-role">Lecturer</div>
        <div class="pg-mag-name">Dr. P. Hendricks</div>
        <div class="pg-mag-areas"><span class="m-tag">Graphics</span><span class="m-tag">VR/AR</span><span class="m-tag">Game Dev</span></div>
        <div class="pg-mag-info">Room 1.18 · phendricks@cs.sun.ac.za<br>Computer graphics, VR/AR, and game development</div>
      </div>
      <div class="pg-mag-card" onclick="openProfileModal('DrASteenkamp')">
        <div class="pg-mag-avatar">AS</div>
        <div class="pg-mag-role">Lecturer</div>
        <div class="pg-mag-name">Dr. A. Steenkamp</div>
        <div class="pg-mag-areas"><span class="m-tag">Data Science</span><span class="m-tag">Databases</span><span class="m-tag">Big Data</span></div>
        <div class="pg-mag-info">Room 1.22 · asteenkamp@cs.sun.ac.za<br>Data science, big data analytics, and database systems</div>
      </div>
      <div class="pg-mag-card" onclick="openProfileModal('DrFOsei')">
        <div class="pg-mag-avatar">FO</div>
        <div class="pg-mag-role">Lecturer · SADiLaR Affiliate</div>
        <div class="pg-mag-name">Dr. F. Osei</div>
        <div class="pg-mag-areas"><span class="m-tag">NLP</span><span class="m-tag">Linguistics</span><span class="m-tag">African Languages</span></div>
        <div class="pg-mag-info">Room 3.10 · fosei@cs.sun.ac.za<br>PhD Edinburgh · Natural language processing</div>
      </div>
      <div class="pg-mag-card" onclick="openProfileModal('DrKvanderMerwe')">
        <div class="pg-mag-avatar">KM</div>
        <div class="pg-mag-role">Lecturer</div>
        <div class="pg-mag-name">Dr. K. van der Merwe</div>
        <div class="pg-mag-areas"><span class="m-tag">Embedded</span><span class="m-tag">IoT</span><span class="m-tag">Edge Computing</span></div>
        <div class="pg-mag-info">Room B05 · kvandermerwe@cs.sun.ac.za<br>Partners: Bosch Engineering SA, Vodacom IoT</div>
      </div>
      <div class="pg-mag-card" onclick="openProfileModal('DrZPetersen')">
        <div class="pg-mag-avatar">ZP</div>
        <div class="pg-mag-role">Lecturer</div>
        <div class="pg-mag-name">Dr. Z. Petersen</div>
        <div class="pg-mag-areas"><span class="m-tag">Software Eng</span><span class="m-tag">DevOps</span><span class="m-tag">Agile</span></div>
        <div class="pg-mag-info">Room 1.20 · zpetersen@cs.sun.ac.za<br>Software engineering, agile methods, DevOps</div>
      </div>
      <div class="pg-mag-card" onclick="openProfileModal('DrNSithole')">
        <div class="pg-mag-avatar">NS</div>
        <div class="pg-mag-role">Lecturer</div>
        <div class="pg-mag-name">Dr. N. Sithole</div>
        <div class="pg-mag-areas"><span class="m-tag">Vision</span><span class="m-tag">Remote Sensing</span><span class="m-tag">Deep Learning</span></div>
        <div class="pg-mag-info">Room 3.08 · nsithole@cs.sun.ac.za<br>PhD Pretoria · Computer vision, SANSA affiliate</div>
      </div>
    </div>

    <div class="pg-section-label">Research Output (Live)</div>
    <div style="padding: 0 80px 60px;">
      <div class="m-api-badge" style="margin-bottom:16px;">Live data from OpenAlex Academic API</div>
      <div id="mpubs-staff"><div class="m-loading"><div class="m-spinner"></div>Fetching recent publications…</div></div>
    </div>
  </div>
  `,onMount:()=>fetchPubs(ALEX_BASE+'&sort=cited_by_count:desc&per-page=5&select=title,authorships,primary_location,publication_year,doi,cited_by_count,primary_topic','mpubs-staff',5,true)},

  3:{label:'Publications',fullLabel:'Publications & Research Output',render:()=>`
  <div class="pg-inner-wide">
    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Research Output 2024–2025</div>
      <h1>Publications<br>&amp; Impact</h1>
      <p class="pg-hero-sub">Our department publishes at top international venues — from Nature journals to IEEE S&amp;P. R14.2M in active research funding.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge">47 Journal Articles</span>
        <span class="pg-hero-badge">23 Conference Papers</span>
        <span class="pg-hero-badge">R14.2M Funding</span>
        <span class="pg-hero-badge">+20.3% Growth</span>
      </div>
    </div>
    <div class="pg-split">
      <div class="pg-split-sidebar">
        <div class="pg-sidebar-label">Filter Publications</div>
        <div class="pg-sidebar-link active" onclick="mFilterPubs('recent',this)">📅 Recent</div>
        <div class="pg-sidebar-link" onclick="mFilterPubs('cited',this)">⭐ Most Cited</div>
        <div class="pg-sidebar-link" onclick="mFilterPubs('ai',this)">🤖 AI / ML</div>
        <div class="pg-sidebar-link" onclick="mFilterPubs('security',this)">🔐 Security</div>
        <div class="pg-sidebar-link" onclick="mFilterPubs('bio',this)">🧬 Bioinformatics</div>
        <div class="pg-sidebar-label">Impact Metrics</div>
        <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:4px;">
          <div style="border-left:2px solid var(--su-maroon);padding:8px 10px;background:rgba(97,34,59,0.04);">
            <div style="font-family:'Share Tech Mono',monospace;font-size:0.58rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;">Journal Articles</div>
            <div style="font-family:'Playfair Display',serif;font-size:1.1rem;font-weight:700;color:var(--page-maroon);">41 → 47 <span style="font-family:'Share Tech Mono',monospace;font-size:0.6rem;color:#52c878;font-style:normal;">▲14.6%</span></div>
          </div>
          <div style="border-left:2px solid var(--su-maroon);padding:8px 10px;background:rgba(97,34,59,0.04);">
            <div style="font-family:'Share Tech Mono',monospace;font-size:0.58rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;">A*/A Conferences</div>
            <div style="font-family:'Playfair Display',serif;font-size:1.1rem;font-weight:700;color:var(--page-maroon);">18 → 23 <span style="font-family:'Share Tech Mono',monospace;font-size:0.6rem;color:#52c878;font-style:normal;">▲27.8%</span></div>
          </div>
          <div style="border-left:2px solid var(--su-maroon);padding:8px 10px;background:rgba(97,34,59,0.04);">
            <div style="font-family:'Share Tech Mono',monospace;font-size:0.58rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;">PhD Graduates</div>
            <div style="font-family:'Playfair Display',serif;font-size:1.1rem;font-weight:700;color:var(--page-maroon);">6 → 9 <span style="font-family:'Share Tech Mono',monospace;font-size:0.6rem;color:#52c878;font-style:normal;">▲50%</span></div>
          </div>
          <div style="border-left:2px solid var(--su-gold-d);padding:8px 10px;background:rgba(202,162,88,0.05);">
            <div style="font-family:'Share Tech Mono',monospace;font-size:0.58rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;">Research Grants</div>
            <div style="font-family:'Playfair Display',serif;font-size:1.1rem;font-weight:700;color:var(--page-maroon);">R14.2M <span style="font-family:'Share Tech Mono',monospace;font-size:0.6rem;color:#52c878;font-style:normal;">▲20.3%</span></div>
          </div>
          <div style="border-left:2px solid var(--su-gold-d);padding:8px 10px;background:rgba(202,162,88,0.05);">
            <div style="font-family:'Share Tech Mono',monospace;font-size:0.58rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;">Intl. Collaborations</div>
            <div style="font-family:'Playfair Display',serif;font-size:1.1rem;font-weight:700;color:var(--page-maroon);">14 → 19 <span style="font-family:'Share Tech Mono',monospace;font-size:0.6rem;color:#52c878;font-style:normal;">▲35.7%</span></div>
          </div>
        </div>
        <div class="pg-sidebar-label">Research Keywords</div>
        <div style="display:flex;flex-wrap:wrap;gap:4px;">
          ${['ML','NLP','Security','Bio','HPC','Vision','Theory','IoT'].map(t=>`<span class="m-tag" style="margin:2px;">${t}</span>`).join('')}
        </div>
      </div>
      <div class="pg-split-main">
        <div class="m-api-badge" style="margin-bottom:20px;">Real-time data from OpenAlex Academic API</div>
        <div id="mpubs-live"><div class="m-loading"><div class="m-spinner"></div>Fetching live publications…</div></div>

        <h2 class="m-h2" style="margin-top:52px;">Selected Publications 2024–2025</h2>
        ${pubCard('Adaptive Neural Architectures for Low-Resource African Languages','Dlamini M., Osei F., Nkosi B.','Nature Machine Intelligence, 2025','10.1038/s42256-025-00821-x','NLP','ML','Q1 Journal')}
        ${pubCard('Formal Verification of Smart Contract Protocols using Isabelle/HOL','Mokoena T., van Zyl A.','IEEE Trans. Software Engineering, 2024','10.1109/TSE.2024.1234567','Formal Methods','Q1 Journal')}
        ${pubCard('HPC-Optimised Genomic Assembly Pipelines for Southern African Populations','Naidoo S., Engelbrecht L., et al.','Bioinformatics (OUP), 2024',null,'Bioinformatics','HPC','Q1 Journal')}
        ${pubCard('Post-Quantum Cryptographic Primitives for Constrained IoT Devices','Botha R., van der Merwe K.','IEEE S&P 2024',null,'Cryptography','IoT','A* Conference')}

        <h2 class="m-h2" style="margin-top:52px;">Impact Metrics</h2>
        <table class="m-table"><thead><tr><th>Metric</th><th>2023</th><th>2024</th><th>Trend</th></tr></thead><tbody>
          <tr><td>DHET-accredited journal articles</td><td>41</td><td>47</td><td class="trend-up">▲ +14.6%</td></tr>
          <tr><td>A*/A conference papers</td><td>18</td><td>23</td><td class="trend-up">▲ +27.8%</td></tr>
          <tr><td>PhD theses graduated</td><td>6</td><td>9</td><td class="trend-up">▲ +50%</td></tr>
          <tr><td>Total research grants (ZAR)</td><td>R11.8M</td><td>R14.2M</td><td class="trend-up">▲ +20.3%</td></tr>
          <tr><td>International collaborations</td><td>14</td><td>19</td><td class="trend-up">▲ +35.7%</td></tr>
        </tbody></table>
      </div>
    </div>
  </div>
  `,onMount:()=>fetchPubs(ALEX_BASE+'&sort=publication_date:desc&per-page=10&select=title,authorships,primary_location,publication_year,doi,cited_by_count,primary_topic','mpubs-live',10,true)},

  4:{label:'Programmes',fullLabel:'Undergraduate & Postgraduate Programmes',render:()=>`
  <div class="pg-inner-wide">
    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Academic Pathways — All Levels</div>
      <h1>Academic<br>Programmes</h1>
      <p class="pg-hero-sub">Rigorous, internationally recognised computing programmes from foundational BSc to cutting-edge doctoral research. Offered in English and Afrikaans.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge">📌 NBT Required</span>
        <span class="pg-hero-badge">Closing: 31 August</span>
        <span class="pg-hero-badge">Apply at maties.com</span>
      </div>
    </div>

    <div class="pg-timeline" style="padding-top:52px;">
      <!-- BSc CS -->
      <div class="pg-timeline-item">
        <div class="pg-tl-year">Undergraduate<br>NQF Level 7<br>3 Years</div>
        <div class="pg-tl-line"></div>
        <div class="pg-tl-content">
          <div class="pg-tl-card">
            <div class="pg-tl-title">BSc Computer Science</div>
            <div class="pg-tl-badges">
              <span class="m-badge">3 Years</span><span class="m-badge green">NQF 7</span><span class="m-badge" style="background:#1a3a70;">396 Credits</span>
            </div>
            <p class="pg-tl-desc">The flagship CS degree at SU. Deep foundations in algorithms, data structures, software design, computer architecture, OS, networks, databases, and concurrency. Three focal areas: <strong>General CS</strong>, <strong>Computer Systems</strong>, or <strong>Data Science &amp; ML</strong>.</p>
            <div class="pg-tl-info-row">
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">📋 Entry Requirements</div>
                <div class="pg-tl-info-body">NSC ≥ 65% · Maths ≥ 70%<br>NBT required · English ≥ 50%<br><em style="color:var(--su-gold-d);">Actual cutoff: 70–75%</em></div>
              </div>
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">💼 Career Paths</div>
                <div class="pg-tl-info-body">Software engineer · Data scientist<br>ML/AI engineer · DevOps · CTO<br>Starting: R420–620k p.a.</div>
              </div>
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">📖 Year Snapshot</div>
                <div class="pg-tl-info-body"><strong>Y1:</strong> CS 114/144, WIS 114/144<br><strong>Y2:</strong> CS 214, CS 244<br><strong>Y3:</strong> CS 313/315/344/345</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- BDatSci -->
      <div class="pg-timeline-item">
        <div class="pg-tl-year">Undergraduate<br>NQF Level 7<br>4 Years</div>
        <div class="pg-tl-line"></div>
        <div class="pg-tl-content">
          <div class="pg-tl-card">
            <div class="pg-tl-title">Bachelor of Data Science (BDatSci)</div>
            <div class="pg-tl-badges">
              <span class="m-badge blue">4 Years</span><span class="m-badge green">NQF 7</span><span class="m-badge" style="background:#1a3a70;">480+ Credits</span>
            </div>
            <p class="pg-tl-desc">Interfaculty degree combining CS with Statistics and Data Science. Significantly more selective than BSc CS — for students seeking deep integration of computing, mathematics, and statistical modelling. ~30 places p.a.</p>
            <div class="pg-tl-info-row">
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">📋 Entry Requirements</div>
                <div class="pg-tl-info-body">NSC ≥ 80% · Maths ≥ 80%<br>NBT top band · ~30 places p.a.<br>Very competitive</div>
              </div>
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">💼 Career Paths</div>
                <div class="pg-tl-info-body">Data scientist · Quant analyst<br>ML research engineer<br>Starting: R500–750k p.a.</div>
              </div>
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">📖 Year Snapshot</div>
                <div class="pg-tl-info-body"><strong>Y1–3:</strong> CS + STAT + WIS<br><strong>Y4:</strong> Research capstone + electives</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Honours -->
      <div class="pg-timeline-item">
        <div class="pg-tl-year">Postgraduate<br>NQF Level 8<br>1 Year</div>
        <div class="pg-tl-line"></div>
        <div class="pg-tl-content">
          <div class="pg-tl-card">
            <div class="pg-tl-title">BScHons Computer Science</div>
            <div class="pg-tl-badges">
              <span class="m-badge">1 Year</span><span class="m-badge green">NQF 8</span><span class="m-badge" style="background:#a07a30;color:#fff;">120–130 Credits</span>
            </div>
            <p class="pg-tl-desc">Structured coursework-based honours bridging undergraduate study and research. Students take advanced modules and complete a supervised research mini-project. Strongly recommended before pursuing an MSc.</p>
            <div class="pg-tl-info-row">
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">📋 Requirements</div>
                <div class="pg-tl-info-body">BSc CS + ≥ 65% in 3rd-year CS<br>Department approval + interview<br>Limited places</div>
              </div>
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">📖 Core Modules</div>
                <div class="pg-tl-info-body">CS 411 Advanced Algorithms<br>CS 413 Research Methodology<br>CS 490 Research Project (40cr)</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- MSc -->
      <div class="pg-timeline-item">
        <div class="pg-tl-year">Postgraduate<br>NQF Level 9<br>1–2 Years</div>
        <div class="pg-tl-line"></div>
        <div class="pg-tl-content">
          <div class="pg-tl-card">
            <div class="pg-tl-title">MSc Computer Science</div>
            <div class="pg-tl-badges">
              <span class="m-badge">1–2 Years</span><span class="m-badge green">NQF 9</span>
            </div>
            <p class="pg-tl-desc">Research-focused master's centred on an original thesis. Students embed in one of our active research groups. NRF bursaries and departmental funding available for exceptional candidates.</p>
            <div class="pg-tl-info-row">
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">📋 Requirements</div>
                <div class="pg-tl-info-body">BScHons CS ≥ 65% overall<br>Supervisor secured first<br>Research proposal required</div>
              </div>
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">🔬 Research Areas</div>
                <div class="pg-tl-info-body">ML &amp; AI · Cybersecurity<br>Bioinformatics · HPC<br>Formal Methods</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- PhD -->
      <div class="pg-timeline-item">
        <div class="pg-tl-year">Doctoral<br>NQF Level 10<br>3–4 Years</div>
        <div class="pg-tl-line"></div>
        <div class="pg-tl-content">
          <div class="pg-tl-card">
            <div class="pg-tl-title">PhD Computer Science</div>
            <div class="pg-tl-badges">
              <span class="m-badge">3–4 Years</span><span class="m-badge green">NQF 10</span>
            </div>
            <p class="pg-tl-desc">Research doctorate requiring an original and substantial contribution to computing science. Candidates publish in peer-reviewed venues and contribute to active research groups. International applicants actively welcomed. NRF, DSI, SARS bursaries available.</p>
            <div class="pg-tl-info-row">
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">📋 Requirements</div>
                <div class="pg-tl-info-body">MSc CS or equivalent<br>Strong publication record preferred<br>Detailed research proposal</div>
              </div>
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">💼 Career Paths</div>
                <div class="pg-tl-info-body">Professor / Senior researcher<br>Research scientist (industry)<br>Chief Scientist / AI Director</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- MEng -->
      <div class="pg-timeline-item">
        <div class="pg-tl-year">Postgraduate<br>NQF Level 9<br>2 Years</div>
        <div class="pg-tl-line"></div>
        <div class="pg-tl-content">
          <div class="pg-tl-card" style="border-top:5px solid var(--su-orange);">
            <div class="pg-tl-title">MEng Computer Engineering</div>
            <div class="pg-tl-badges">
              <span class="m-badge">2 Years</span><span class="m-badge green">NQF 9</span><span class="m-badge" style="background:var(--su-orange);color:#fff;">Joint Degree</span>
            </div>
            <p class="pg-tl-desc">Offered jointly with Electrical &amp; Electronic Engineering. Focuses on embedded systems, hardware-software co-design, FPGA, and IoT. Coursework + mini-thesis format.</p>
            <div class="pg-tl-info-row">
              <div class="pg-tl-info-box">
                <div class="pg-tl-info-label">💼 Career Paths</div>
                <div class="pg-tl-info-body">Embedded systems engineer<br>FPGA developer · IoT architect<br>Hardware engineer · Defence tech</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Chart section -->
    <div class="pg-section-label">Programme Comparison</div>
    <div style="padding:0 80px 80px;">
      <div class="pg-tl-card">
        <p style="font-size:0.86rem;color:var(--page-text2);margin-bottom:14px;">Bubble size = NQF level. X-axis = duration. Y-axis = minimum NSC %. Use the slider to filter.</p>
        <div class="chart-container"><canvas id="prog-chart"></canvas></div>
        <div class="m-slider-wrap">
          <div class="m-slider-label">Show programmes with min NSC ≥ <span class="m-slider-val" id="nsc-val">60%</span></div>
          <input type="range" id="nsc-slider" min="60" max="85" value="60" step="5" oninput="updateProgChart(this.value)">
        </div>
      </div>
    </div>
  </div>
  `,onMount:()=>{setTimeout(()=>initProgChart(),100);}},

  5:{label:'Courses',fullLabel:'Course Catalogue & Module Listings',render:()=>`
  <div class="pg-inner-wide">
    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Course Catalogue</div>
      <h1>Module<br>Listings</h1>
      <p class="pg-hero-sub">All CS modules across all year levels. Click any module to expand full details. Filter by year or search by code or name.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge" id="mod-count-badge">47 Modules</span>
        <span class="pg-hero-badge">7 Year Levels</span>
        <span class="pg-hero-badge">NQF 5–9</span>
        <span class="pg-hero-badge">120 Credits/Year</span>
      </div>
    </div>

    <!-- Filter toolbar -->
    <div class="mod-toolbar">
      <div class="mod-filter-tabs" id="mod-tabs">
        <button class="mod-tab active" data-year="all" onclick="modFilter('all',this)">All</button>
        <button class="mod-tab" data-year="1" onclick="modFilter('1',this)">Y1 Foundations</button>
        <button class="mod-tab" data-year="2" onclick="modFilter('2',this)">Y2 Core</button>
        <button class="mod-tab" data-year="3" onclick="modFilter('3',this)">Y3 Specialisation</button>
        <button class="mod-tab" data-year="4" onclick="modFilter('4',this)">Y4 Honours</button>
        <button class="mod-tab" data-year="5" onclick="modFilter('5',this)">Y5 Postgrad</button>
        <button class="mod-tab" data-year="6" onclick="modFilter('6',this)">Y6 MSc</button>
        <button class="mod-tab" data-year="7" onclick="modFilter('7',this)">Y7 PhD</button>
      </div>
      <div class="mod-search-wrap">
        <input class="mod-search" id="mod-search" type="text" placeholder="Search code or name…" oninput="modSearch(this.value)">
        <span class="mod-search-clear" id="mod-clear" onclick="modClearSearch()" style="display:none;">✕</span>
      </div>
    </div>

    <!-- Track filter chips -->
    <div class="mod-track-row" id="mod-track-row">
      <span class="mod-track-label">Track:</span>
      <button class="mod-track-btn active" data-track="all" onclick="modTrack('all',this)">All</button>
      <button class="mod-track-btn" data-track="ai" onclick="modTrack('ai',this)" style="border-color:#82CCAE;color:#3a8a6a;">🤖 AI</button>
      <button class="mod-track-btn" data-track="security" onclick="modTrack('security',this)" style="border-color:#dc4405;color:#dc4405;">🔐 Security</button>
      <button class="mod-track-btn" data-track="systems" onclick="modTrack('systems',this)" style="border-color:#64c8d4;color:#2a8a90;">⚡ Systems</button>
      <button class="mod-track-btn" data-track="data" onclick="modTrack('data',this)" style="border-color:#b48ae0;color:#7a5aaa;">📊 Data</button>
      <button class="mod-track-btn" data-track="bio" onclick="modTrack('bio',this)" style="border-color:#5ecfaa;color:#2a9a7a;">🧬 Bio</button>
      <button class="mod-track-btn" data-track="theory" onclick="modTrack('theory',this)" style="border-color:#f5a623;color:#b07010;">📐 Theory</button>
      <button class="mod-track-btn" data-track="graphics" onclick="modTrack('graphics',this)" style="border-color:#ff7eb3;color:#cc3377;">🎮 Graphics</button>
      <button class="mod-track-btn" data-track="honours" onclick="modTrack('honours',this)" style="border-color:#caa258;color:#8a6a28;">🎓 Honours</button>
      <button class="mod-track-btn" data-track="masters" onclick="modTrack('masters',this)" style="border-color:#6b2fa0;color:#6b2fa0;">📘 Masters</button>
      <button class="mod-track-btn" data-track="phd" onclick="modTrack('phd',this)" style="border-color:#c0392b;color:#c0392b;">🔬 PhD</button>
    </div>

    <!-- Module count -->
    <div class="mod-result-meta" id="mod-result-meta">Showing all 47 modules</div>

    <!-- Module list -->
    <div class="mod-list" id="mod-list"></div>

    <div style="height:80px;"></div>
  </div>
  `,onMount:()=>{
  const MODS = [
    // Year 1
    {code:'CS 114',name:'Introduction to Computer Science 1',year:1,sem:1,credits:16,track:[],desc:'Foundations of computational thinking, problem solving, and programming in Python. Variables, control flow, functions, recursion, and basic data structures.',prereqs:'None',assessments:'4 Practicals (40%) + Final Exam (60%)'},
    {code:'CS 144',name:'Introduction to Computer Science 2',year:1,sem:2,credits:16,track:[],desc:'Object-oriented programming, abstract data types, introduction to algorithms, complexity, and sorting. Java is introduced alongside Python.',prereqs:'CS 114',assessments:'4 Practicals (40%) + Final Exam (60%)'},
    {code:'WIS 114',name:'Mathematics 114',year:1,sem:1,credits:16,track:[],desc:'Calculus (limits, derivatives, integrals), linear algebra (vectors, matrices, eigenvalues), and introductory mathematical reasoning.',prereqs:'NSC Mathematics ≥ 70%',assessments:'Tests (30%) + Exam (70%)'},
    {code:'WIS 144',name:'Mathematics 144',year:1,sem:2,credits:16,track:[],desc:'Discrete mathematics: logic, sets, relations, functions, graph theory, combinatorics, and proof techniques (induction, contradiction).',prereqs:'WIS 114',assessments:'Tests (30%) + Exam (70%)'},
    {code:'FIS 114',name:'Physics 114',year:1,sem:1,credits:16,track:[],desc:'Mechanics, waves, electromagnetism, and optics. Provides physical intuition for embedded systems and hardware-level CS topics.',prereqs:'NSC Physical Sciences ≥ 60%',assessments:'Practicals (20%) + Tests (20%) + Exam (60%)'},
    {code:'STAT 144',name:'Introductory Statistics',year:1,sem:2,credits:12,track:[],desc:'Descriptive statistics, probability distributions, hypothesis testing, regression, and introduction to statistical software (R).',prereqs:'WIS 114 or concurrent',assessments:'Assignments (30%) + Exam (70%)'},
    // Year 2
    {code:'CS 214',name:'Data Structures & Algorithms',year:2,sem:1,credits:16,track:[],desc:'Core data structures (trees, heaps, hash tables, graphs) and algorithm design paradigms (divide-and-conquer, greedy, dynamic programming). Complexity analysis.',prereqs:'CS 144, WIS 144',assessments:'Programming assignments (40%) + Exam (60%)',critical:true},
    {code:'CS 244',name:'Computer Architecture & OS',year:2,sem:2,credits:16,track:['systems'],desc:'Digital logic, CPU design, memory hierarchy, I/O. Operating system concepts: processes, threads, scheduling, memory management, file systems.',prereqs:'CS 144, FIS 114',assessments:'Labs (30%) + Exam (70%)'},
    {code:'WIS 214',name:'Mathematics 214',year:2,sem:1,credits:16,track:[],desc:'Abstract algebra: groups, rings, fields. Introductory real analysis: sequences, series, continuity, differentiation. Proof-heavy course.',prereqs:'WIS 144',assessments:'Tests (30%) + Exam (70%)'},
    {code:'WIS 244',name:'Mathematics 244',year:2,sem:2,credits:16,track:[],desc:'Analysis continued: Riemann integration, metric spaces, uniform convergence. Ordinary differential equations.',prereqs:'WIS 214',assessments:'Tests (30%) + Exam (70%)'},
    {code:'STAT 244',name:'Mathematical Statistics',year:2,sem:2,credits:16,track:['ai','data'],desc:'Probability theory, random variables, distributions, parameter estimation, hypothesis testing, ANOVA, and linear models. Foundation for ML.',prereqs:'STAT 144, WIS 214',assessments:'Assignments (30%) + Exam (70%)'},
    // Year 3
    {code:'CS 313',name:'Computer Networks',year:3,sem:1,credits:16,track:['security','systems'],desc:'OSI model, TCP/IP, Ethernet, routing, DNS, HTTP, TLS. Socket programming. Network security fundamentals. Protocol analysis.',prereqs:'CS 244',assessments:'Labs (30%) + Exam (70%)'},
    {code:'CS 314',name:'Concurrent & Parallel Programming',year:3,sem:1,credits:16,track:['systems'],desc:'Threads, synchronisation, locks, semaphores, monitors. MPI, OpenMP, CUDA for GPU computing. Distributed algorithm correctness.',prereqs:'CS 244',assessments:'Programming projects (50%) + Exam (50%)'},
    {code:'CS 315',name:'Machine Learning',year:3,sem:1,credits:16,track:['ai','data'],desc:'Supervised and unsupervised learning: linear models, SVMs, decision trees, neural networks, clustering, dimensionality reduction. Python/scikit-learn.',prereqs:'CS 214, STAT 244',assessments:'Kaggle projects (40%) + Exam (60%)'},
    {code:'CS 323',name:'Programming Language Concepts',year:3,sem:1,credits:16,track:['theory'],desc:'Language paradigms: imperative, functional, logic. Type systems, type inference, polymorphism. Operational and denotational semantics. Lambda calculus.',prereqs:'CS 224',assessments:'Assignments (40%) + Exam (60%)'},
    {code:'CS 343',name:'Databases & Information Systems',year:3,sem:1,credits:16,track:['data'],desc:'Relational model, SQL, normalisation, transactions, indexing. NoSQL databases. Full-stack web: HTML/CSS/JS, REST APIs, Django/Flask.',prereqs:'CS 214',assessments:'Projects (50%) + Exam (50%)'},
    {code:'CS 344',name:'Software Engineering & Design',year:3,sem:2,credits:16,track:['honours'],desc:'Agile methods, UML, design patterns, testing (unit, integration, TDD), CI/CD, code quality and review practices. Industry-focused.',prereqs:'CS 244',assessments:'Group project (60%) + Exam (40%)'},
    {code:'CS 345',name:'Computability & Formal Languages',year:3,sem:2,credits:16,track:['theory','honours'],desc:'Finite automata, regular languages, context-free grammars, Turing machines, decidability, complexity (P vs NP), reduction techniques.',prereqs:'CS 214, WIS 244',assessments:'Problem sets (40%) + Exam (60%)'},
    {code:'CS 353',name:'Computer Security Fundamentals',year:3,sem:2,credits:16,track:['security'],desc:'Threat modelling, vulnerability analysis, exploitation basics. Defensive programming, secure coding practices. Penetration testing methodology.',prereqs:'CS 313',assessments:'Labs (40%) + Exam (60%)'},
    {code:'CS 354',name:'Computer Vision',year:3,sem:2,credits:16,track:['ai','graphics'],desc:'Image formation, feature detection, segmentation, object recognition, deep CNNs for vision, 3D reconstruction, optical flow.',prereqs:'CS 315',assessments:'Projects (50%) + Exam (50%)'},
    {code:'CS 373',name:'Embedded Systems',year:3,sem:1,credits:12,track:['systems'],desc:'Microcontroller architecture, real-time OS, interrupt handling, DMA. Sensor interfaces: I2C, SPI, UART. IoT protocols (MQTT, CoAP).',prereqs:'CS 244',assessments:'Labs (50%) + Exam (50%)'},
    // Honours
    {code:'CS 411',name:'Advanced Algorithms',year:4,sem:1,credits:20,track:['honours','ai','theory'],desc:'Randomised algorithms, approximation algorithms, online algorithms, streaming algorithms, competitive analysis, and advanced graph theory.',prereqs:'CS 345',assessments:'Problem sets (50%) + Exam (50%)'},
    {code:'CS 413',name:'Research Methodology',year:4,sem:1,credits:10,track:['honours'],desc:'Scientific writing, literature review, research design, ethics, presentation skills, and academic writing for computer science.',prereqs:'Honours entry',assessments:'Written assignments (100%)'},
    {code:'CS 415',name:'Deep Learning',year:4,sem:1,credits:20,track:['ai','honours'],desc:'CNN architectures, sequence models (LSTM, Transformers), attention mechanisms. Distributed GPU training. PyTorch advanced.',prereqs:'CS 315, CS 354',assessments:'Projects (60%) + Exam (40%)'},
    {code:'CS 416',name:'Network Security & Forensics',year:4,sem:1,credits:20,track:['security','honours'],desc:'Advanced penetration testing, malware analysis, digital forensics. Incident response planning. CTF practicals.',prereqs:'CS 353, CS 313',assessments:'Labs (60%) + Exam (40%)'},
    {code:'CS 421',name:'Natural Language Processing',year:4,sem:2,credits:20,track:['ai','honours'],desc:'Text classification, parsing, seq2seq models, attention mechanisms, transformers, BERT, GPT-style LLMs, and multilingual NLP.',prereqs:'CS 315',assessments:'Projects (60%) + Exam (40%)'},
    {code:'CS 422',name:'Reinforcement Learning',year:4,sem:2,credits:20,track:['ai','honours'],desc:'MDPs, Bellman equations, Q-learning, policy gradient methods (REINFORCE, PPO). Multi-agent RL. Gymnasium/MuJoCo practicals.',prereqs:'CS 315, CS 411',assessments:'Project (70%) + Seminar (30%)'},
    {code:'CS 431',name:'High-Performance Computing',year:4,sem:1,credits:20,track:['systems','honours'],desc:'Parallel architectures, GPU (CUDA), FPGAs. Performance profiling, MPI advanced. Access to CHPC Lengau supercomputer.',prereqs:'CS 314, CS 244',assessments:'Labs (50%) + Project (50%)'},
    {code:'CS 441',name:'Advanced Software Engineering',year:4,sem:2,credits:20,track:['honours','systems'],desc:'Distributed systems, CAP theorem, microservices, Kubernetes. Software reliability engineering.',prereqs:'CS 344',assessments:'Project (60%) + Exam (40%)'},
    {code:'CS 490',name:'Honours Research Project',year:4,sem:0,credits:40,track:['honours'],desc:'Year-long supervised research project culminating in a written thesis and oral presentation. Students embed in an active research lab.',prereqs:'All core Honours modules',assessments:'Thesis (70%) + Presentation (30%)'},
    // Y5 Postgrad
    {code:'CS 448',name:'Advanced Machine Learning',year:5,sem:1,credits:20,track:['ai'],desc:'Deep learning architectures, generative models (VAE, GAN, Diffusion), reinforcement learning, meta-learning, and ML theory.',prereqs:'CS 315 or equivalent',assessments:'Research project (70%) + Seminar (30%)'},
    {code:'CS 449',name:'Bioinformatics Algorithms',year:5,sem:1,credits:20,track:['bio'],desc:'Sequence alignment, genome assembly, phylogenetics, protein structure prediction, single-cell RNA-seq, and variant calling pipelines.',prereqs:'CS 214 + Biology background',assessments:'Computational project (80%) + Report (20%)'},
    {code:'CS 450',name:'Applied Cryptography',year:5,sem:2,credits:20,track:['security'],desc:'Symmetric/asymmetric encryption, post-quantum cryptography (lattice-based), zero-knowledge proofs, secure multi-party computation.',prereqs:'WIS 214 + CS 345',assessments:'Problem sets (40%) + Project (60%)'},
    {code:'CS 451',name:'Formal Verification',year:5,sem:2,credits:20,track:['theory'],desc:'Isabelle/HOL theorem prover, TLA+ model checking, Coq proof assistant, smart contract verification, and program correctness proofs.',prereqs:'CS 345, WIS 214',assessments:'Proof assignments (60%) + Exam (40%)'},
    {code:'CS 452',name:'Cloud & Distributed Systems',year:5,sem:2,credits:20,track:['systems'],desc:'CAP theorem, consensus (Raft, Paxos), MapReduce, Spark, Kubernetes, serverless computing, and distributed transaction management.',prereqs:'CS 314, CS 313',assessments:'Labs (40%) + Project (60%)'},
    {code:'CS 453',name:'Advanced Computer Vision',year:5,sem:1,credits:20,track:['graphics','ai'],desc:'3D reconstruction (NeRF), video understanding, multi-modal models (CLIP, DALL-E). Real-time systems on edge hardware (Jetson).',prereqs:'CS 354, CS 415',assessments:'Research project (80%) + Presentation (20%)'},
    {code:'CS 460',name:'MSc Research Project',year:5,sem:0,credits:90,track:['honours','masters'],desc:'Original research contribution leading to a publishable MSc dissertation. Supervised by a faculty member, co-supervised by external collaborator. Culminates in public viva voce.',prereqs:'CS 490 or equivalent Honours degree',assessments:'Dissertation (80%) + Viva voce (20%)'},
    // Y6 MSc
    {code:'CS 501',name:'Advanced Research Topics',year:6,sem:1,credits:20,track:['masters'],desc:'Intensive reading group covering frontier research. Students present and critique top-venue papers (NeurIPS, ICML, IEEE S&P, SOSP, STOC).',prereqs:'MSc entry',assessments:'Paper presentations (50%) + Written review (50%)'},
    {code:'CS 502',name:'MSc Thesis Proposal',year:6,sem:1,credits:20,track:['masters'],desc:'Guided preparation of a full MSc research proposal. Literature survey, problem statement, methodology, and oral defence before supervisory panel.',prereqs:'CS 501',assessments:'Written proposal (60%) + Oral defence (40%)'},
    {code:'CS 510',name:'Advanced AI Systems',year:6,sem:2,credits:20,track:['masters','ai'],desc:'Large language models, foundation models, alignment and RLHF, agent architectures, multi-modal systems. Students replicate and extend published results.',prereqs:'CS 448',assessments:'Replication project (60%) + Seminar (40%)'},
    {code:'CS 511',name:'Advanced Security Research',year:6,sem:2,credits:20,track:['masters','security'],desc:'Post-quantum cryptography, zero-knowledge systems, hardware security (SGX, TrustZone), side-channel attacks. Research mini-project.',prereqs:'CS 450',assessments:'Research project (70%) + Report (30%)'},
    {code:'CS 512',name:'Advanced Distributed Systems',year:6,sem:2,credits:20,track:['masters','systems'],desc:'Consistency models, transactional memory, coordination-free databases, geo-distributed systems. CRDT deep dive.',prereqs:'CS 452',assessments:'Project (70%) + Exam (30%)'},
    {code:'CS 560',name:'MSc Dissertation',year:6,sem:0,credits:120,track:['masters'],desc:'Original, significant contribution to knowledge in the chosen subfield. Defended orally with external examiner assessment.',prereqs:'CS 502',assessments:'Dissertation (80%) + Viva voce (20%)'},
    // Y7 PhD
    {code:'CS 601',name:'PhD Research Seminar',year:7,sem:0,credits:0,track:['phd'],desc:'Weekly seminar series. Each student presents their research annually. Invited external speakers from top universities and industry research labs.',prereqs:'PhD registration',assessments:'Annual presentation (Pass/Fail)'},
    {code:'CS 602',name:'PhD Proposal & Candidacy',year:7,sem:1,credits:0,track:['phd'],desc:'Formal PhD proposal defence. Problem motivation, related work, methodology, preliminary results, and two-year work plan. Confirms candidacy status.',prereqs:'CS 601',assessments:'Written proposal (50%) + Oral defence (50%)'},
    {code:'CS 610',name:'PhD Research in AI',year:7,sem:0,credits:0,track:['phd','ai'],desc:'Independent doctoral research in AI/ML. Targets NeurIPS, ICML, ICLR, or Nature Machine Intelligence.',prereqs:'CS 602',assessments:'Publications + Thesis'},
    {code:'CS 611',name:'PhD Research in Security',year:7,sem:0,credits:0,track:['phd','security'],desc:'Doctoral research in cybersecurity and cryptography. Targets IEEE S&P, ACM CCS, USENIX Security, or NDSS.',prereqs:'CS 602',assessments:'Publications + Thesis'},
    {code:'CS 612',name:'PhD Research in Systems',year:7,sem:0,credits:0,track:['phd','systems'],desc:'Doctoral research in HPC and distributed systems. Access to CHPC Lengau supercomputer. Targets OSDI, SOSP, EuroSys.',prereqs:'CS 602',assessments:'Publications + Thesis'},
    {code:'CS 690',name:'PhD Thesis',year:7,sem:0,credits:360,track:['phd'],desc:'An original and substantial contribution to CS knowledge. Examined by two external examiners and defended in a public viva voce. Expected duration: 3–4 years.',prereqs:'CS 602 + candidacy',assessments:'Thesis (80%) + Viva voce (20%)'},
  ];

  const YEAR_LABELS = {1:'Year 1 — Foundations',2:'Year 2 — Core',3:'Year 3 — Specialisation',4:'Year 4 — Honours',5:'Year 5 — Postgraduate',6:'Year 6 — MSc',7:'Year 7 — PhD'};
  const YEAR_COLORS = {1:'#61223b',2:'#a07a30',3:'#1a6040',4:'#1a3a70',5:'#420f27',6:'#6b2fa0',7:'#1a0a2e'};
  const TRACK_COLORS = {ai:'#3a8a6a',security:'#dc4405',systems:'#2a8a90',data:'#7a5aaa',bio:'#2a9a7a',theory:'#b07010',graphics:'#cc3377',honours:'#8a6a28',masters:'#6b2fa0',phd:'#c0392b'};

  let activeYear = 'all', activeTrack = 'all', activeSearch = '', expandedCode = null;

  function renderMods() {
    let filtered = MODS.filter(m => {
      const yearOk = activeYear === 'all' || String(m.year) === activeYear;
      const trackOk = activeTrack === 'all' || m.track.includes(activeTrack);
      const q = activeSearch.toLowerCase();
      const searchOk = !q || m.code.toLowerCase().includes(q) || m.name.toLowerCase().includes(q) || (m.desc||'').toLowerCase().includes(q);
      return yearOk && trackOk && searchOk;
    });

    const badge = document.getElementById('mod-count-badge');
    const meta = document.getElementById('mod-result-meta');
    if (badge) badge.textContent = filtered.length + ' Modules';
    if (meta) meta.textContent = filtered.length === MODS.length ? `Showing all ${MODS.length} modules` : `Showing ${filtered.length} of ${MODS.length} modules`;

    const list = document.getElementById('mod-list');
    if (!list) return;

    if (!filtered.length) {
      list.innerHTML = `<div style="padding:48px 80px;font-family:'Raleway',sans-serif;font-size:0.9rem;color:var(--page-text2);">No modules match your filters. <span style="cursor:pointer;color:var(--su-gold);text-decoration:underline;" onclick="modClearAll()">Clear all filters</span></div>`;
      return;
    }

    // Group by year
    const grouped = {};
    filtered.forEach(m => { if(!grouped[m.year]) grouped[m.year]=[]; grouped[m.year].push(m); });

    list.innerHTML = Object.keys(grouped).sort().map(yr => {
      const mods = grouped[yr];
      const col = YEAR_COLORS[yr] || 'var(--su-maroon)';
      const rows = mods.map(m => {
        const isOpen = m.code === expandedCode;
        const TRACK_LABELS={ai:'🤖 AI',security:'🔐 Security',systems:'⚡ Systems',data:'📊 Data',bio:'🧬 Bio',theory:'📐 Theory',graphics:'🎮 Graphics',honours:'🎓 Honours',masters:'📘 Masters',phd:'🔬 PhD'};
        const trackPills = m.track.map(t => `<span class="mod-track-pill" style="background:${TRACK_COLORS[t]||'#61223b'}22;color:${TRACK_COLORS[t]||'#61223b'};border:1px solid ${TRACK_COLORS[t]||'#61223b'}44;">${TRACK_LABELS[t]||t}</span>`).join('');
        const critBadge = m.critical ? `<span class="mod-critical-badge">⚠ Critical path</span>` : '';
        return `<div class="mod-row ${isOpen?'mod-row-open':''}" data-code="${m.code}" onclick="modToggle('${m.code.replace("'","\'")}')">
          <div class="mod-row-main">
            <div class="mod-row-code" style="border-left:3px solid ${col};">${m.code}</div>
            <div class="mod-row-name">${m.name}${critBadge}</div>
            <div class="mod-row-meta">
              <span class="mod-sem">${m.sem===0?'Annual':`Sem ${m.sem}`}</span>
              <span class="mod-cr">${m.credits} cr</span>
              ${trackPills}
            </div>
            <div class="mod-row-toggle">${isOpen?'−':'+'}</div>
          </div>
          ${isOpen ? `<div class="mod-row-detail">
            <div class="mod-detail-grid">
              <div class="mod-detail-block">
                <div class="mod-detail-label">Description</div>
                <div class="mod-detail-body">${m.desc}</div>
              </div>
              <div class="mod-detail-block">
                <div class="mod-detail-label">Prerequisites</div>
                <div class="mod-detail-body">${m.prereqs}</div>
              </div>
              <div class="mod-detail-block">
                <div class="mod-detail-label">Assessment</div>
                <div class="mod-detail-body">${m.assessments}</div>
              </div>
            </div>
          </div>` : ''}
        </div>`;
      }).join('');

      return `<div class="mod-year-group">
        <div class="mod-year-header" style="border-left:4px solid ${col};">
          <span class="mod-year-label">${YEAR_LABELS[yr]||'Year '+yr}</span>
          <span class="mod-year-count">${mods.length} module${mods.length!==1?'s':''}</span>
        </div>
        ${rows}
      </div>`;
    }).join('');
  }

  window.modFilter = function(yr, btn) {
    activeYear = yr;
    document.querySelectorAll('.mod-tab').forEach(b => b.classList.remove('active'));
    if(btn) btn.classList.add('active');
    expandedCode = null;
    renderMods();
  };
  window.modTrack = function(track, btn) {
    activeTrack = track;
    document.querySelectorAll('.mod-track-btn').forEach(b => b.classList.remove('active'));
    if(btn) btn.classList.add('active');
    expandedCode = null;
    renderMods();
  };
  window.modSearch = function(val) {
    activeSearch = val;
    expandedCode = null;
    const clr = document.getElementById('mod-clear');
    if(clr) clr.style.display = val ? 'block' : 'none';
    renderMods();
  };
  window.modClearSearch = function() {
    activeSearch = '';
    const inp = document.getElementById('mod-search');
    if(inp) inp.value = '';
    const clr = document.getElementById('mod-clear');
    if(clr) clr.style.display = 'none';
    renderMods();
  };
  window.modClearAll = function() {
    activeYear = 'all'; activeTrack = 'all'; activeSearch = '';
    const inp = document.getElementById('mod-search');
    if(inp) inp.value = '';
    document.querySelectorAll('.mod-tab').forEach((b,i)=>b.classList.toggle('active',i===0));
    document.querySelectorAll('.mod-track-btn').forEach((b,i)=>b.classList.toggle('active',i===0));
    expandedCode = null;
    renderMods();
  };
  window.modToggle = function(code) {
    expandedCode = expandedCode === code ? null : code;
    renderMods();
    if(expandedCode) {
      setTimeout(()=>{
        const el = document.querySelector(`.mod-row[data-code="${code}"]`);
        if(el) el.scrollIntoView({behavior:'smooth',block:'nearest'});
      },50);
    }
  };

  renderMods();
}},

  6:{label:'Research',fullLabel:'Research Groups, Labs & Centres',render:()=>`
  <div class="pg-inner-wide">
    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Research Excellence</div>
      <h1>Research Groups,<br>Labs &amp; Centres</h1>
      <p class="pg-hero-sub">Internationally recognised research groups with active postgraduate programmes and external funding. All groups welcome prospective MSc and PhD students.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge">R14.2M Active Funding</span>
        <span class="pg-hero-badge">6 Research Groups</span>
        <span class="pg-hero-badge">12+ PhD Students</span>
      </div>
    </div>

    <div class="pg-spotlight-grid" style="padding-top:0;">
      <div class="pg-spotlight-card">
        <span class="pg-spotlight-icon">🤖</span>
        <div class="pg-spotlight-title">AI Research Lab (AIRL)</div>
        <p class="pg-spotlight-body">Machine learning, NLP for African languages, computer vision, responsible AI, and neural architecture. PI: Prof. Dlamini. Partners: Google DeepMind Africa, CSIR, DSI.</p>
        <div class="pg-spotlight-meta">NRF A-rated · R8.5M DSI grant · 12 PhD students · <span class="m-tag green">Open to students</span></div>
      </div>
      <div class="pg-spotlight-card accent">
        <span class="pg-spotlight-icon">🔐</span>
        <div class="pg-spotlight-title">Centre for Cybersecurity (CCS)</div>
        <p class="pg-spotlight-body">Cryptography, post-quantum security, digital forensics, network defence, and threat intelligence. PI: Prof. Botha. Accredited under NCPF. Publishing at IEEE S&amp;P, ACM CCS, USENIX.</p>
        <div class="pg-spotlight-meta">Govt-accredited · R3.2M funding · IEEE Senior Member · <span class="m-tag green">Open to students</span></div>
      </div>
      <div class="pg-spotlight-card accent2">
        <span class="pg-spotlight-icon">🧬</span>
        <div class="pg-spotlight-title">Computational Biology Group (CBG)</div>
        <p class="pg-spotlight-body">Bioinformatics pipelines for Southern African genomics, phylogenetics, and metagenomics. SARChI Chair: Prof. Naidoo. H3Africa consortium member and NIH supplement recipient.</p>
        <div class="pg-spotlight-meta">SARChI R5M · NIH supplement · H3Africa PI · <span class="m-tag green">Open to students</span></div>
      </div>
      <div class="pg-spotlight-card accent3">
        <span class="pg-spotlight-icon">⚡</span>
        <div class="pg-spotlight-title">High-Performance Computing Group</div>
        <p class="pg-spotlight-body">Parallel algorithms, GPU computing, distributed systems, and cloud infrastructure. Lead: Assoc. Prof. Engelbrecht. CHPC national committee member with AWS and Azure research credits.</p>
        <div class="pg-spotlight-meta">CHPC advisory board · AWS &amp; Azure credits · <span class="m-tag green">Open to students</span></div>
      </div>
      <div class="pg-spotlight-card">
        <span class="pg-spotlight-icon">📐</span>
        <div class="pg-spotlight-title">Formal Methods Group</div>
        <p class="pg-spotlight-body">Theorem proving, model checking, program verification, and smart contract verification. Lead: Assoc. Prof. Mokoena. Active collaboration with INRIA (France) and MPI-SWS (Germany).</p>
        <div class="pg-spotlight-meta">NRF R1.1M · INRIA collaboration · <span class="m-tag green">Open to students</span></div>
      </div>
      <div class="pg-spotlight-card accent4">
        <span class="pg-spotlight-icon">🎮</span>
        <div class="pg-spotlight-title">Computer Graphics &amp; Vision Lab</div>
        <p class="pg-spotlight-body">Real-time rendering, physically-based shading, augmented reality, drone-captured imagery processing, and remote sensing for environmental applications. Lead: Dr. Hendricks &amp; Dr. Sithole.</p>
        <div class="pg-spotlight-meta">Industry partnerships · <span class="m-tag green">Open to students</span></div>
      </div>
    </div>

    <div class="pg-section-label">Research Trends &amp; Output</div>
    <div class="pg-feature-strip" style="margin-bottom:0;">
      <div style="padding:36px 48px;">
        <p style="font-family:'Raleway',sans-serif;font-size:0.9rem;color:var(--page-text2);margin-bottom:20px;line-height:1.7;">Publication output, citation impact, and international collaborations — 2019 to 2024. Use the slider to highlight a specific year.</p>
        <div class="chart-container"><canvas id="research-trends-chart"></canvas></div>
        <div class="m-slider-wrap" style="margin-top:16px;">
          <div class="m-slider-label">Highlight year <span class="m-slider-val" id="yr-val">2024</span></div>
          <input type="range" id="yr-slider" min="2019" max="2024" value="2024" step="1" oninput="document.getElementById('yr-val').textContent=this.value">
        </div>
      </div>
    </div>

    <div class="pg-section-label" style="margin-top:48px;">Live Research Output</div>
    <div style="padding:0 80px 60px;">
      <div class="m-api-badge" style="margin-bottom:16px;">Real-time data from OpenAlex Academic API</div>
      <div id="mpubs-labs"><div class="m-loading"><div class="m-spinner"></div>Loading…</div></div>
    </div>
  </div>
  `,onMount:()=>{fetchPubs(ALEX_BASE+'&sort=cited_by_count:desc&per-page=6&select=title,authorships,primary_location,publication_year,doi,cited_by_count,primary_topic','mpubs-labs',6,true);setTimeout(()=>initResearchChart(),100);}},

  7:{label:'News',fullLabel:'News, Announcements & Press Releases',render:()=>`
  <div class="pg-inner-wide">
    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Newsroom · Live Feed</div>
      <h1>News &amp;<br>Announcements</h1>
      <p class="pg-hero-sub">Live newsroom feed from Stellenbosch University — research breakthroughs, awards, events, and press releases from Africa's leading CS department.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge" id="m-news-count">Loading…</span>
        <span class="pg-hero-badge">SU Newsroom Feed</span>
        <span class="pg-hero-badge" id="m-news-freshness">–</span>
      </div>
    </div>

    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:space-between;border-bottom:1px solid var(--page-border);padding-bottom:16px;margin-bottom:32px;">
      <div style="font-family:'Share Tech Mono',monospace;font-size:1.04rem;color:var(--page-text2);" id="m-news-meta">Loading latest news…</div>
      <div style="display:flex;gap:8px;">
        <button class="m-topbar-btn" id="m-news-refresh" type="button">↻ Refresh</button>
        <a class="m-topbar-btn" href="https://www.su.ac.za/en/news?language=en" target="_blank" rel="noopener">SU Newsroom ↗</a>
      </div>
    </div>

    <div id="m-news-error" class="m-api-err" style="display:none;margin-bottom:24px;"></div>
    <div id="m-news-featured" style="margin-bottom:40px;"></div>
    <div class="pg-section-label" id="m-news-section-label" style="display:none;">More Stories</div>
    <div id="m-news-list" class="pg-spotlight-grid" style="padding-bottom:80px;"></div>
  </div>
`,onMount:()=>{loadSUNews();}},

  8:{label:'Events',fullLabel:'Events & Seminars Calendar',render:()=>`
  <div class="pg-inner-wide">
    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Events Calendar · Live Feed</div>
      <h1>Events &amp;<br>Seminars</h1>
      <p class="pg-hero-sub">Live upcoming events from Stellenbosch University — research seminars, workshops, industry talks, and department gatherings throughout the year.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge" id="m-events-count">Loading…</span>
        <span class="pg-hero-badge">SU Events Feed</span>
        <span class="pg-hero-badge" id="m-events-freshness">–</span>
      </div>
    </div>

    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:space-between;border-bottom:1px solid var(--page-border);padding-bottom:16px;margin-bottom:32px;">
      <div style="font-family:'Share Tech Mono',monospace;font-size:0.65rem;color:var(--page-text2);" id="m-events-meta">Loading upcoming events…</div>
      <div style="display:flex;gap:8px;">
        <button class="m-topbar-btn" id="m-events-refresh" type="button">↻ Refresh</button>
        <a class="m-topbar-btn" href="https://www.su.ac.za/en/staff/events" target="_blank" rel="noopener">SU Events ↗</a>
      </div>
    </div>

    <div id="m-events-error" class="m-api-err" style="display:none;margin-bottom:24px;"></div>
    <div class="pg-section-label">Upcoming Events</div>
    <div id="m-events-list" style="padding-bottom:80px;"></div>
  </div>
  `,onMount:()=>{loadSUEvents();}},
9:{label:'Students',fullLabel:'Student Resources — FAQs, Forms & Community',render:()=>`
  <div class="pg-inner-wide">

    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Student Portal</div>
      <h1>Student Resources<br>&amp; Community</h1>
      <p class="pg-hero-sub">Everything a CS student at Stellenbosch University needs — answers, tools, forms, and the societies that make the degree worth it.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge">7 FAQ Topics</span>
        <span class="pg-hero-badge">18 Resource Links</span>
        <span class="pg-hero-badge">5 Student Societies</span>
        <span class="pg-hero-badge">6 Academic Forms</span>
      </div>
    </div>

    <!-- FAQ -->
    <div class="pg-section-label">Frequently Asked Questions</div>
    <div class="pg-feature-strip">
      <div class="pg-feature-row">
        <div class="pg-feature-num">01</div>
        <div class="pg-feature-title">How do I register for modules?</div>
        <div class="pg-feature-body">Done through <strong>SUNStudent</strong> during the pre-registration and registration periods. Check your study contract and prerequisites first. Contact the UG Coordinator in Room G.05 if anything blocks.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">02</div>
        <div class="pg-feature-title">What is the minimum pass mark?</div>
        <div class="pg-feature-body">A minimum of <strong>50%</strong> is required to pass any CS module. Some modules have sub-minimums (typically 40%) for practicals or exam components — check your study guide on day one.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">03</div>
        <div class="pg-feature-title">How do I apply for a special exam?</div>
        <div class="pg-feature-body">Submit an aegrotat / extraordinary application to <strong>Student Admin (IR)</strong> within 5 working days of the missed assessment, with supporting documentation. The UG Coordinator can help with department-level guidance.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">04</div>
        <div class="pg-feature-title">Where do I find notes and assignments?</div>
        <div class="pg-feature-body">All course materials are on <strong>SUNLearn</strong> (Moodle). Some lecturers use <strong>GitHub Classroom</strong> for programming assignments — check the module study guide in the first week.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">05</div>
        <div class="pg-feature-title">Can I repeat a module I already passed?</div>
        <div class="pg-feature-body">Generally no — Faculty approval is required. Focus that energy on higher-level modules where foundational skills are tested again at greater depth and count for more.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">06</div>
        <div class="pg-feature-title">How do I access tutoring or academic support?</div>
        <div class="pg-feature-body">The department runs a <strong>peer tutoring programme</strong> for Year 1–2 modules. The university's <strong>Academic Support</strong> centre provides writing and mathematics help free to all registered students.</div>
      </div>
      <div class="pg-feature-row" style="border-bottom:none;">
        <div class="pg-feature-num">07</div>
        <div class="pg-feature-title">When is the department office open?</div>
        <div class="pg-feature-body"><strong>Room G.05</strong>, CS Building, Banghoek Street. Monday–Thursday 08:00–16:30 · Friday 08:00–15:30. Always include your student number in any email correspondence.</div>
      </div>
    </div>

    <!-- RESOURCES -->
    <div class="pg-section-label">Resources &amp; Tools</div>
    <div class="pg-spotlight-grid">
      <div class="pg-spotlight-card">
        <span class="pg-spotlight-icon">🎓</span>
        <div class="pg-spotlight-title">Academic Systems</div>
        <p class="pg-spotlight-body">The core university platforms every student must know. Registration, results, and all course materials live here.</p>
        <div class="pg-spotlight-meta">
          <a href="https://student.sun.ac.za" target="_blank" style="color:var(--su-gold);text-decoration:none;">SUNStudent ↗</a> &nbsp;·&nbsp;
          <a href="https://learn.sun.ac.za" target="_blank" style="color:var(--su-gold);text-decoration:none;">SUNLearn ↗</a> &nbsp;·&nbsp;
          <a href="https://sun.ac.za" target="_blank" style="color:var(--su-gold);text-decoration:none;">SU Portal ↗</a>
        </div>
      </div>
      <div class="pg-spotlight-card accent2">
        <span class="pg-spotlight-icon">💻</span>
        <div class="pg-spotlight-title">Developer Tools</div>
        <p class="pg-spotlight-body">Free cloud credits, IDEs, and lab access available to all CS students. Activate your GitHub Student Pack before your first semester.</p>
        <div class="pg-spotlight-meta">
          <a href="https://github.com" target="_blank" style="color:var(--su-gold);text-decoration:none;">GitHub Pack ↗</a> &nbsp;·&nbsp;
          <a href="https://azure.microsoft.com/en-us/free/students/" target="_blank" style="color:var(--su-gold);text-decoration:none;">Azure ↗</a> &nbsp;·&nbsp;
          <a href="https://www.jetbrains.com/student/" target="_blank" style="color:var(--su-gold);text-decoration:none;">JetBrains ↗</a>
        </div>
      </div>
      <div class="pg-spotlight-card accent3">
        <span class="pg-spotlight-icon">📚</span>
        <div class="pg-spotlight-title">Research &amp; Library</div>
        <p class="pg-spotlight-body">Full access to SU's digital library and academic databases. Supplement with open-access sources for literature reviews.</p>
        <div class="pg-spotlight-meta">
          <a href="https://library.sun.ac.za" target="_blank" style="color:var(--su-gold);text-decoration:none;">SU Library ↗</a> &nbsp;·&nbsp;
          <a href="https://scholar.google.com" target="_blank" style="color:var(--su-gold);text-decoration:none;">Scholar ↗</a> &nbsp;·&nbsp;
          <a href="https://openalex.org" target="_blank" style="color:var(--su-gold);text-decoration:none;">OpenAlex ↗</a>
        </div>
      </div>
      <div class="pg-spotlight-card accent">
        <span class="pg-spotlight-icon">🏥</span>
        <div class="pg-spotlight-title">Wellness &amp; Support</div>
        <p class="pg-spotlight-body">Mental health, physical wellbeing, disability access, and financial aid. Support structures are in place — use them.</p>
        <div class="pg-spotlight-meta">
          <a href="https://www.sun.ac.za/english/students/Pages/Wellness.aspx" target="_blank" style="color:var(--su-gold);text-decoration:none;">Wellness Centre ↗</a> &nbsp;·&nbsp;
          <a href="https://www.sun.ac.za/english/students/Pages/disability.aspx" target="_blank" style="color:var(--su-gold);text-decoration:none;">Disability Unit ↗</a>
        </div>
      </div>
      <div class="pg-spotlight-card accent4">
        <span class="pg-spotlight-icon">🖥️</span>
        <div class="pg-spotlight-title">Online Learning</div>
        <p class="pg-spotlight-body">World-class CS courses from MIT, Harvard, and Stanford to supplement your degree. Free audit tracks available on most platforms.</p>
        <div class="pg-spotlight-meta">
          <a href="https://ocw.mit.edu" target="_blank" style="color:var(--su-gold);text-decoration:none;">MIT OCW ↗</a> &nbsp;·&nbsp;
          <a href="https://www.coursera.org" target="_blank" style="color:var(--su-gold);text-decoration:none;">Coursera ↗</a> &nbsp;·&nbsp;
          <a href="https://www.edx.org" target="_blank" style="color:var(--su-gold);text-decoration:none;">edX ↗</a>
        </div>
      </div>
      <div class="pg-spotlight-card">
        <span class="pg-spotlight-icon">💼</span>
        <div class="pg-spotlight-title">Careers &amp; Industry</div>
        <p class="pg-spotlight-body">Internship listings, graduate programmes, and direct employer connections. Start building your profile in Year 2, not Year 4.</p>
        <div class="pg-spotlight-meta">
          <a href="https://sun.ac.za/careers" target="_blank" style="color:var(--su-gold);text-decoration:none;">SU Careers ↗</a> &nbsp;·&nbsp;
          <a href="https://www.graduategateway.com" target="_blank" style="color:var(--su-gold);text-decoration:none;">Grad Gateway ↗</a> &nbsp;·&nbsp;
          <a href="https://www.linkedin.com" target="_blank" style="color:var(--su-gold);text-decoration:none;">LinkedIn ↗</a>
        </div>
      </div>
    </div>

    <!-- FORMS -->
    <div class="pg-section-label">Academic Forms</div>
    <div class="pg-feature-strip">
      <div class="pg-feature-row">
        <div class="pg-feature-num" style="font-size:1.5rem;color:var(--su-gold-d);align-self:center;">G.05</div>
        <div class="pg-feature-title">Module Prerequisite Override</div>
        <div class="pg-feature-body">Request to register for a module without completing its stated prerequisite. Requires written academic motivation and HoD approval. &nbsp;<span class="m-tag">UG Coordinator</span></div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num" style="font-size:1.5rem;color:var(--su-gold-d);align-self:center;">IR</div>
        <div class="pg-feature-title">Special Exam Application</div>
        <div class="pg-feature-body">Aegrotat / Extraordinary exam request for a missed assessment. Medical or equivalent documentation required within 5 working days. &nbsp;<span class="m-tag">Student Admin</span></div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num" style="font-size:1.5rem;color:var(--su-gold-d);align-self:center;">G.05</div>
        <div class="pg-feature-title">Study Contract Change</div>
        <div class="pg-feature-body">Modify your programme, specialisation track, or module selections outside standard registration windows. &nbsp;<span class="m-tag">Department Office</span></div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num" style="font-size:1.5rem;color:var(--su-gold-d);align-self:center;">PG</div>
        <div class="pg-feature-title">Postgraduate Supervision Agreement</div>
        <div class="pg-feature-body">Required for all Honours, MSc, and PhD students confirming a supervisor relationship. Signed by both parties before submission. &nbsp;<span class="m-tag gold">PG Administrator</span></div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num" style="font-size:1.5rem;color:var(--su-gold-d);align-self:center;">REC</div>
        <div class="pg-feature-title">Research Ethics Declaration</div>
        <div class="pg-feature-body">Required for research involving human subjects or sensitive datasets. Must be submitted and approved before data collection begins. &nbsp;<span class="m-tag">SU Ethics Office</span></div>
      </div>
      <div class="pg-feature-row" style="border-bottom:none;">
        <div class="pg-feature-num" style="font-size:1.5rem;color:var(--su-gold-d);align-self:center;">FAC</div>
        <div class="pg-feature-title">Credit Transfer Application</div>
        <div class="pg-feature-body">Recognition of prior learning or modules from another accredited institution. Requires official transcripts and module outlines. &nbsp;<span class="m-tag">Faculty Admin</span></div>
      </div>
    </div>

    <!-- SOCIETIES -->
    <div class="pg-section-label">Student Societies</div>
    <div class="pg-spotlight-grid" style="padding-bottom:80px;">
      <div class="pg-spotlight-card">
        <span class="pg-spotlight-icon">💻</span>
        <div class="pg-spotlight-title">CS Student Society</div>
        <p class="pg-spotlight-body">The main student body for CS at Stellenbosch. Coding competitions, hackathons, industry talks, alumni panels, and social events throughout the year.</p>
        <div class="pg-spotlight-meta"><span class="m-tag green">Open to all CS students</span></div>
      </div>
      <div class="pg-spotlight-card accent">
        <span class="pg-spotlight-icon">🔐</span>
        <div class="pg-spotlight-title">Cybersecurity Club</div>
        <p class="pg-spotlight-body">CTF competitions, ethical hacking workshops, and red-team exercises. Competes nationally in the SASA Cyber Challenge each year.</p>
        <div class="pg-spotlight-meta"><span class="m-tag green">Open to all · No prior experience needed</span></div>
      </div>
      <div class="pg-spotlight-card accent2">
        <span class="pg-spotlight-icon">🤖</span>
        <div class="pg-spotlight-title">AI &amp; Data Science Club</div>
        <p class="pg-spotlight-body">Kaggle competitions, ML paper reading groups, industry mentorship, and project showcases. The fastest-growing society in the department.</p>
        <div class="pg-spotlight-meta"><span class="m-tag green">Open to all years</span></div>
      </div>
      <div class="pg-spotlight-card accent3">
        <span class="pg-spotlight-icon">🚀</span>
        <div class="pg-spotlight-title">TechVentures Society</div>
        <p class="pg-spotlight-body">For student entrepreneurs. Startup workshops, pitch nights, and direct connections to the Innovus technology transfer ecosystem at SU.</p>
        <div class="pg-spotlight-meta"><span class="m-tag green">Open to all faculties</span></div>
      </div>
      <div class="pg-spotlight-card accent4">
        <span class="pg-spotlight-icon">🧬</span>
        <div class="pg-spotlight-title">Bioinformatics &amp; Comp Sci</div>
        <p class="pg-spotlight-body">Bridging CS, biology, and data science. Partners with the African Genome Centre for student research placement opportunities and co-supervised projects.</p>
        <div class="pg-spotlight-meta"><span class="m-tag green">Interdisciplinary · All welcome</span></div>
      </div>
      <div class="pg-spotlight-card" style="border-top-color:var(--su-gold-d);">
        <span class="pg-spotlight-icon" style="font-size:2rem;">💡</span>
        <div class="pg-spotlight-title" style="font-size:1rem;">Start a New Society</div>
        <p class="pg-spotlight-body" style="font-size:0.88rem;">Have an idea for a new student group? Talk to the CS Student Representative Council or the UG Coordinator. The department actively supports new initiatives.</p>
        <div class="pg-spotlight-meta"><span class="m-tag gold">Talk to Room G.05</span></div>
      </div>
    </div>

  </div>
`,onMount:()=>{}},

10:{label:'Contact',fullLabel:'Contact, Location & Directions',render:()=>`
  <div class="pg-inner-wide">

    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Location & Directions</div>
      <h1>Contact<br>&amp; Find Us</h1>
      <p class="pg-hero-sub">We're on Banghoek Street in the heart of Stellenbosch — 50 minutes from Cape Town, and at the centre of Africa's most exciting computing research scene.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge">CS Building</span>
        <span class="pg-hero-badge" id="c5-hero-status">Check Hours</span>
        <span class="pg-hero-badge">+27 21 808 4200</span>
        <span class="pg-hero-badge">4 Key Contacts</span>
      </div>
    </div>

    <div class="pg-section-label">Building & Location</div>
    <div class="pg-feature-strip">
      <div class="pg-feature-row">
        <div class="pg-feature-num">📍</div>
        <div class="pg-feature-title">Physical Address</div>
        <div class="pg-feature-body"><strong>CS Building</strong>, corner of Banghoek &amp; Joubert Streets, Stellenbosch, 7600, Western Cape, South Africa. GPS: −33.9310, 18.8628 &nbsp;<span class="m-tag">Building code: CS-MAIN</span></div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">📞</div>
        <div class="pg-feature-title">General Enquiries</div>
        <div class="pg-feature-body">Main line: <a href="tel:+27218084200" style="color:var(--su-gold);text-decoration:none;font-weight:700;">+27 (0)21 808 4200</a> &nbsp;·&nbsp; Email: <a href="mailto:cs-office@sun.ac.za" style="color:var(--su-gold);text-decoration:none;">cs-office@sun.ac.za</a> &nbsp;·&nbsp; Website: <a href="https://cs.sun.ac.za" target="_blank" style="color:var(--su-gold);text-decoration:none;">cs.sun.ac.za ↗</a></div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">🕐</div>
        <div class="pg-feature-title">Office Hours</div>
        <div class="pg-feature-body">Monday–Thursday <strong>08:00–16:30</strong> &nbsp;<span id="c5-stat-mon"></span> &nbsp;·&nbsp; Friday <strong>08:00–15:30</strong> &nbsp;<span id="c5-stat-fri"></span> &nbsp;·&nbsp; Saturday–Sunday <span style="color:var(--su-orange);font-weight:600;">Closed</span></div>
      </div>
      <div class="pg-feature-row" style="border-bottom:none;">
        <div class="pg-feature-num">🅿</div>
        <div class="pg-feature-title">Parking</div>
        <div class="pg-feature-body">Banghoek Parking Garage directly adjacent to the building (paid, open to visitors). Disabled parking bays on the ground level of the CS Building.</div>
      </div>
    </div>

    <div class="pg-section-label">Interactive Map</div>
    <div style="border:1px solid var(--page-border);border-radius:2px;overflow:hidden;margin-bottom:48px;">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3310.4!2d18.8648!3d-33.9324!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1dcdb24f69c7d2e1%3A0x8d3b3e8e5e5e5e5e!2sDepartment%20of%20Computer%20Science%2C%20Stellenbosch%20University!5e0!3m2!1sen!2sza!4v1700000000000"
        width="100%" height="400" style="border:0;display:block;" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>

    <div class="pg-section-label">Key Contacts</div>
    <div class="pg-spotlight-grid">
      <div class="pg-spotlight-card">
        <span class="pg-spotlight-icon">🎓</span>
        <div class="pg-spotlight-title">Head of Department</div>
        <p class="pg-spotlight-body">Prof. A. van Zyl leads the department's academic and research strategy.</p>
        <div class="pg-spotlight-meta"><a href="mailto:avanzyl@cs.sun.ac.za" style="color:var(--su-gold);text-decoration:none;">avanzyl@cs.sun.ac.za ↗</a><br><span style="font-size:0.78rem;color:var(--page-text2);">Room 1.24 · By appointment</span></div>
      </div>
      <div class="pg-spotlight-card accent">
        <span class="pg-spotlight-icon">📋</span>
        <div class="pg-spotlight-title">UG Coordinator</div>
        <p class="pg-spotlight-body">Ms. T. Joubert handles undergraduate queries — registration, forms, prerequisite overrides.</p>
        <div class="pg-spotlight-meta"><a href="mailto:ug-cs@sun.ac.za" style="color:var(--su-gold);text-decoration:none;">ug-cs@sun.ac.za ↗</a><br><span style="font-size:0.78rem;color:var(--page-text2);">Room G.05 · Walk-ins welcome</span></div>
      </div>
      <div class="pg-spotlight-card accent2">
        <span class="pg-spotlight-icon">🔬</span>
        <div class="pg-spotlight-title">PG Administrator</div>
        <p class="pg-spotlight-body">Mr. L. Abrahams manages all postgraduate administration — supervision, bursaries, submissions.</p>
        <div class="pg-spotlight-meta"><a href="mailto:pg-cs@sun.ac.za" style="color:var(--su-gold);text-decoration:none;">pg-cs@sun.ac.za ↗</a><br><span style="font-size:0.78rem;color:var(--page-text2);">Room G.06 · 09:00–15:00</span></div>
      </div>
      <div class="pg-spotlight-card accent3">
        <span class="pg-spotlight-icon">🖥️</span>
        <div class="pg-spotlight-title">IT & Technical Support</div>
        <p class="pg-spotlight-body">Lab access, software requests, network issues, and hardware faults in CS teaching labs.</p>
        <div class="pg-spotlight-meta"><a href="mailto:cs-support@sun.ac.za" style="color:var(--su-gold);text-decoration:none;">cs-support@sun.ac.za ↗</a><br><span style="font-size:0.78rem;color:var(--page-text2);">Room B01 · 08:00–17:00</span></div>
      </div>
    </div>

    <div class="pg-section-label">Getting Here</div>
    <div class="pg-feature-strip" style="padding-bottom:80px;">
      <div class="pg-feature-row">
        <div class="pg-feature-num">🚗</div>
        <div class="pg-feature-title">By Car from Cape Town</div>
        <div class="pg-feature-body">Take the <strong>N2</strong> eastbound to the <strong>R310</strong> (Helshoogte Pass exit), follow signs into Stellenbosch central. CS Building is on <strong>Banghoek Street</strong> — approximately 50 minutes from Cape Town CBD.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">🚂</div>
        <div class="pg-feature-title">By Train (Metrorail)</div>
        <div class="pg-feature-body">Take the <strong>Cape Town–Stellenbosch</strong> Metrorail line to Stellenbosch station. The CS Building is a 1.2 km walk (±15 min) or a short e-hailing ride. Trains run every <strong>30 minutes</strong> during peak hours.</div>
      </div>
      <div class="pg-feature-row">
        <div class="pg-feature-num">🚌</div>
        <div class="pg-feature-title">By Intercity Coach</div>
        <div class="pg-feature-body"><strong>Intercape</strong> and <strong>Greyhound</strong> coaches serve Stellenbosch town centre. The CS Building is a 10-minute walk east along Dorp Street toward the university campus.</div>
      </div>
      <div class="pg-feature-row" style="border-bottom:none;">
        <div class="pg-feature-num">🚲</div>
        <div class="pg-feature-title">On Campus & Cycling</div>
        <div class="pg-feature-body">Stellenbosch is highly <strong>cycling-friendly</strong>. 8-minute ride from town centre. Secure bicycle parking at the building entrance. The SU hop-on-hop-off shuttle also stops near the CS Building.</div>
      </div>
    </div>

  </div>
`,onMount:()=>{
  const now=new Date(), day=now.getDay(), h=now.getHours();
  const mk=open=>`<span style="font-family:'Share Tech Mono',monospace;font-size:0.7rem;padding:2px 7px;border-radius:2px;background:${open?'rgba(82,200,120,0.12)':'rgba(220,68,5,0.12)'};color:${open?'#52c878':'#dc4405'};border:1px solid ${open?'rgba(82,200,120,0.3)':'rgba(220,68,5,0.3)'};">● ${open?'OPEN':'CLOSED'}</span>`;
  const wkday=day>=1&&day<=4, fri=day===5;
  const m=document.getElementById('c5-stat-mon'), f=document.getElementById('c5-stat-fri');
  const s=document.getElementById('c5-hero-status');
  if(m) m.innerHTML=mk(wkday&&h>=8&&h<17);
  if(f) f.innerHTML=mk(fri&&h>=8&&h<16);
  const isOpen=(wkday&&h>=8&&h<17)||(fri&&h>=8&&h<16);
  if(s){ s.style.color=isOpen?'#52c878':'#dc4405'; s.textContent=isOpen?'● Office Open Now':'● Office Closed'; }
}},

11:{label:'Advisor',fullLabel:'Degree Advisor — Smart Pathway Planner',render:()=>`
  <div class="pg-inner-wide">

    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Personalised Degree Planning · Stellenbosch CS</div>
      <h1>Build Your<br>Perfect Pathway</h1>
      <p class="pg-hero-sub">Answer up to 14 questions for a deeply personalised year-by-year plan, track match, module-level advice, lab recommendations, internship timeline, and career projections.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge" id="a5-badge-pct">0% complete</span>
        <span class="pg-hero-badge">14 Dimensions</span>
        <span class="pg-hero-badge">Career Projections</span>
        <span class="pg-hero-badge">Graph-Linked</span>
      </div>
    </div>

    <div style="height:3px;background:var(--page-border);margin:0 24px 32px;overflow:hidden;">
      <div id="a5-prog-fill" style="height:100%;width:0%;background:linear-gradient(90deg,var(--su-maroon),var(--su-gold));transition:width 0.4s ease;"></div>
    </div>

    <div class="adv-card-grid">

      <!-- Step 1: Interests -->
      <div class="adv-card adv-card-wide" id="adv-card-1">
        <div class="adv-card-num" style="animation-delay:-1.7s">01</div>
        <div class="adv-card-title">Interest Areas <span class="adv-req">Required</span></div>
        <div class="adv-card-hint">Select all that apply — your primary interest shapes the entire plan</div>
        <div class="adv-chips" id="adv-interests">
          <div class="a5-chip" data-val="ai" onclick="advToggle(this);a5Prog()">🤖 AI & Machine Learning</div>
          <div class="a5-chip" data-val="security" onclick="advToggle(this);a5Prog()">🔐 Cybersecurity</div>
          <div class="a5-chip" data-val="data" onclick="advToggle(this);a5Prog()">📊 Data Science & Analytics</div>
          <div class="a5-chip" data-val="systems" onclick="advToggle(this);a5Prog()">⚡ Systems, HPC & Cloud</div>
          <div class="a5-chip" data-val="bio" onclick="advToggle(this);a5Prog()">🧬 Bioinformatics & Computational Biology</div>
          <div class="a5-chip" data-val="theory" onclick="advToggle(this);a5Prog()">📐 Theory, Logic & Formal Methods</div>
          <div class="a5-chip" data-val="graphics" onclick="advToggle(this);a5Prog()">🎮 Graphics, Vision & XR</div>
        </div>
      </div>

      <!-- Step 2: Career Goal -->
      <div class="adv-card" id="adv-card-2">
        <div class="adv-card-num" style="animation-delay:-4.2s">02</div>
        <div class="adv-card-title">Career Goal <span class="adv-req">Required</span></div>
        <div class="adv-card-hint">This determines which electives and postgrad modules to prioritise</div>
        <div class="adv-chips" id="adv-goal">
          <div class="a5-chip" data-val="industry" onclick="advSingle(this,'adv-goal');a5Prog()">💼 Industry / Corporate</div>
          <div class="a5-chip" data-val="research" onclick="advSingle(this,'adv-goal');a5Prog()">🔬 Research (MSc/PostDoc)</div>
          <div class="a5-chip" data-val="phd" onclick="advSingle(this,'adv-goal');a5Prog()">🎓 PhD / Academia</div>
          <div class="a5-chip" data-val="startup" onclick="advSingle(this,'adv-goal');a5Prog()">🚀 Startup / Entrepreneur</div>
          <div class="a5-chip" data-val="consulting" onclick="advSingle(this,'adv-goal');a5Prog()">📋 Consulting / Advisory</div>
          <div class="a5-chip" data-val="ngo" onclick="advSingle(this,'adv-goal');a5Prog()">🌍 NGO / Public Sector / Gov</div>
        </div>
      </div>

      <!-- Step 3: Current Year -->
      <div class="adv-card" id="adv-card-3">
        <div class="adv-card-num" style="animation-delay:-0.9s">03</div>
        <div class="adv-card-title">Current Year Level <span class="adv-req">Required</span></div>
        <div class="adv-card-hint">We tailor the urgency and focus of module recommendations to where you are now</div>
        <div class="adv-chips" id="adv-skill">
          <div class="a5-chip" data-val="1" onclick="advSingle(this,'adv-skill');a5Prog()">Y1 — Foundations</div>
          <div class="a5-chip" data-val="2" onclick="advSingle(this,'adv-skill');a5Prog()">Y2 — Core CS</div>
          <div class="a5-chip" data-val="3" onclick="advSingle(this,'adv-skill');a5Prog()">Y3 — Specialisation</div>
          <div class="a5-chip" data-val="4" onclick="advSingle(this,'adv-skill');a5Prog()">Y4 — Honours</div>
          <div class="a5-chip" data-val="postgrad" onclick="advSingle(this,'adv-skill');a5Prog()">Postgraduate (MSc/PhD)</div>
          <div class="a5-chip" data-val="considering" onclick="advSingle(this,'adv-skill');a5Prog()">🤔 Considering Applying</div>
        </div>
      </div>

      <!-- Step 4: Maths Depth -->
      <div class="adv-card" id="adv-card-4">
        <div class="adv-card-num" style="animation-delay:-6.1s">04</div>
        <div class="adv-card-title">Mathematical Depth</div>
        <div class="adv-card-hint">Optional — affects which theory-heavy modules we recommend</div>
        <div class="adv-chips" id="adv-math">
          <div class="a5-chip" data-val="high" onclick="advSingle(this,'adv-math');a5Prog()">🔥 Love deep maths — proofs, analysis</div>
          <div class="a5-chip" data-val="medium" onclick="advSingle(this,'adv-math');a5Prog()">⚖ Comfortable with applied maths</div>
          <div class="a5-chip" data-val="low" onclick="advSingle(this,'adv-math');a5Prog()">🛠 Prefer practical / minimal maths</div>
        </div>
      </div>

      <!-- Step 5: Work Style -->
      <div class="adv-card" id="adv-card-5">
        <div class="adv-card-num" style="animation-delay:-2.8s">05</div>
        <div class="adv-card-title">Work Style Preference</div>
        <div class="adv-card-hint">Optional — shapes project type and role recommendations</div>
        <div class="adv-chips" id="adv-teamwork">
          <div class="a5-chip" data-val="solo" onclick="advSingle(this,'adv-teamwork');a5Prog()">🧑‍💻 Deep solo focus</div>
          <div class="a5-chip" data-val="mixed" onclick="advSingle(this,'adv-teamwork');a5Prog()">🤝 Mix of solo and team</div>
          <div class="a5-chip" data-val="team" onclick="advSingle(this,'adv-teamwork');a5Prog()">👥 Collaborative team work</div>
          <div class="a5-chip" data-val="lead" onclick="advSingle(this,'adv-teamwork');a5Prog()">🎯 Leading / managing others</div>
        </div>
      </div>

      <!-- Step 6: Study Pace -->
      <div class="adv-card" id="adv-card-6">
        <div class="adv-card-num" style="animation-delay:-7.3s">06</div>
        <div class="adv-card-title">Study Pace & Priority</div>
        <div class="adv-card-hint">Optional — determines elective load and internship timing advice</div>
        <div class="adv-chips" id="adv-time">
          <div class="a5-chip" data-val="fast" onclick="advSingle(this,'adv-time');a5Prog()">⚡ Fast-track — finish ASAP</div>
          <div class="a5-chip" data-val="balanced" onclick="advSingle(this,'adv-time');a5Prog()">⚖ Balanced — quality + speed</div>
          <div class="a5-chip" data-val="deep" onclick="advSingle(this,'adv-time');a5Prog()">🔬 Deep dive — maximum learning</div>
        </div>
      </div>

      <!-- Step 7: Target Sector -->
      <div class="adv-card" id="adv-card-7">
        <div class="adv-card-num" style="animation-delay:-3.5s">07</div>
        <div class="adv-card-title">Target Industry Sector</div>
        <div class="adv-card-hint">Optional — select all that apply for employer-specific advice</div>
        <div class="adv-chips" id="adv-sector">
          <div class="a5-chip" data-val="fintech" onclick="advToggle2(this,'adv-sector');a5Prog()">💳 FinTech / Banking</div>
          <div class="a5-chip" data-val="health" onclick="advToggle2(this,'adv-sector');a5Prog()">🏥 Healthcare / MedTech</div>
          <div class="a5-chip" data-val="gov" onclick="advToggle2(this,'adv-sector');a5Prog()">🏛 Government / Public Sector</div>
          <div class="a5-chip" data-val="tech" onclick="advToggle2(this,'adv-sector');a5Prog()">💻 Big Tech / FAANG</div>
          <div class="a5-chip" data-val="telco" onclick="advToggle2(this,'adv-sector');a5Prog()">📡 Telecoms / ISP</div>
          <div class="a5-chip" data-val="academia" onclick="advToggle2(this,'adv-sector');a5Prog()">🎓 Academia / Research Institute</div>
          <div class="a5-chip" data-val="defence" onclick="advToggle2(this,'adv-sector');a5Prog()">🛡 Defence / Intelligence</div>
          <div class="a5-chip" data-val="energy" onclick="advToggle2(this,'adv-sector');a5Prog()">⚡ Energy / Climate Tech</div>
        </div>
      </div>

      <!-- Step 8: Preferred Language -->
      <div class="adv-card" id="adv-card-8">
        <div class="adv-card-num" style="animation-delay:-5.0s">08</div>
        <div class="adv-card-title">Programming Language Ecosystem</div>
        <div class="adv-card-hint">Optional — shapes tooling and ecosystem advice in your plan</div>
        <div class="adv-chips" id="adv-lang">
          <div class="a5-chip" data-val="python" onclick="advToggle2(this,'adv-lang')">🐍 Python</div>
          <div class="a5-chip" data-val="cpp" onclick="advToggle2(this,'adv-lang')">⚙ C / C++</div>
          <div class="a5-chip" data-val="java" onclick="advToggle2(this,'adv-lang')">☕ Java / Kotlin</div>
          <div class="a5-chip" data-val="rust" onclick="advToggle2(this,'adv-lang')">🦀 Rust</div>
          <div class="a5-chip" data-val="js" onclick="advToggle2(this,'adv-lang')">🌐 JavaScript / TypeScript</div>
          <div class="a5-chip" data-val="r" onclick="advToggle2(this,'adv-lang')">📊 R / Julia / MATLAB</div>
          <div class="a5-chip" data-val="haskell" onclick="advToggle2(this,'adv-lang')">λ Haskell / OCaml / Prolog</div>
          <div class="a5-chip" data-val="go" onclick="advToggle2(this,'adv-lang')">🐹 Go / Elixir</div>
        </div>
      </div>

      <!-- Step 9: Geographic Horizon -->
      <div class="adv-card" id="adv-card-9">
        <div class="adv-card-num" style="animation-delay:-0.4s">09</div>
        <div class="adv-card-title">Geographic Career Horizon</div>
        <div class="adv-card-hint">Optional — tailors employer names, visa info, and salary benchmarks</div>
        <div class="adv-chips" id="adv-horizon">
          <div class="a5-chip" data-val="local" onclick="advSingle(this,'adv-horizon');a5Prog()">🇿🇦 South Africa</div>
          <div class="a5-chip" data-val="africa" onclick="advSingle(this,'adv-horizon');a5Prog()">🌍 Pan-African</div>
          <div class="a5-chip" data-val="eu" onclick="advSingle(this,'adv-horizon');a5Prog()">🇪🇺 Europe (UK/EU)</div>
          <div class="a5-chip" data-val="us" onclick="advSingle(this,'adv-horizon');a5Prog()">🇺🇸 North America</div>
          <div class="a5-chip" data-val="global" onclick="advSingle(this,'adv-horizon');a5Prog()">🌐 Fully Remote / Global</div>
        </div>
      </div>

      <!-- Step 10: Postgrad Intent -->
      <div class="adv-card" id="adv-card-10">
        <div class="adv-card-num" style="animation-delay:-8.1s">10</div>
        <div class="adv-card-title">Postgraduate Intent</div>
        <div class="adv-card-hint">Optional — adds postgrad funding info and MSc/PhD module recommendations</div>
        <div class="adv-chips" id="adv-postgrad-intent">
          <div class="a5-chip" data-val="industry-d" onclick="advSingle(this,'adv-postgrad-intent');a5Prog()">💼 Industry after Honours</div>
          <div class="a5-chip" data-val="msc" onclick="advSingle(this,'adv-postgrad-intent');a5Prog()">📘 MSc Coursework</div>
          <div class="a5-chip" data-val="msc-r" onclick="advSingle(this,'adv-postgrad-intent');a5Prog()">📗 MSc Research</div>
          <div class="a5-chip" data-val="phd-d" onclick="advSingle(this,'adv-postgrad-intent');a5Prog()">📕 PhD (Direct)</div>
          <div class="a5-chip" data-val="undecided" onclick="advSingle(this,'adv-postgrad-intent');a5Prog()">🤷 Undecided</div>
        </div>
      </div>

      <!-- Step 11: Project Type Preference -->
      <div class="adv-card" id="adv-card-11">
        <div class="adv-card-num" style="animation-delay:-1.2s">11</div>
        <div class="adv-card-title">Project Type Preference</div>
        <div class="adv-card-hint">Optional — shapes Honours project framing and supervisor matching</div>
        <div class="adv-chips" id="adv-project">
          <div class="a5-chip" data-val="build" onclick="advSingle(this,'adv-project');a5Prog()">🔨 Build things (engineering)</div>
          <div class="a5-chip" data-val="research" onclick="advSingle(this,'adv-project');a5Prog()">🔬 Discover things (research)</div>
          <div class="a5-chip" data-val="analyse" onclick="advSingle(this,'adv-project');a5Prog()">📊 Analyse data / systems</div>
          <div class="a5-chip" data-val="design" onclick="advSingle(this,'adv-project');a5Prog()">🎨 Design / UX / HCI</div>
          <div class="a5-chip" data-val="prove" onclick="advSingle(this,'adv-project');a5Prog()">📐 Prove / verify formally</div>
        </div>
      </div>

      <!-- Step 12: School Background -->
      <div class="adv-card" id="adv-card-12">
        <div class="adv-card-num" style="animation-delay:-6.7s">12</div>
        <div class="adv-card-title">NSC / School Background</div>
        <div class="adv-card-hint">Optional — helps calibrate Year 1 difficulty warnings and support resources</div>
        <div class="adv-chips" id="adv-school">
          <div class="a5-chip" data-val="maths" onclick="advSingle(this,'adv-school');a5Prog()">✓ Maths (70%+) & Physics</div>
          <div class="a5-chip" data-val="maths-only" onclick="advSingle(this,'adv-school');a5Prog()">✓ Maths (60–69%), no Physics</div>
          <div class="a5-chip" data-val="maths-low" onclick="advSingle(this,'adv-school');a5Prog()">⚠ Maths below 60%</div>
          <div class="a5-chip" data-val="matlit" onclick="advSingle(this,'adv-school');a5Prog()">📝 Mathematical Literacy</div>
          <div class="a5-chip" data-val="ib" onclick="advSingle(this,'adv-school');a5Prog()">🌐 IB / A-Levels / International</div>
        </div>
      </div>

      <!-- Step 13: Funding Situation -->
      <div class="adv-card" id="adv-card-13">
        <div class="adv-card-num" style="animation-delay:-3.9s">13</div>
        <div class="adv-card-title">Funding & Financial Situation</div>
        <div class="adv-card-hint">Optional — surfaces relevant bursaries, NSFAS info, and part-time strategies</div>
        <div class="adv-chips" id="adv-funding">
          <div class="a5-chip" data-val="self" onclick="advSingle(this,'adv-funding');a5Prog()">💰 Self-funded / family</div>
          <div class="a5-chip" data-val="nsfas" onclick="advSingle(this,'adv-funding');a5Prog()">📋 NSFAS recipient</div>
          <div class="a5-chip" data-val="bursary" onclick="advSingle(this,'adv-funding');a5Prog()">🏆 Corporate / external bursary</div>
          <div class="a5-chip" data-val="nrf" onclick="advSingle(this,'adv-funding');a5Prog()">🔬 NRF / postgrad bursary</div>
          <div class="a5-chip" data-val="part-time" onclick="advSingle(this,'adv-funding');a5Prog()">⚡ Need part-time income</div>
          <div class="a5-chip" data-val="seeking" onclick="advSingle(this,'adv-funding');a5Prog()">🔍 Actively seeking funding</div>
        </div>
      </div>

      <!-- Step 14: Special Interests / Electives -->
      <div class="adv-card adv-card-wide" id="adv-card-14">
        <div class="adv-card-num" style="animation-delay:-5.5s">14</div>
        <div class="adv-card-title">Special Elective Interests</div>
        <div class="adv-card-hint">Optional — flags modules outside your main track worth considering</div>
        <div class="adv-chips" id="adv-elective">
          <div class="a5-chip" data-val="hci" onclick="advToggle2(this,'adv-elective')">🖱 HCI & UX Design</div>
          <div class="a5-chip" data-val="embedded" onclick="advToggle2(this,'adv-elective')">🔧 Embedded / IoT Systems</div>
          <div class="a5-chip" data-val="blockchain" onclick="advToggle2(this,'adv-elective')">🔗 Blockchain & Web3</div>
          <div class="a5-chip" data-val="nlp" onclick="advToggle2(this,'adv-elective')">💬 NLP & Language AI</div>
          <div class="a5-chip" data-val="quantum" onclick="advToggle2(this,'adv-elective')">⚛ Quantum Computing</div>
          <div class="a5-chip" data-val="ethics" onclick="advToggle2(this,'adv-elective')">⚖ AI Ethics & Law</div>
          <div class="a5-chip" data-val="robotics" onclick="advToggle2(this,'adv-elective')">🤖 Robotics & Control</div>
          <div class="a5-chip" data-val="open-source" onclick="advToggle2(this,'adv-elective')">🌐 Open-Source Contribution</div>
        </div>
      </div>

    </div><!-- /adv-card-grid -->

    <div class="adv-cta-row-v5">
      <div id="a5-prog-label" class="adv-status-msg">Select your interests, career goal, and year level to begin</div>
      <div style="display:flex;gap:12px;align-items:center;">
        <button class="a5-gen-btn" onclick="generateAdvice()"><span>Generate My Pathway →</span></button>
        <button onclick="a5Reset()" class="adv-reset-btn">↺ Reset</button>
      </div>
    </div>

    <div id="advisor-result" style="padding: 0 24px 80px;"></div>

  </div>
`,onMount:()=>{
  window.a5Reset = function() {
    document.querySelectorAll('.a5-chip.on,.adv-chip.selected,.a5-chip.selected').forEach(c => c.classList.remove('on','selected'));
    document.getElementById('advisor-result').innerHTML = '';
    document.querySelectorAll('.adv-card').forEach(c => c.classList.remove('adv-card-done'));
    a5Prog();
  };
  window.advReset = window.a5Reset;
  window.a5Prog = function() {
    const has = sel => document.querySelector(sel) !== null;
    const hasMulti = sel => document.querySelectorAll(sel).length > 0;
    const req = [
      hasMulti('#adv-interests .a5-chip.on, #adv-interests .a5-chip.selected'),
      has('#adv-goal .a5-chip.on, #adv-goal .a5-chip.selected'),
      has('#adv-skill .a5-chip.on, #adv-skill .a5-chip.selected'),
    ];
    const opt = [
      has('#adv-math .a5-chip.on, #adv-math .a5-chip.selected'),
      has('#adv-teamwork .a5-chip.on, #adv-teamwork .a5-chip.selected'),
      has('#adv-time .a5-chip.on, #adv-time .a5-chip.selected'),
      hasMulti('#adv-sector .a5-chip.on, #adv-sector .a5-chip.selected'),
      hasMulti('#adv-lang .a5-chip.on, #adv-lang .a5-chip.selected'),
      has('#adv-horizon .a5-chip.on, #adv-horizon .a5-chip.selected'),
      has('#adv-postgrad-intent .a5-chip.on, #adv-postgrad-intent .a5-chip.selected'),
      has('#adv-project .a5-chip.on, #adv-project .a5-chip.selected'),
      has('#adv-school .a5-chip.on, #adv-school .a5-chip.selected'),
      has('#adv-funding .a5-chip.on, #adv-funding .a5-chip.selected'),
      hasMulti('#adv-elective .a5-chip.on, #adv-elective .a5-chip.selected'),
    ];
    const done = req.filter(Boolean).length + opt.filter(Boolean).length;
    const total = req.length + opt.length;
    const pct = Math.round(done / total * 100);
    const fill = document.getElementById('a5-prog-fill');
    const lbl = document.getElementById('a5-prog-label');
    const badge = document.getElementById('a5-badge-pct');
    if (fill) fill.style.width = pct + '%';
    if (badge) badge.textContent = pct + '% complete';
    const cardDoneMap = [req[0],req[1],req[2],opt[0],opt[1],opt[2],opt[3],opt[4],opt[5],opt[6],opt[7],opt[8],opt[9],opt[10]];
    cardDoneMap.forEach((done,i) => {
      const card = document.getElementById('adv-card-'+(i+1));
      if(card) card.classList.toggle('adv-card-done', !!done);
    });
    if (lbl) {
      if (!req[0]) lbl.textContent = 'Select at least one interest area to proceed';
      else if (!req[1]) lbl.textContent = 'Now select a career goal';
      else if (!req[2]) lbl.textContent = 'Select your current year level';
      else if (pct === 100) lbl.textContent = '✓ All 14 dimensions complete — ready to generate!';
      else lbl.textContent = `${req.filter(Boolean).length}/3 required · ${opt.filter(Boolean).length}/${opt.length} optional filled · ${pct}% complete`;
    }
  };
  window.advToggle = function(el) { el.classList.toggle('on'); el.classList.toggle('selected'); };
  window.advSingle = function(el, groupId) {
    document.querySelectorAll('#'+groupId+' .a5-chip').forEach(c => c.classList.remove('on', 'selected'));
    el.classList.add('on', 'selected');
  };
  window.advToggle2 = function(el) { el.classList.toggle('on'); el.classList.toggle('selected'); };
  window.advProgress = window.a5Prog;
  window.a5Prog();
}},
12:{label:'Graph',fullLabel:'Curriculum Prerequisite Graph',render:()=>`
  <div class="pg-inner-wide">

    <div class="pg-hero">
      <div class="pg-hero-rule"></div>
      <div class="pg-hero-eyebrow">Curriculum Map</div>
      <h1>Prerequisite<br>Graph</h1>
      <p class="pg-hero-sub">An interactive map of all CS modules and their dependencies. Every arrow is a prerequisite — follow them to understand the critical path through your degree. Search, filter by track, click nodes for detail, drag to rearrange.</p>
      <div class="pg-hero-badges">
        <span class="pg-hero-badge" id="gstat-nodes">– Modules</span>
        <span class="pg-hero-badge" id="gstat-links">– Links</span>
        <span class="pg-hero-badge">7 Year Levels</span>
        <span class="pg-hero-badge">9 Tracks</span>
      </div>
    </div>

    <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:32px;">
      <span class="gci-badge green">✓ BEng-equivalent credit load</span>
      <span class="gci-badge gold">⚡ ~120 credits/year</span>
      <span class="gci-badge blue">🔗 Deep prerequisite chains</span>
      <span class="gci-badge red">⚠ CS 214 is critical bottleneck</span>
    </div>

    <div class="graph-layout">
      <div class="graph-main">
        <div class="graph-toolbar" id="graph-toolbar">
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.88rem;color:var(--su-gold-d);letter-spacing:1px;margin-right:2px;white-space:nowrap;">TRACK PATH:</span>
          <button class="graph-filter-btn active" onclick="graphHighlight('all',this)">All</button>
          <button class="graph-filter-btn" onclick="graphHighlight('ai',this)">🤖 AI</button>
          <button class="graph-filter-btn" onclick="graphHighlight('security',this)">🔐 Security</button>
          <button class="graph-filter-btn" onclick="graphHighlight('systems',this)">⚡ Systems</button>
          <button class="graph-filter-btn" onclick="graphHighlight('data',this)">📊 Data</button>
          <button class="graph-filter-btn" onclick="graphHighlight('bio',this)">🧬 Bio</button>
          <button class="graph-filter-btn" onclick="graphHighlight('theory',this)">📐 Theory</button>
          <button class="graph-filter-btn" onclick="graphHighlight('graphics',this)">🎮 Graphics</button>
          <button class="graph-filter-btn" onclick="graphHighlight('honours',this)">🎓 Honours</button>
          <button class="graph-filter-btn" onclick="graphHighlight('masters',this)">📘 Masters</button>
          <button class="graph-filter-btn" onclick="graphHighlight('phd',this)">🔬 PhD</button>
        </div>
        <div class="graph-toolbar" id="graph-toolbar-year" style="margin-top:4px;padding-top:4px;border-top:1px solid var(--page-border);">
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.88rem;color:var(--su-gold-d);letter-spacing:1px;margin-right:2px;white-space:nowrap;">YEAR LEVEL:</span>
          <button class="graph-filter-btn graph-year-btn active" onclick="graphHighlightYear(0,this)">All</button>
          <button class="graph-filter-btn graph-year-btn" onclick="graphHighlightYear(1,this)">Y1 Foundations</button>
          <button class="graph-filter-btn graph-year-btn" onclick="graphHighlightYear(2,this)">Y2 Core</button>
          <button class="graph-filter-btn graph-year-btn" onclick="graphHighlightYear(3,this)">Y3 Specialisation</button>
          <button class="graph-filter-btn graph-year-btn" onclick="graphHighlightYear(4,this)">Y4 Honours</button>
          <button class="graph-filter-btn graph-year-btn" onclick="graphHighlightYear(5,this)">Y5 Postgrad</button>
          <button class="graph-filter-btn graph-year-btn" onclick="graphHighlightYear(6,this)">Y6 MSc</button>
          <button class="graph-filter-btn graph-year-btn" onclick="graphHighlightYear(7,this)">Y7 PhD</button>
        </div>
        <div class="graph-search-wrap" style="margin-top:12px;" id="graph-search-wrap">
          <span class="graph-search-icon">🔍</span>
          <input class="graph-search-input" type="text" placeholder="🔍  Search by module code or name…" id="graph-search-input" oninput="graphSearch(this.value);this.style.textAlign=this.value?'center':'center';" onblur="setTimeout(()=>document.getElementById('graph-search-results').style.display='none',200);this.style.textAlign='center';" onfocus="this.style.textAlign='center';if(this.value)graphSearch(this.value);" >
          <div class="graph-search-results" id="graph-search-results"></div>
        </div>
        <div class="graph-legend" style="margin-top:12px;">
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#61223b;"></div><span>Y1 Foundation</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#a07a30;"></div><span>Y2 Core</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#1a6040;"></div><span>Y3 Specialisation</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#1a3a70;"></div><span>Y4 Honours</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#420f27;"></div><span>Postgrad</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#6b2fa0;"></div><span>MSc</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#1a0a2e;border:1px solid #6b2fa0;"></div><span>PhD</span></div>
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.88rem;color:var(--su-gold-d);margin:0 4px;">│</span>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#82CCAE;border:2px solid #82CCAE;"></div><span>AI Track</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#dc4405;border:2px solid #dc4405;"></div><span>Security</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#64c8d4;border:2px solid #64c8d4;"></div><span>Systems</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#b48ae0;border:2px solid #b48ae0;"></div><span>Data</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#f5a623;border:2px solid #f5a623;"></div><span>Theory</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#6b2fa0;border:2px solid #6b2fa0;"></div><span>Masters</span></div>
          <div class="graph-legend-item"><div class="graph-legend-dot" style="background:#c0392b;border:2px solid #c0392b;"></div><span>PhD</span></div>
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.88rem;color:var(--su-gold-d);margin:0 4px;">│</span>
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.88rem;color:var(--su-gold-d);">Node size = prerequisite depth</span>
        </div>
        <div id="curr-graph-container" style="height:clamp(480px,65vh,800px);">
          <svg id="curr-graph-svg" width="100%" height="100%"></svg>
          <div id="graph-node-tooltip" class="graph-node-tooltip"></div>
          <div class="graph-controls">
            <button class="graph-ctrl-btn" onclick="graphZoomIn()" title="Zoom in">+</button>
            <button class="graph-ctrl-btn" onclick="graphZoomOut()" title="Zoom out">−</button>
            <button class="graph-ctrl-btn" onclick="graphZoomReset()" title="Reset view" style="font-size:0.65rem;letter-spacing:0;">FIT</button>
          </div>
        </div>
        <p style="font-family:'Share Tech Mono',monospace;font-size:0.63rem;color:var(--su-gold-d);margin-top:10px;opacity:0.7;line-height:1.7;">
          🖱 <strong>Drag</strong> nodes to rearrange · <strong>Scroll</strong> to zoom · <strong>Click</strong> node for sidebar detail · <strong>Double-click</strong> node for full details · <strong>Double-click</strong> background to reset view
        </p>
      </div>

      <div class="graph-sidebar">
        <div class="graph-sidebar-scroll">
        <div class="graph-module-detail" id="graph-module-detail" style="display:block;">
          <div style="font-family:'Share Tech Mono',monospace;font-size:0.6rem;color:var(--su-gold-d);letter-spacing:2px;text-transform:uppercase;margin-bottom:8px;">— SELECTED MODULE —</div>
          <div class="gmd-code" id="gmd-code" style="opacity:0.4;">CS 000</div>
          <div class="gmd-name" id="gmd-name" style="opacity:0.5;font-size:0.9rem;">Click any node to inspect</div>
          <div class="gmd-meta">
            <div class="gmd-meta-box"><div class="gmd-meta-val" id="gmd-cr" style="opacity:0.4;">—</div><div class="gmd-meta-lbl">Credits</div></div>
            <div class="gmd-meta-box"><div class="gmd-meta-val" id="gmd-yr" style="opacity:0.4;">—</div><div class="gmd-meta-lbl">Year</div></div>
          </div>
          <div class="gmd-section-lbl">⬆ Prerequisites</div>
          <div class="gmd-chips" id="gmd-prereqs"><span style="font-family:'Share Tech Mono',monospace;font-size:0.78rem;color:var(--su-gold-d);opacity:0.6;">None</span></div>
          <div class="gmd-section-lbl">⬇ Unlocks</div>
          <div class="gmd-chips" id="gmd-unlocks"><span style="font-family:'Share Tech Mono',monospace;font-size:0.78rem;color:var(--su-gold-d);opacity:0.6;">None</span></div>
          <div class="gmd-section-lbl">🏷 Tracks</div>
          <div class="gmd-chips" id="gmd-tracks"><span style="font-family:'Share Tech Mono',monospace;font-size:0.78rem;color:var(--su-gold-d);opacity:0.6;">General</span></div>
          <button class="adv-cta-btn" style="width:100%;margin-top:12px;font-size:0.7rem;padding:9px;opacity:0.4;pointer-events:none;" id="gmd-detail-btn" onclick="document.getElementById('m-modal').classList.add('open')">📋 Full Details →</button>
        </div>
        <div class="graph-panel" id="graph-advisor-panel" style="display:none;border:1px solid rgba(202,162,88,0.35);">
          <div class="graph-panel-header" style="background:linear-gradient(90deg,#420f27,#61223b);">🎯 Your Career Path</div>
          <div class="graph-panel-body" id="graph-advisor-body">
          </div>
        </div>
        <div class="graph-panel">
          <div class="graph-panel-header" id="graph-track-counts-header">📊 Track Module Counts</div>
          <div class="graph-panel-body" id="graph-track-counts">
            <div class="track-bar-row"><div class="track-bar-label"><span>🤖 AI / ML</span><span id="tc-ai">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#82CCAE;" id="tcb-ai"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>🔐 Security</span><span id="tc-sec">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#dc4405;" id="tcb-sec"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>⚡ Systems</span><span id="tc-sys">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#64c8d4;" id="tcb-sys"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>📊 Data</span><span id="tc-dat">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#b48ae0;" id="tcb-dat"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>🧬 Bioinformatics</span><span id="tc-bio">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#5ecfaa;" id="tcb-bio"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>📐 Theory</span><span id="tc-thy">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#f5a623;" id="tcb-thy"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>🎮 Graphics</span><span id="tc-grx">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#e879a0;" id="tcb-grx"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>📘 Masters</span><span id="tc-msc">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#6b2fa0;" id="tcb-msc"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>🔬 PhD</span><span id="tc-phd">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#c0392b;" id="tcb-phd"></div></div></div>
          </div>
        </div>
        <div class="graph-panel">
          <div class="graph-panel-header" id="graph-year-breakdown-header">📅 Modules Per Year</div>
          <div class="graph-panel-body" id="graph-year-breakdown">
            <div class="track-bar-row"><div class="track-bar-label"><span>Y1 Foundation</span><span id="yc-1">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#61223b;" id="ycb-1"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>Y2 Core</span><span id="yc-2">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#a07a30;" id="ycb-2"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>Y3 Specialisation</span><span id="yc-3">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#1a6040;" id="ycb-3"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>Y4 Honours</span><span id="yc-4">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#1a3a70;" id="ycb-4"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>Y5 Postgrad</span><span id="yc-5">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#420f27;" id="ycb-5"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>Y6 MSc</span><span id="yc-6">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#6b2fa0;" id="ycb-6"></div></div></div>
            <div class="track-bar-row"><div class="track-bar-label"><span>Y7 PhD</span><span id="yc-7">–</span></div><div class="track-bar-bg"><div class="track-bar-fill" style="background:#1a0a2e;" id="ycb-7"></div></div></div>
          </div>
        </div>
        <div class="graph-panel">
          <div class="graph-panel-header" data-panel="critical">⚠ Critical Modules</div>
          <div class="graph-panel-body">
            <p style="font-family:'Raleway',sans-serif;font-size:0.95rem;line-height:1.65;color:var(--page-text2);margin:0 0 14px;">Modules that unlock the most downstream paths — failing these has the largest impact on your degree timeline.</p>
            <div style="display:flex;flex-direction:column;gap:8px;" id="critical-modules-list">
              <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:rgba(220,68,5,0.08);border-left:3px solid #dc4405;border-radius:0 3px 3px 0;">
                <span style="font-family:'Share Tech Mono',monospace;font-size:0.95rem;color:#f07040;cursor:pointer;" onclick="graphFocusModule('CS214')">CS214</span>
                <span style="font-family:'Raleway',sans-serif;font-size:0.95rem;color:var(--page-text2);">Data Structures</span>
                <span style="font-family:'Share Tech Mono',monospace;font-size:0.82rem;color:var(--su-orange);">🔗 most unlocks</span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:rgba(202,162,88,0.06);border-left:3px solid var(--su-gold-d);border-radius:0 3px 3px 0;">
                <span style="font-family:'Share Tech Mono',monospace;font-size:0.95rem;color:var(--su-gold);cursor:pointer;" onclick="graphFocusModule('CS114')">CS114</span>
                <span style="font-family:'Raleway',sans-serif;font-size:0.95rem;color:var(--page-text2);">Intro to CS</span>
                <span style="font-family:'Share Tech Mono',monospace;font-size:0.82rem;color:var(--su-gold-d);">🔑 gateway</span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:rgba(202,162,88,0.06);border-left:3px solid var(--su-gold-d);border-radius:0 3px 3px 0;">
                <span style="font-family:'Share Tech Mono',monospace;font-size:0.95rem;color:var(--su-gold);cursor:pointer;" onclick="graphFocusModule('CS315')">CS315</span>
                <span style="font-family:'Raleway',sans-serif;font-size:0.95rem;color:var(--page-text2);">Machine Learning</span>
                <span style="font-family:'Share Tech Mono',monospace;font-size:0.82rem;color:var(--su-gold-d);">🏆 honours path</span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:rgba(26,96,64,0.08);border-left:3px solid #1a6040;border-radius:0 3px 3px 0;">
                <span style="font-family:'Share Tech Mono',monospace;font-size:0.95rem;color:var(--su-green);cursor:pointer;" onclick="graphFocusModule('CS244')">CS244</span>
                <span style="font-family:'Raleway',sans-serif;font-size:0.95rem;color:var(--page-text2);">Architecture & OS</span>
                <span style="font-family:'Share Tech Mono',monospace;font-size:0.82rem;color:var(--su-green);">🏗 Y3 branch</span>
              </div>
            </div>
          </div>
        </div>
        <div class="graph-panel">
          <div class="graph-panel-header">💡 How to Read This Graph</div>
          <div class="graph-panel-body">
            <div style="font-family:'Raleway',sans-serif;font-size:1rem;line-height:1.75;color:var(--page-text2);">
              <p style="margin:0 0 10px;"><strong style="color:var(--page-maroon);">Arrows</strong> point from prerequisite → module. Follow arrows forward to see what each module unlocks.</p>
              <p style="margin:0 0 10px;"><strong style="color:var(--page-maroon);">Node size</strong> indicates how many downstream modules it enables — larger = more critical.</p>
              <p style="margin:0 0 10px;"><strong style="color:var(--page-maroon);">Vertical position</strong> reflects year level — Year 1 at top, Postgrad at bottom.</p>
              <p style="margin:0;"><strong style="color:var(--page-maroon);">Glowing nodes</strong> are active in the current highlighted track.</p>
              <p style="margin:10px 0 0;"><strong style="color:var(--page-maroon);">Career Path panel</strong> appears at the top of this sidebar after you generate a plan in the Career Advisor page.</p>
            </div>
          </div>
        </div>
        </div><!-- /.graph-sidebar-scroll -->
      </div>
    </div>
  </div>
`,onMount:()=>setTimeout(()=>{
    initCurrGraph();

    // Populate advisor career path panel if a plan exists
    function updateAdvisorPanel(){
      const panel=document.getElementById('graph-advisor-panel');
      const body=document.getElementById('graph-advisor-body');
      if(!panel||!body) return;
      const p=window._advisorPlan;
      if(!p){panel.style.display='none';return;}
      panel.style.display='block';

      const TRACK_COLORS_MAP={ai:'#82CCAE',security:'#dc4405',systems:'#64c8d4',data:'#b48ae0',bio:'#5ecfaa',theory:'#f5a623',graphics:'#e879a0',honours:'#caa258'};
      const trackColor=TRACK_COLORS_MAP[p.primary]||'#caa258';

      // Per-year module chips
      const yearKeys=['y1','y2','y3','y4','y5'];
      const yearLabels={y1:'Y1 Foundation',y2:'Y2 Core',y3:'Y3 Specialisation',y4:'Y4 Honours',y5:'Y5 Postgrad'};
      const yearColors={y1:'#61223b',y2:'#a07a30',y3:'#1a6040',y4:'#1a3a70',y5:'#420f27'};
      const yearRows=yearKeys.filter(k=>p.plans[k]&&p.plans[k].length).map(k=>`
        <div style="margin-bottom:10px;">
          <div style="font-family:'Share Tech Mono',monospace;font-size:0.72rem;color:${yearColors[k]};letter-spacing:1px;text-transform:uppercase;margin-bottom:5px;display:flex;align-items:center;gap:6px;">
            <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${yearColors[k]};flex-shrink:0;"></span>${yearLabels[k]}
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:4px;">
            ${p.plans[k].map(m=>`<span onclick="graphFocusModule('${m.code}')" style="font-family:'Share Tech Mono',monospace;font-size:0.78rem;padding:3px 8px;border-radius:2px;cursor:pointer;background:rgba(202,162,88,0.08);border:1px solid rgba(202,162,88,0.2);color:var(--su-gold);transition:background 0.15s;" onmouseover="this.style.background='var(--su-maroon)'" onmouseout="this.style.background='rgba(202,162,88,0.08)'">${m.code}</span>`).join('')}
          </div>
        </div>`).join('');

      body.innerHTML=`
        <div style="margin-bottom:14px;padding:10px 12px;background:rgba(202,162,88,0.06);border-radius:4px;border-left:3px solid ${trackColor};">
          <div style="font-family:'Share Tech Mono',monospace;font-size:0.7rem;color:var(--su-gold-d);letter-spacing:1px;text-transform:uppercase;margin-bottom:4px;">Primary Track</div>
          <div style="font-family:'Raleway',sans-serif;font-weight:800;font-size:1.1rem;color:${trackColor};">${p.trackLabel}</div>
          <div style="font-family:'Share Tech Mono',monospace;font-size:0.75rem;color:var(--su-gold-d);margin-top:4px;">Goal: ${p.goalLabel} &nbsp;·&nbsp; ${p.totalModules} modules &nbsp;·&nbsp; ~${p.totalCredits}cr</div>
          ${p.interests.length>1?`<div style="margin-top:6px;display:flex;flex-wrap:wrap;gap:4px;">${p.interests.slice(1).map(i=>`<span style="font-family:'Share Tech Mono',monospace;font-size:0.7rem;padding:2px 8px;border-radius:10px;background:rgba(202,162,88,0.08);border:1px solid rgba(202,162,88,0.15);color:rgba(202,162,88,0.7);">+${i}</span>`).join('')}</div>`:''}
        </div>
        <div style="margin-bottom:12px;">
          <button onclick="graphHighlight('${p.primary}',null);document.getElementById('graph-advisor-panel').scrollIntoView({behavior:'smooth',block:'nearest'});" style="width:100%;background:var(--su-maroon);color:var(--su-gold);font-family:'Raleway',sans-serif;font-weight:800;font-size:0.82rem;padding:9px;border:1px solid rgba(202,162,88,0.3);border-radius:3px;cursor:pointer;letter-spacing:0.5px;transition:all 0.18s;" onmouseover="this.style.background='#420f27'" onmouseout="this.style.background='var(--su-maroon)'">
            ✦ Highlight My Track on Graph
          </button>
        </div>
        <div style="font-family:'Share Tech Mono',monospace;font-size:0.72rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">Recommended Modules</div>
        ${yearRows}
        <div style="margin-top:10px;font-family:'Share Tech Mono',monospace;font-size:0.68rem;color:rgba(202,162,88,0.4);line-height:1.6;">Click any module code above to inspect it on the graph. Generated from Career Advisor — go back to update your path.</div>
      `;
    }
    updateAdvisorPanel();
    // Re-run if advisor plan updates while on this page
    window._updateAdvisorGraphPanel=updateAdvisorPanel;

    // ── Dynamic sidebar update: reacts to track/year filter changes ──
    window._updateGraphSidebar=function(activeTrack, activeYear){
      if(typeof GRAPH_NODES==='undefined') return;

      // Determine which nodes are "visible" under the current filter
      let visibleNodes;
      if(activeTrack && activeTrack!=='all'){
        // Track filter: include track nodes + their prerequisites
        const trackIds=GRAPH_NODES.filter(n=>n.track&&n.track.includes(activeTrack)).map(n=>n.id);
        const withPrereqs=new Set(trackIds);
        let changed=true;
        while(changed){changed=false;GRAPH_LINKS.forEach(l=>{const t=l.target?.id||l.target,s=l.source?.id||l.source;if(withPrereqs.has(t)&&!withPrereqs.has(s)){withPrereqs.add(s);changed=true;}});}
        visibleNodes=GRAPH_NODES.filter(n=>withPrereqs.has(n.id));
      } else if(activeYear && activeYear!==0){
        visibleNodes=GRAPH_NODES.filter(n=>n.year===activeYear);
      } else {
        visibleNodes=GRAPH_NODES;
      }

      const visibleIds=new Set(visibleNodes.map(n=>n.id));

      // ── Track Module Counts ──
      const trackDef={ai:{id:'tc-ai',bar:'tcb-ai',color:'#82CCAE'},security:{id:'tc-sec',bar:'tcb-sec',color:'#dc4405'},systems:{id:'tc-sys',bar:'tcb-sys',color:'#64c8d4'},data:{id:'tc-dat',bar:'tcb-dat',color:'#b48ae0'},bio:{id:'tc-bio',bar:'tcb-bio',color:'#5ecfaa'},theory:{id:'tc-thy',bar:'tcb-thy',color:'#f5a623'},graphics:{id:'tc-grx',bar:'tcb-grx',color:'#e879a0'},masters:{id:'tc-msc',bar:'tcb-msc',color:'#6b2fa0'},phd:{id:'tc-phd',bar:'tcb-phd',color:'#c0392b'}};
      // When a single module is selected, override counts to 1 (match) or 0 (no match)
      const selectedNode=activeTrack==='_module_'?window._selectedGraphModule:null;
      const selectedTracks=new Set(selectedNode&&selectedNode.track?selectedNode.track:[]);
      const trackCounts={};
      Object.keys(trackDef).forEach(t=>{
        trackCounts[t]=selectedNode
          ? (selectedTracks.has(t)?1:0)
          : visibleNodes.filter(n=>n.track&&n.track.includes(t)).length;
      });
      const maxTc=Math.max(1,...Object.values(trackCounts));
      Object.keys(trackDef).forEach(t=>{
        const el=document.getElementById(trackDef[t].id);
        const bar=document.getElementById(trackDef[t].bar);
        if(el) el.textContent=trackCounts[t]===0&&selectedNode?'0':trackCounts[t];
        if(bar){
          bar.style.width=selectedNode?(trackCounts[t]===0?'0%':'10%'):`${Math.round(trackCounts[t]/maxTc*100)}%`;
          if(selectedNode){
            // Single module mode: highlight only its tracks
            bar.style.background=selectedTracks.has(t)?trackDef[t].color:'rgba(202,162,88,0.15)';
            bar.style.boxShadow=selectedTracks.has(t)?`0 0 8px ${trackDef[t].color}88`:'none';
          } else if(activeTrack&&activeTrack!=='all'){
            bar.style.background=t===activeTrack?trackDef[t].color:'rgba(202,162,88,0.25)';
            bar.style.boxShadow='none';
          } else {
            bar.style.background=trackDef[t].color;
            bar.style.boxShadow='none';
          }
        }
        // Update label style to show active track
        if(el){
          const parentRow=el.closest('.track-bar-row');
          if(parentRow){
            if(selectedNode) parentRow.style.opacity=selectedTracks.has(t)?'1':'0.4';
            else parentRow.style.opacity='1';
          }
        }
      });

      // ── Modules Per Year ──
      const yearColors={1:'#61223b',2:'#a07a30',3:'#1a6040',4:'#1a3a70',5:'#420f27',6:'#6b2fa0',7:'#1a0a2e'};
      const getYearCount=(y)=>selectedNode?(y===selectedNode.year?1:0):visibleNodes.filter(n=>n.year===y).length;
      const maxYc=Math.max(1,...[1,2,3,4,5,6,7].map(y=>getYearCount(y)));
      for(let y=1;y<=7;y++){
        const count=getYearCount(y);
        const el=document.getElementById('yc-'+y);
        const bel=document.getElementById('ycb-'+y);
        if(el) el.textContent=count;
        if(bel){
          bel.style.width=selectedNode?(count===0?'0%':'10%'):`${Math.round(count/maxYc*100)}%`;
          if(selectedNode){
            // Single module mode: highlight only its year
            const isModuleYear=y===selectedNode.year;
            bel.style.background=isModuleYear?yearColors[y]:'rgba(202,162,88,0.15)';
            bel.style.boxShadow=isModuleYear?`0 0 8px ${yearColors[y]}88`:'none';
          } else if(activeYear&&activeYear!==0){
            bel.style.background=y===activeYear?yearColors[y]:'rgba(202,162,88,0.25)';
            bel.style.boxShadow='none';
          } else {
            bel.style.background=yearColors[y];
            bel.style.boxShadow='none';
          }
        }
        if(el){
          const parentRow=el.closest('.track-bar-row');
          if(parentRow){
            if(selectedNode) parentRow.style.opacity=y===selectedNode.year?'1':'0.4';
            else parentRow.style.opacity='1';
          }
        }
      }

      // ── Critical Modules (recalculated for visible set) ──
      // Score = number of downstream modules reachable via GRAPH_LINKS within visible set
      function countDownstream(nodeId, vIds){
        const visited=new Set();
        const queue=[nodeId];
        while(queue.length){
          const cur=queue.shift();
          GRAPH_LINKS.forEach(l=>{
            const s=l.source?.id||l.source, t=l.target?.id||l.target;
            if(s===cur&&vIds.has(t)&&!visited.has(t)){visited.add(t);queue.push(t);}
          });
        }
        return visited.size;
      }

      const scoredNodes=visibleNodes
        .filter(n=>n.id.startsWith('CS'))
        .map(n=>({...n, score:countDownstream(n.id,visibleIds)}))
        .sort((a,b)=>b.score-a.score)
        .slice(0,6);

      // Build badge labels based on position + track context
      function critBadge(n, rank, track){
        if(rank===0) return {label:'🔗 most unlocks',color:'#f07040',bg:'rgba(220,68,5,0.08)',border:'#dc4405'};
        if(n.year===1) return {label:'🔑 gateway',color:'var(--su-gold)',bg:'rgba(202,162,88,0.06)',border:'var(--su-gold-d)'};
        if(n.track&&n.track.includes('ai')) return {label:'🤖 AI path',color:'#82CCAE',bg:'rgba(130,204,174,0.06)',border:'#82CCAE'};
        if(n.track&&n.track.includes('security')) return {label:'🔐 security path',color:'#f07040',bg:'rgba(220,68,5,0.06)',border:'#dc4405'};
        if(n.track&&n.track.includes('honours')) return {label:'🏆 honours path',color:'var(--su-gold)',bg:'rgba(202,162,88,0.06)',border:'var(--su-gold-d)'};
        if(n.year===3) return {label:'🏗 Y3 branch',color:'var(--su-green)',bg:'rgba(26,96,64,0.08)',border:'#1a6040'};
        if(n.year===4) return {label:'⭐ Y4 core',color:'#5a8ae0',bg:'rgba(26,58,112,0.06)',border:'#1a3a70'};
        return {label:`▸ ${n.score} unlocks`,color:'rgba(202,162,88,0.7)',bg:'rgba(202,162,88,0.04)',border:'rgba(202,162,88,0.2)'};
      }

      const critHtml=scoredNodes.length?scoredNodes.map((n,i)=>{
        const b=critBadge(n,i,activeTrack);
        return `<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:${b.bg};border-left:3px solid ${b.border};border-radius:0 3px 3px 0;gap:8px;">
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.95rem;color:${b.color};cursor:pointer;flex-shrink:0;" onclick="graphFocusModule('${n.id}')">${n.id}</span>
          <span style="font-family:'Raleway',sans-serif;font-size:0.88rem;color:var(--page-text2);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${n.name.replace(' & ',' &amp; ')}</span>
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.75rem;color:${b.color};flex-shrink:0;">${b.label}</span>
        </div>`;
      }).join(''):`<div style="font-family:'Share Tech Mono',monospace;font-size:0.82rem;color:var(--su-gold-d);padding:8px;">No modules in current filter</div>`;

      const critList=document.getElementById('critical-modules-list');
      if(critList) critList.innerHTML=critHtml;

      // ── Update Track Counts and Year panel headers ──
      const tcHdr=document.getElementById('graph-track-counts-header');
      const yrHdr=document.getElementById('graph-year-breakdown-header');
      if(tcHdr) tcHdr.textContent=window._selectedGraphModule?`📊 Tracks — ${window._selectedGraphModule.id}`:'📊 Track Module Counts';
      if(yrHdr) yrHdr.textContent=window._selectedGraphModule?`📅 Year — ${window._selectedGraphModule.id}`:'📅 Modules Per Year';

      // ── Update panel header label to show context ──
      const selectedNodeForLabel=window._selectedGraphModule;
      const filterLabel=selectedNodeForLabel
        ? `⚠ Critical — ${selectedNodeForLabel.id} Context`
        : activeTrack&&activeTrack!=='all'
        ? `⚠ Critical — ${activeTrack.charAt(0).toUpperCase()+activeTrack.slice(1)} Track`
        : activeYear&&activeYear!==0
        ? `⚠ Critical — Year ${activeYear}`
        : '⚠ Critical Modules';
      const critHeader=document.querySelector('.graph-panel-header[data-panel="critical"]');
      if(critHeader) critHeader.textContent=filterLabel;
    };

    // Populate stats once graph is ready
    setTimeout(()=>{
      if(typeof GRAPH_NODES!=='undefined'){
        document.getElementById('gstat-nodes').textContent=GRAPH_NODES.length+' Modules';
        document.getElementById('gstat-links').textContent=GRAPH_LINKS.length+' Links';
        // Initial full population via sidebar update
        window._updateGraphSidebar('all',0);
      }
    },600);
    // Search function
    window.graphSearch=function(val){
      const res=document.getElementById('graph-search-results');
      if(!val||val.length<2){res.style.display='none';return;}
      const q=val.toLowerCase();
      const matches=GRAPH_NODES.filter(n=>n.id.toLowerCase().includes(q)||n.label.toLowerCase().includes(q)).slice(0,8);
      if(!matches.length){res.style.display='none';return;}
      res.style.display='block';
      res.innerHTML=matches.map(n=>`
        <div class="graph-search-result-item" onclick="graphFocusModule('${n.id}');document.getElementById('graph-search-input').value='${n.id} – ${n.label}';document.getElementById('graph-search-results').style.display='none';">
          <span class="gsri-code" style="font-size:0.9rem;">${n.id} — ${n.name||n.label}</span>
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.68rem;color:var(--su-gold-d);">Y${n.year} · ${n.credits||16}cr</span>
        </div>`).join('');
    };
    window.graphFocusModule=function(id){
      const node=GRAPH_NODES.find(n=>n.id===id);
      if(!node) return;
      // Update sidebar detail panel
      document.getElementById('graph-module-detail').classList.add('visible');
      const codeEl=document.getElementById('gmd-code');
      const nameEl=document.getElementById('gmd-name');
      const detailBtn=document.getElementById('gmd-detail-btn');
      codeEl.textContent=node.id; codeEl.style.opacity='';
      nameEl.textContent=node.name||node.id; nameEl.style.opacity=''; nameEl.style.fontSize='';
      if(detailBtn){
        detailBtn.style.opacity='';detailBtn.style.pointerEvents='';
        detailBtn.onclick=()=>{
          const YEAR_NAMES={1:'Year 1 — Foundation',2:'Year 2 — Core',3:'Year 3 — Specialisation',4:'Year 4 — Honours',5:'Postgraduate (MSc/PhD)',6:'MSc Coursework',7:'PhD Research'};
          const prereqIds=GRAPH_LINKS.filter(l=>(l.target===id||(l.target&&l.target.id===id))).map(l=>l.source?.id||l.source);
          const prereqNodes=GRAPH_NODES.filter(n=>prereqIds.includes(n.id));
          const postreqIds=GRAPH_LINKS.filter(l=>(l.source===id||(l.source&&l.source.id===id))).map(l=>l.target?.id||l.target);
          const postreqNodes=GRAPH_NODES.filter(n=>postreqIds.includes(n.id));
          const prereqHtml=prereqNodes.length
            ? prereqNodes.map(n=>`<span style="display:inline-flex;align-items:center;gap:4px;background:rgba(97,34,59,0.18);border:1px solid rgba(202,162,88,0.25);color:var(--su-gold);font-family:'Share Tech Mono',monospace;font-size:0.72rem;padding:4px 10px;border-radius:3px;margin:2px;">${n.id} — ${n.name}</span>`).join('')
            : `<span style="color:rgba(202,162,88,0.5);font-family:'Share Tech Mono',monospace;font-size:0.78rem;">None — Entry-level module</span>`;
          const postreqHtml=postreqNodes.length
            ? postreqNodes.map(n=>`<span style="display:inline-flex;align-items:center;gap:4px;background:rgba(26,96,64,0.15);border:1px solid rgba(130,204,174,0.25);color:var(--su-green);font-family:'Share Tech Mono',monospace;font-size:0.72rem;padding:4px 10px;border-radius:3px;margin:2px;">${n.id} — ${n.name}</span>`).join('')
            : `<span style="color:rgba(202,162,88,0.4);font-family:'Share Tech Mono',monospace;font-size:0.78rem;">Terminal module</span>`;
          document.getElementById('m-modal-content').innerHTML=`
            <div style="margin-bottom:20px;">
              <div style="font-family:'Share Tech Mono',monospace;font-size:0.7rem;color:var(--su-gold-d);margin-bottom:4px;">${YEAR_NAMES[node.year]||'Module Details'} · ${node.sem==='Ann'?'Full Year':node.sem==='S1'?'Semester 1':'Semester 2'}</div>
              <h2 style="font-family:'Raleway',sans-serif;font-weight:800;color:var(--su-maroon);font-size:1.5rem;margin:0;">${node.id} — ${node.name}</h2>
            </div>
            <p class="m-p" style="margin-bottom:16px;">${node.desc||'No description available.'}</p>
            <div class="m-grid3" style="margin:16px 0;">
              <div class="m-stat" style="padding:14px;"><span class="num" style="font-size:1.6rem;">${node.credits}</span><div class="lbl">Credits</div></div>
              <div class="m-stat" style="padding:14px;"><span class="num" style="font-size:1.4rem;">${YEAR_NAMES[node.year]?.split('—')[0]||'Y'+node.year}</span><div class="lbl">Year Level</div></div>
              <div class="m-stat" style="padding:14px;"><span class="num" style="font-size:1.4rem;">${node.sem==='Ann'?'Full Yr':node.sem}</span><div class="lbl">Semester</div></div>
            </div>
            ${node.track?`<div style="margin-top:8px;">${node.track.map(t=>`<span class="m-tag gold">${t.toUpperCase()} TRACK</span>`).join('')}</div>`:''}
            <div class="m-infobox" style="margin-top:14px;">
              <div style="font-family:'Share Tech Mono',monospace;font-size:0.65rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">⬆ Prerequisites (must pass first)</div>
              <div style="display:flex;flex-wrap:wrap;gap:4px;">${prereqHtml}</div>
            </div>
            <div class="m-infobox" style="margin-top:10px;border-left-color:var(--su-green);">
              <div style="font-family:'Share Tech Mono',monospace;font-size:0.65rem;color:var(--su-gold-d);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">⬇ Unlocks (modules this opens)</div>
              <div style="display:flex;flex-wrap:wrap;gap:4px;">${postreqHtml}</div>
            </div>
          `;
          document.getElementById('m-modal').classList.add('open');
          triggerGlitch();
        };
      }
      document.getElementById('gmd-cr').textContent=(node.credits||16)+'cr'; document.getElementById('gmd-cr').style.opacity='';
      document.getElementById('gmd-yr').textContent='Y'+node.year; document.getElementById('gmd-yr').style.opacity='';
      // Prereqs and unlocks
      const prereqs=GRAPH_LINKS.filter(l=>(l.target===id||(l.target&&l.target.id===id))).map(l=>l.source?.id||l.source);
      const unlocks=GRAPH_LINKS.filter(l=>(l.source===id||(l.source&&l.source.id===id))).map(l=>l.target?.id||l.target);
      document.getElementById('gmd-prereqs').innerHTML=prereqs.length?prereqs.map(p=>`<span class="gmd-chip" onclick="graphFocusModule('${p}')">${p}</span>`).join(''):'<span style="font-family:\'Share Tech Mono\',monospace;font-size:0.78rem;color:var(--su-gold-d);opacity:0.6;">None</span>';
      document.getElementById('gmd-unlocks').innerHTML=unlocks.length?unlocks.map(u=>`<span class="gmd-chip" onclick="graphFocusModule('${u}')">${u}</span>`).join(''):'<span style="font-family:\'Share Tech Mono\',monospace;font-size:0.78rem;color:var(--su-gold-d);opacity:0.6;">None</span>';
      document.getElementById('gmd-tracks').innerHTML=node.track&&node.track.length?node.track.map(t=>`<span class="gmd-chip">${t}</span>`).join(''):'<span style="font-family:\'Share Tech Mono\',monospace;font-size:0.78rem;color:var(--su-gold-d);opacity:0.6;">General</span>';
      // Highlight node on graph
      const isDark=!document.getElementById('MATIES-root').classList.contains('light-mode');
      const ids=new Set([id,...prereqs,...unlocks]);
      d3.selectAll('.graph-node circle').each(function(d){
        const isMe=d.id===id;
        const isConn=ids.has(d.id)&&!isMe;
        d3.select(this)
          .attr('opacity',isMe?1:isConn?0.75:0.15)
          .attr('stroke',isMe?'#caa258':isConn?'rgba(202,162,88,0.5)':'rgba(202,162,88,0.1)')
          .attr('stroke-width',isMe?4:isConn?2:1)
          .style('filter',isMe?'drop-shadow(0 0 16px #caa258)':isConn?'drop-shadow(0 0 6px rgba(202,162,88,0.4))':'none');
      });
      d3.selectAll('#curr-graph-svg line').each(function(d){
        const src=d.source?.id||d.source;
        const tgt=d.target?.id||d.target;
        const active=(src===id||tgt===id);
        d3.select(this).attr('opacity',active?1:0.04).attr('stroke',active?'#caa258':'rgba(202,162,88,0.08)').attr('stroke-width',active?2.5:1).attr('marker-end',active?'url(#arrow-active)':null);
      });
      // Update sidebar bars to reflect the selected module's year and tracks
      window._selectedGraphModule=node;
      if(typeof window._updateGraphSidebar==='function') window._updateGraphSidebar('_module_',0);
      triggerGlitch();
    };
    // Zoom functions
    let _zoomBehavior=null;
    window._setGraphZoom=function(z){if(_zoomBehavior&&window._graphSvg)window._graphSvg.transition().duration(300).call(_zoomBehavior.scaleBy,z);};
    window.graphZoomIn=function(){window._setGraphZoom(1.35);};
    window.graphZoomOut=function(){window._setGraphZoom(0.75);};
    window.graphZoomReset=function(){if(_zoomBehavior&&window._graphSvg&&window._graphG){const svg=document.getElementById('curr-graph-svg');const W=svg.clientWidth,H=svg.clientHeight;window._graphSvg.transition().duration(400).call(_zoomBehavior.transform,d3.zoomIdentity.translate(W/2,H/2).scale(0.9));}};
    // Store zoom behavior ref after graph init
    setTimeout(()=>{
      const svg=d3.select('#curr-graph-svg');
      const existing=svg.property('__zoom');
      if(existing) _zoomBehavior=window._graphZoomRef;
    },500);
    // If coming from Advisor, apply the advisor highlights after graph is initialised
    if(window._advisorHighlightIds&&window._advisorHighlightIds.length){
      setTimeout(()=>advApplyGraphHighlight(),600);
    }
  },120)},
};

