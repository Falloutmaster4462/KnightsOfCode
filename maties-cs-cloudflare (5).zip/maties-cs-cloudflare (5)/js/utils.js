/* ══════════════════════════════════════════════
   MATIES-OS — Utilities, Helpers & Data Loaders
   ══════════════════════════════════════════════ */
'use strict';
'use strict';

/* Cloudflare Pages - no Drupal JS escape needed */

/* ── UTILS ── */
const R     = document.getElementById('MATIES-root');
const delay = ms => new Promise(r => setTimeout(r, ms));

/* ── GLITCH ── */
const glitch = document.getElementById('m-glitch');

function triggerGlitch(){
  glitch.classList.remove('active','strong-glitch');
  void glitch.offsetWidth;
  glitch.classList.add('active');
  setTimeout(() => glitch.classList.remove('active'), 180);
}

function scheduleGlitch(){
  setTimeout(() => { triggerGlitch(); scheduleGlitch(); }, 1500 + Math.random() * 3500);
}

/* ── CLOCK ── */
function updateClock(){
  const now=new Date(); const days=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const pad=n=>String(n).padStart(2,'0');
  const el=document.getElementById('m-term-clock');
  if(el) el.textContent=`${days[now.getDay()]} ${pad(now.getDate())}/${pad(now.getMonth()+1)}/${now.getFullYear()}  ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}  [SAST]`;
}
updateClock(); setInterval(updateClock,1000);

/* ── THEME ── */
function mToggleTheme(force){
  if(force===true)  R.classList.remove('light-mode');
  else if(force===false) R.classList.add('light-mode');
  else R.classList.toggle('light-mode');
  const isLight=R.classList.contains('light-mode');
  const btn=document.getElementById('m-theme-btn');
  if(btn) btn.textContent=isLight?'🌙':'☀️';
  const tbtn=document.getElementById('m-term-theme-btn');
  if(tbtn) tbtn.textContent=isLight?'🌙 DARK':'☀️ LIGHT';
  try{ const _tv=isLight?'light':'dark'; localStorage.setItem('MATIES-theme',_tv); document.documentElement.setAttribute('data-maties-theme',_tv); }catch(e){}
}
window.mToggleTheme=mToggleTheme;
try{ if(localStorage.getItem('MATIES-theme')==='light') mToggleTheme(false); }catch(e){}

/* ── STAFF DATA ── */
const staffData={
  ProfAvanZyl:{name:'Prof. A. van Zyl',role:'Head of Department · Professor',avatar:'AZ',email:'avanzyl@cs.sun.ac.za',room:'1.24',phone:'+27 21 808 4100',areas:['Algorithms','Complexity Theory','Theoretical CS'],bio:'Professor van Zyl has been with Stellenbosch University since 1999 and has served as Head of Department since 2018. He holds a PhD from MIT and is an IEEE Fellow and NRF A-rated researcher. His research focuses on algorithm design, computational complexity, and combinatorial optimisation.',hIndex:'32',pubs:'89',grants:'NRF Competitive Grant (R2.1M), SARChI Affiliate',teaching:'CS 344 (AI), CS 345 (Theory of Computation)',office:'Mon/Wed 10:00–11:30 by appointment'},
  ProfMDlamini:{name:'Prof. M. Dlamini',role:'Professor · AI Research Lab Director',avatar:'MD',email:'mdlamini@cs.sun.ac.za',room:'2.01',phone:'+27 21 808 4210',areas:['Machine Learning','AI Ethics','Neural Architecture','NLP'],bio:"Prof. Dlamini leads the AI Research Lab and is one of South Africa's most cited ML researchers. She received the NRF A-rating in 2024 — one of only 16 computing researchers in Africa to hold this distinction. She collaborates actively with Google DeepMind Africa and has published in Nature Machine Intelligence, NeurIPS, and ICML.",hIndex:'28',pubs:'74',grants:'DSI R8.5M AI Grant (PI), Google Faculty Award, NRF',teaching:'CS 354 (Machine Learning), CS 448 (Advanced ML)',office:'Tue/Thu 14:00–15:30 or by appointment'},
  ProfRBotha:{name:'Prof. R. Botha',role:'Professor · CCS Director',avatar:'RB',email:'rbotha@cs.sun.ac.za',room:'1.08',phone:'+27 21 808 4120',areas:['Cryptography','Post-Quantum Security','Digital Forensics','Network Security'],bio:'Professor Botha directs the Centre for Cybersecurity (CCS) and is an IEEE Senior Member. He obtained his PhD from TU Delft, Netherlands. His group has published at IEEE S&P, ACM CCS, and USENIX Security.',hIndex:'24',pubs:'61',grants:'NRF, NCPF, CSIR (total R3.2M)',teaching:'CS 347 (Computer Security), CS 450 (Cryptography)',office:'Mon 10:00–12:00, Fri 09:00–11:00'},
  ProfSNaidoo:{name:'Prof. S. Naidoo',role:'Professor · SARChI Chair',avatar:'SN',email:'snaidoo@cs.sun.ac.za',room:'3.15',phone:'+27 21 808 4180',areas:['Bioinformatics','Computational Biology','Genomics'],bio:'Professor Naidoo holds a prestigious SARChI Research Chair in Computational Biology. His group works on genomics and proteomics pipelines specifically designed for Southern African populations. He is a PI in the H3Africa Consortium.',hIndex:'21',pubs:'55',grants:'SARChI Chair (R5M), H3Africa, DSI, NIH supplement',teaching:'CS 449 (Bioinformatics Algorithms)',office:'Wed 09:00–11:00 or email'},
  AssocProfLEngelbrecht:{name:'Assoc. Prof. L. Engelbrecht',role:'Associate Professor · HPC Group Lead',avatar:'LE',email:'lengelbrecht@cs.sun.ac.za',room:'2.12',phone:'+27 21 808 4145',areas:['HPC','Distributed Systems','Cloud Computing'],bio:'Assoc. Prof. Engelbrecht completed his PhD at Stellenbosch and joined the permanent staff in 2015. He serves on the CHPC national advisory committee.',hIndex:'14',pubs:'38',grants:'NRF, CHPC, AWS Research Credits',teaching:'CS 355 (Parallel & Distributed), CS 452 (Cloud Systems)',office:'Mon/Wed/Fri 11:00–12:00'},
  AssocProfTMokoena:{name:'Assoc. Prof. T. Mokoena',role:'Associate Professor · Formal Methods Group Lead',avatar:'TM',email:'tmokoena@cs.sun.ac.za',room:'2.08',phone:'+27 21 808 4148',areas:['Formal Methods','Program Verification','Model Checking'],bio:'Assoc. Prof. Mokoena obtained his PhD from INRIA, France, and has active collaborative links with MPI-SWS Germany. He is an expert in the Isabelle/HOL theorem prover.',hIndex:'12',pubs:'29',grants:'NRF (R1.1M)',teaching:'CS 345 (Theory), CS 451 (Formal Verification)',office:'Tue/Thu 10:00–11:30'},
  DrPHendricks:{name:'Dr. P. Hendricks',role:'Lecturer',avatar:'PH',email:'phendricks@cs.sun.ac.za',room:'1.18',phone:'+27 21 808 4155',areas:['Computer Graphics','VR/AR','Game Development','Rendering'],bio:'Dr. Hendricks specialises in real-time rendering, virtual and augmented reality systems, and game engine architecture. He obtained his PhD from Stellenbosch University with a thesis on physically-based rendering for resource-constrained devices. He coordinates the department\'s Game Development elective and supervises students in the Computer Graphics & Vision Lab. He has industry partnerships with local VR studios and serves as a reviewer for IEEE VR and ACM SIGGRAPH.',hIndex:'6',pubs:'18',grants:'NRF Thuthuka (R620k), Industry: local VR studio partnerships',teaching:'CS 234 (Computer Graphics), CS 453 (Advanced Rendering & Game Dev)',office:'Mon/Wed 13:00–14:30'},
  DrASteenkamp:{name:'Dr. A. Steenkamp',role:'Lecturer',avatar:'AS',email:'asteenkamp@cs.sun.ac.za',room:'1.22',phone:'+27 21 808 4158',areas:['Data Science','Big Data','Database Systems','Data Engineering'],bio:'Dr. Steenkamp completed her PhD at the University of Cape Town, focusing on scalable data pipeline architectures for large-scale analytics. She joined the Stellenbosch CS department in 2021 and teaches core modules in data science and database systems. Her research interests span big data engineering, data quality, and analytics infrastructure. She collaborates with DataFirst at UCT and has published in VLDB workshops and the South African Computer Journal.',hIndex:'5',pubs:'14',grants:'NRF Thuthuka (R580k), DataFirst research partnership',teaching:'CS 243 (Database Systems), CS 343 (Data Science & Engineering)',office:'Tue/Thu 11:00–12:30'},
  DrFOsei:{name:'Dr. F. Osei',role:'Lecturer · SADiLaR Affiliate',avatar:'FO',email:'fosei@cs.sun.ac.za',room:'3.10',phone:'+27 21 808 4162',areas:['Natural Language Processing','Computational Linguistics','Low-Resource NLP','African Languages'],bio:'Dr. Osei holds a PhD from the University of Edinburgh, where his thesis addressed NLP for low-resource African languages. He joined the AI Research Lab as a SADiLaR (South African Centre for Digital Language Resources) affiliate and collaborates closely with Prof. Dlamini on multilingual language model research. His work on isiZulu and Sepedi NLP has been cited by Google Research Africa. He is a co-author on the 2025 Nature Machine Intelligence paper on adaptive neural architectures for African languages.',hIndex:'7',pubs:'21',grants:'SADiLaR Digital Humanities Grant, NRF Thuthuka (R640k)',teaching:'CS 315 (Machine Learning), CS 355 (Natural Language Processing)',office:'Mon/Wed/Fri 10:00–11:00'},
  DrKvanderMerwe:{name:'Dr. K. van der Merwe',role:'Lecturer',avatar:'KM',email:'kvandermerwe@cs.sun.ac.za',room:'B05',phone:'+27 21 808 4168',areas:['Embedded Systems','Internet of Things','Real-Time Systems','Edge Computing'],bio:'Dr. van der Merwe obtained his PhD from KU Leuven, Belgium, where he researched energy-efficient scheduling for embedded real-time systems. He returned to South Africa in 2020 and joined the Stellenbosch department, bringing strong industry ties — he maintains active research partnerships with Bosch Engineering South Africa and Vodacom\'s IoT division. His teaching covers embedded systems design, firmware development, and IoT platform architecture. He supervises the department\'s embedded systems laboratory.',hIndex:'5',pubs:'16',grants:'Bosch Engineering SA research grant, Vodacom IoT Innovation Fund',teaching:'CS 244 (Systems Programming), CS 314 (Embedded & Real-Time Systems)',office:'Tue/Thu 14:00–16:00'},
  DrZPetersen:{name:'Dr. Z. Petersen',role:'Lecturer',avatar:'ZP',email:'zpetersen@cs.sun.ac.za',room:'1.20',phone:'+27 21 808 4172',areas:['Software Engineering','DevOps','Agile Methods','CI/CD','Software Architecture'],bio:'Dr. Petersen completed her PhD at Stellenbosch University on continuous delivery practices in large-scale enterprise software. She has extensive industry experience, having worked as a software architect at Synthesis Software Technologies before returning to academia. Her research examines DevOps adoption in South African software firms, software quality metrics, and agile transformation. She serves on the programme committee of the South African Institute for Computer Scientists and Information Technologists (SAICSIT) conference.',hIndex:'5',pubs:'15',grants:'SAICSIT research grant, industry partnerships: Synthesis Software Technologies',teaching:'CS 323 (Software Engineering), CS 423 (Software Architecture & DevOps)',office:'Mon/Wed 11:00–12:30 or by appointment'},
  DrNSithole:{name:'Dr. N. Sithole',role:'Lecturer',avatar:'NS',email:'nsithole@cs.sun.ac.za',room:'3.08',phone:'+27 21 808 4175',areas:['Computer Vision','Remote Sensing','Image Processing','Deep Learning for Vision'],bio:'Dr. Sithole obtained his PhD from the University of Pretoria, focusing on deep learning approaches for satellite image segmentation and land-cover classification. He joined the Computer Graphics & Vision Lab at Stellenbosch in 2022, where he collaborates with Dr. Hendricks on vision-based applications. His remote sensing research has practical applications in land-use monitoring, precision agriculture, and disaster response, with data partnerships through the South African National Space Agency (SANSA). He has published at IEEE IGARSS and the ISPRS Journal.',hIndex:'6',pubs:'17',grants:'SANSA research partnership, NRF Thuthuka (R600k)',teaching:'CS 234 (Image Processing), CS 354 (Machine Learning), CS 453 (Computer Vision)',office:'Tue/Thu 09:00–10:30'},
};

function openProfileModal(id){
  const d=staffData[id]; if(!d)return;
  document.getElementById('m-modal-content').innerHTML=`
    <div style="display:flex;align-items:center;gap:18px;margin-bottom:20px;flex-wrap:wrap;">
      <div class="m-avatar" style="width:76px;height:76px;font-size:1.8rem;flex-shrink:0;">${d.avatar}</div>
      <div>
        <h2 style="font-family:'Raleway',sans-serif;font-weight:800;color:var(--su-maroon);font-size:1.4rem;">${d.name}</h2>
        <div style="font-family:'Raleway',sans-serif;font-weight:600;font-size:0.7rem;color:var(--su-gold-d);letter-spacing:1px;margin-top:4px;text-transform:uppercase;">${d.role}</div>
        <div style="margin-top:8px;">${d.areas.map(a=>`<span class="m-tag">${a}</span>`).join('')}</div>
      </div>
    </div>
    <p class="m-p" style="font-size:0.97rem;">${d.bio}</p>
    <div class="m-grid3" style="margin:16px 0;">
      <div class="m-stat" style="padding:14px;"><span class="num" style="font-size:2rem;">${d.hIndex}</span><div class="lbl">h-index</div></div>
      <div class="m-stat" style="padding:14px;"><span class="num" style="font-size:2rem;">${d.pubs}</span><div class="lbl">Publications</div></div>
    </div>
    <table class="m-table"><tbody>
      <tr><td style="font-family:'Share Tech Mono',monospace;font-size:0.68rem;color:var(--su-gold-d);width:110px;">EMAIL</td><td><a href="mailto:${d.email}" class="m-link">${d.email}</a></td></tr>
      <tr><td style="font-family:'Share Tech Mono',monospace;font-size:0.68rem;color:var(--su-gold-d);">PHONE</td><td>${d.phone}</td></tr>
      <tr><td style="font-family:'Share Tech Mono',monospace;font-size:0.68rem;color:var(--su-gold-d);">ROOM</td><td>${d.room}</td></tr>
      <tr><td style="font-family:'Share Tech Mono',monospace;font-size:0.68rem;color:var(--su-gold-d);">TEACHING</td><td>${d.teaching}</td></tr>
      <tr><td style="font-family:'Share Tech Mono',monospace;font-size:0.68rem;color:var(--su-gold-d);">GRANTS</td><td style="font-size:0.9rem;">${d.grants}</td></tr>
      <tr><td style="font-family:'Share Tech Mono',monospace;font-size:0.68rem;color:var(--su-gold-d);">OFFICE HRS</td><td>${d.office}</td></tr>
    </tbody></table>`;
  document.getElementById('m-modal').classList.add('open');
}
window.openProfileModal=openProfileModal;

function mCloseModal(e){
  if(!e||e.target===document.getElementById('m-modal'))
    document.getElementById('m-modal').classList.remove('open');
}
window.mCloseModal=mCloseModal;

/* ── HELPERS ── */
function pCard(init,name,role,tags,bio,email,room){
  const safeId=name.replace(/[^a-zA-Z]/g,'');
  return `<div class="m-profile" onclick="openProfileModal('${safeId}')">
    <div class="m-avatar">${init}</div>
    <h3>${name}</h3><div class="role">${role}</div>
    <div>${tags.split('·').map(t=>`<span class="m-tag">${t.trim()}</span>`).join('')}</div>
    <div style="font-family:'Share Tech Mono',monospace;font-size:0.6rem;color:var(--su-gold-d);margin-top:8px;">Room ${room}</div>
  </div>`;
}
function pubCard(title,authors,venue,doi,...tags){
  const doiLink=doi?`<a href="https://doi.org/${doi}" target="_blank">DOI ↗</a>`:'';
  return `<div class="m-pub"><h4>${title}</h4><div class="authors">${authors}</div><div class="venue">${venue}</div>
    <div style="margin-top:10px;display:flex;align-items:center;flex-wrap:wrap;gap:6px;">${tags.filter(Boolean).map(t=>`<span class="m-tag">${t}</span>`).join('')}${doiLink}</div></div>`;
}
function eventCard(day,month,title,speaker,location,time,type,id){
  const cols={Academic:'var(--su-maroon)',Industry:'#1a3a70',Workshop:'#1a6040',Competition:'#7b3d00',Distinguished:'var(--su-wine)',Lecture:'var(--su-maroon)',Postgraduate:'#1a3a70',Social:'#1a6040'};
  const c=cols[type]||'var(--su-maroon)';
  return `<div class="m-event" style="border-left:4px solid ${c}">
    <div class="m-edate" style="background:${c}"><div class="day">${day}</div><div class="mon">${month.toUpperCase()}</div></div>
    <div class="m-ebody"><h4>${title}</h4><p>${speaker}</p>
    <div class="emeta">📍 ${location} &nbsp;|&nbsp; 🕐 ${time} &nbsp;|&nbsp; <span class="m-tag" style="font-size:0.58rem;background:${c};">${type}</span></div>
    </div></div>`;
}
function faq(q,a){
  return `<button class="m-acc-btn">${q}<span class="m-acc-arrow">▶</span></button>
    <div class="m-acc-body"><div class="m-acc-inner">${a}</div></div>`;
}
function modSection(year,title,mods){
  const rows=mods.map(([code,name,sem,cred])=>`<div class="m-mod-row" data-year="${year}"><span class="code">${code}</span><span>${name}</span><span class="sem">${sem}</span><span class="cred">${cred} cr</span></div>`).join('');
  return `<div class="m-acc-item"><button class="m-acc-btn" style="padding:11px 0;font-size:1rem;">${title} <span style="font-family:'Share Tech Mono',monospace;font-size:0.66rem;color:var(--su-gold-d);margin-left:6px;">[${mods.length} modules]</span><span class="m-acc-arrow">▶</span></button>
    <div class="m-acc-body"><div class="m-acc-inner" style="padding:0 0 10px;">
      <div style="display:grid;grid-template-columns:96px 1fr 60px 56px;gap:8px;padding:6px 12px;background:var(--su-maroon);font-family:'Share Tech Mono',monospace;font-size:0.66rem;color:var(--su-white);letter-spacing:1px;"><span>CODE</span><span>MODULE</span><span style="text-align:center;">SEM</span><span style="text-align:right;">CR</span></div>
    ${rows}</div></div></div>`;
}
function initAccordions(el){
  (el||document.getElementById('m-content')).querySelectorAll('.m-acc-btn').forEach(h=>{
    h.onclick=()=>{
      const body=h.nextElementSibling;const arrow=h.querySelector('.m-acc-arrow');
      body.classList.toggle('open');
      if(arrow) arrow.style.transform=body.classList.contains('open')?'rotate(90deg)':'';
    };
  });
}




/* ══════════════════════════════════════════════════════════════════════
   OPTIMISED NEWS & EVENTS FETCHING
   Strategy:
   - Race all proxies in parallel → first valid response wins
   - Per-attempt timeout: 4s (down from 9s)
   - Events: parse all details from the index page (no per-event fetches)
   - Cache TTL: news 10min, events 15min (stale-while-revalidate)
   - sessionStorage for within-session instant loads
   ══════════════════════════════════════════════════════════════════════ */

const SU_NEWS_RSS   = 'https://www.su.ac.za/en/rss.xml?language=en';
const SU_EVENTS_URL = 'https://www.su.ac.za/en/events';

// allorigins /get returns JSON {contents, status} — often faster than /raw
// because it skips re-encoding and hits CDN cache more often
function _proxyUrls(target) {
  const enc = encodeURIComponent(target);
  return [
    `https://api.allorigins.win/get?url=${enc}`,   // JSON wrapper — fastest, CDN-cached
    `https://api.allorigins.win/raw?url=${enc}`,   // raw fallback
    `https://corsproxy.io/?${enc}`,
    `https://api.codetabs.com/v1/proxy?quest=${enc}`,
    target,                                          // direct last (usually blocked by CORS)
  ];
}

async function fetchRace(target, validateFn, timeoutMs = 4000) {
  const urls = _proxyUrls(target);
  return new Promise((resolve, reject) => {
    let settled = false;
    let failures = 0;
    urls.forEach(url => {
      const ctrl = new AbortController();
      const tid  = setTimeout(() => ctrl.abort(), timeoutMs);
      fetch(url, { signal: ctrl.signal, cache: 'no-store' })
        .then(r => { clearTimeout(tid); return r.ok ? r.text() : Promise.reject(new Error(`HTTP ${r.status}`)); })
        .then(txt => {
          clearTimeout(tid);
          if (settled) return;
          // allorigins /get wraps in JSON — unwrap if needed
          let body = txt;
          if (url.includes('/get?url=')) {
            try { body = JSON.parse(txt).contents || txt; } catch(e) {}
          }
          if (!validateFn(body)) throw new Error('Invalid response');
          settled = true;
          resolve(body);
        })
        .catch(() => {
          clearTimeout(tid);
          failures++;
          if (!settled && failures === urls.length) reject(new Error('All proxies failed'));
        });
    });
  });
}

/* ── Silent background prefetch — warms cache before user visits tab ── */
function _prefetchSilent() {
  // News: only prefetch if cache is missing or stale
  try {
    const nc = JSON.parse(localStorage.getItem('su_news_v4') || 'null');
    if (!nc || (Date.now() - nc.ts) > 10 * 60 * 1000) {
      fetchRace(SU_NEWS_RSS, t => isRss(t), 5000)
        .then(xml => {
          const doc   = new DOMParser().parseFromString(xml, 'text/xml');
          if (doc.querySelector('parsererror')) return;
          const items = Array.from(doc.querySelectorAll('item')).slice(0, 12).map(it => ({
            title:   (it.querySelector('title')?.textContent   || '').trim(),
            link:    (it.querySelector('link')?.textContent    || '').trim(),
            pubDate: (it.querySelector('pubDate')?.textContent || '').trim(),
            desc:    stripHtml(it.querySelector('description')?.textContent || ''),
          })).filter(x => x.title && x.link);
          if (items.length) localStorage.setItem('su_news_v4', JSON.stringify({ ts: Date.now(), items }));
        }).catch(() => {});
    }
  } catch(e) {}

  // Events: only prefetch if cache is missing or stale
  try {
    const ec = JSON.parse(localStorage.getItem('su_events_v4') || 'null');
    if (!ec || (Date.now() - ec.ts) > 15 * 60 * 1000) {
      fetchRace(SU_EVENTS_URL, t => isHtml(t), 5000)
        .then(html => {
          const doc   = new DOMParser().parseFromString(html, 'text/html');
          const items = _parseEventsFromDoc(doc);
          if (items.length) localStorage.setItem('su_events_v4', JSON.stringify({ ts: Date.now(), items }));
        }).catch(() => {});
    }
  } catch(e) {}
}
window._prefetchSilent = _prefetchSilent;

/* ── validators ── */
const isRss  = t => { const s = String(t).slice(0, 3000).toLowerCase(); return s.includes('<rss') || s.includes('<feed') || s.includes('<item') || s.includes('<channel'); };
const isHtml = t => { const s = String(t).slice(0, 2000).toLowerCase(); return s.includes('<html') || s.includes('<!doctype') || s.includes('<body') || s.includes('<div'); };

/* ── tiny helpers ── */
function stripHtml(html) {
  const d = document.createElement('div');
  d.innerHTML = html || '';
  return (d.textContent || '').replace(/\s+/g, ' ').trim();
}
function fmtDate(d) {
  try {
    const dt = new Date(d);
    if (isNaN(dt)) return '';
    return dt.toLocaleDateString(undefined, { year:'numeric', month:'short', day:'2-digit' });
  } catch(e) { return ''; }
}

/* ══ NEWS ══════════════════════════════════════════════════════════════ */

const NEWS_CACHE_KEY = 'su_news_v4';
const NEWS_FRESH_MS  = 10 * 60 * 1000;   // 10 min — show from cache instantly
const NEWS_STALE_MS  = 4  * 60 * 60 * 1000; // 4 hr  — background revalidate

function _newsCache(write) {
  try {
    if (write) { localStorage.setItem(NEWS_CACHE_KEY, JSON.stringify(write)); return; }
    return JSON.parse(localStorage.getItem(NEWS_CACHE_KEY) || 'null');
  } catch(e) { return null; }
}

async function loadSUNews(opts = {}) {
  const list    = document.getElementById('m-news-list');
  const meta    = document.getElementById('m-news-meta');
  const err     = document.getElementById('m-news-error');
  const btn     = document.getElementById('m-news-refresh');
  if (!list || !meta) return;

  if (btn && !btn.dataset.bound) {
    btn.dataset.bound = '1';
    btn.addEventListener('click', () => loadSUNews({ force: true }));
  }

  const now    = Date.now();
  const cached = opts.force ? null : _newsCache();
  const age    = cached ? (now - cached.ts) : Infinity;
  const fresh  = age < NEWS_FRESH_MS;

  // ── instant render from cache ──
  if (cached && cached.items?.length) {
    renderSUNews(cached.items, cached.ts, !fresh);
    if (fresh) return; // still hot — skip network
  } else {
    meta.textContent = 'Loading latest news…';
  }

  // ── background / foreground fetch ──
  try {
    const xml  = await fetchRace(SU_NEWS_RSS, isRss, 4000);
    const doc  = new DOMParser().parseFromString(xml, 'text/xml');
    if (doc.querySelector('parsererror')) throw new Error('Parse error');

    const items = Array.from(doc.querySelectorAll('item')).slice(0, 12).map(it => ({
      title:   (it.querySelector('title')?.textContent || '').trim(),
      link:    (it.querySelector('link')?.textContent  || '').trim(),
      pubDate: (it.querySelector('pubDate')?.textContent || '').trim(),
      desc:    stripHtml(it.querySelector('description')?.textContent || ''),
    })).filter(x => x.title && x.link);

    if (!items.length) throw new Error('No items');
    _newsCache({ ts: now, items });
    renderSUNews(items, now, false);

  } catch(e) {
    if (!cached) {
      if (err) { err.style.display = 'block'; err.textContent = 'Could not load live news. Please try again shortly.'; }
      meta.textContent = 'News unavailable';
    } else if (err) {
      err.style.display = 'block';
      err.textContent = 'Live refresh failed — showing cached news.';
    }
  }
}

function renderSUNews(items, ts, isStale) {
  const list       = document.getElementById('m-news-list');
  const featured   = document.getElementById('m-news-featured');
  const meta       = document.getElementById('m-news-meta');
  const countEl    = document.getElementById('m-news-count');
  const freshEl    = document.getElementById('m-news-freshness');
  const sectionLbl = document.getElementById('m-news-section-label');
  if (!list || !meta) return;

  meta.textContent = `Updated ${new Date(ts).toLocaleString()} · Source: Stellenbosch University RSS${isStale ? ' (cached)' : ''}`;
  if (countEl) countEl.textContent = `${items.length} Articles`;
  if (freshEl) freshEl.textContent = isStale ? 'Cached' : 'Live';

  if (featured && items.length) {
    const n = items[0];
    const d = fmtDate(n.pubDate);
    const blurb = (n.desc || '').slice(0, 400) + ((n.desc || '').length > 400 ? '…' : '');
    featured.innerHTML = `<a href="${n.link}" target="_blank" rel="noopener" style="text-decoration:none;color:inherit;display:block;border:1px solid var(--page-border);border-top:4px solid var(--su-maroon);padding:40px 48px;transition:border-color 0.2s;" onmouseover="this.style.borderColor='var(--su-maroon)'" onmouseout="this.style.borderTop='4px solid var(--su-maroon)';this.style.borderColor='var(--page-border)'">
      <div style="font-family:'Share Tech Mono',monospace;font-size:0.62rem;color:var(--su-gold-d);letter-spacing:2px;text-transform:uppercase;margin-bottom:16px;">Featured · ${d || 'Latest'}</div>
      <div style="font-family:'Playfair Display',serif;font-size:clamp(1.5rem,3vw,2.4rem);font-weight:700;line-height:1.25;color:var(--page-h);margin-bottom:20px;max-width:800px;">${n.title}</div>
      <p style="font-family:'Raleway',sans-serif;font-size:1rem;color:var(--page-text2);line-height:1.8;max-width:680px;margin:0 0 24px;">${blurb}</p>
      <span style="font-family:'Share Tech Mono',monospace;font-size:0.68rem;letter-spacing:1.5px;color:var(--su-gold);text-transform:uppercase;">Read Full Story →</span>
    </a>`;
  }

  if (sectionLbl && items.length > 1) sectionLbl.style.display = '';
  list.innerHTML = items.slice(1).map(n => {
    const d     = fmtDate(n.pubDate);
    const blurb = (n.desc || '').slice(0, 160) + ((n.desc || '').length > 160 ? '…' : '');
    return `<a href="${n.link}" target="_blank" rel="noopener" class="pg-spotlight-card" style="text-decoration:none;color:inherit;display:block;">
      <div style="font-family:'Share Tech Mono',monospace;font-size:0.58rem;color:var(--su-gold-d);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:10px;">${d || 'News'}</div>
      <div class="pg-spotlight-title" style="font-size:0.95rem;">${n.title}</div>
      <p class="pg-spotlight-body" style="font-size:0.84rem;">${blurb}</p>
      <div class="pg-spotlight-meta" style="margin-top:auto;"><span style="color:var(--su-gold);font-size:0.75rem;">Read →</span></div>
    </a>`;
  }).join('');
}

window.loadSUNews = loadSUNews;

/* ══ EVENTS ════════════════════════════════════════════════════════════ */

const EVENTS_CACHE_KEY = 'su_events_v4';
const EVENTS_FRESH_MS  = 30 * 60 * 1000;      // 30 min fresh window
const EVENTS_STALE_MS  = 12 * 60 * 60 * 1000; // 12 hr stale window

function _eventsCache(write) {
  try {
    if (write) { localStorage.setItem(EVENTS_CACHE_KEY, JSON.stringify(write)); return; }
    return JSON.parse(localStorage.getItem(EVENTS_CACHE_KEY) || 'null');
  } catch(e) { return null; }
}

function _parseEventsFromDoc(doc) {
  const items = [];
  const seen  = new Set();
  const containers = doc.querySelectorAll('.event-item, .views-row, article, [class*="event"], li.item');

  const addFromLink = (a, container) => {
    if (items.length >= 10) return;
    const href = a.getAttribute('href') || '';
    if (!href || !href.includes('/events/') || href.includes('calendar.google') || href.includes('outlook')) return;
    const abs = href.startsWith('http') ? href : new URL(href, SU_EVENTS_URL).toString();
    if (!abs.includes('su.ac.za') || seen.has(abs)) return;
    seen.add(abs);
    const title = (a.textContent || '').trim();
    if (title.length < 6) return;
    const ctx   = (container || a.closest('li, article, div') || a).textContent || '';
    const dateM = ctx.match(/(\d{1,2}\s+\w+\s+\d{4})/);
    const timeM = ctx.match(/(\d{1,2}:\d{2}\s*(?:AM|PM)?)\s*[-–]\s*(\d{1,2}:\d{2}\s*(?:AM|PM)?)/i);
    const type  = ctx.match(/\b(Workshop|Seminar|Lecture|Colloquium|Conference|Webinar|Exhibition|Concert|Ceremony|Competition|Symposium|Forum|Award|Social|Postgraduate|Distinguished)\b/i);
    items.push({ title, link: abs, dateLine: dateM ? dateM[1] : '', time: timeM ? `${timeM[1]}–${timeM[2]}` : '', location: '', venue: '', type: type ? type[1] : 'Event' });
  };

  if (containers.length) containers.forEach(c => { const a = c.querySelector('a'); if (a) addFromLink(a, c); });
  if (items.length < 3)  doc.querySelectorAll('a[href*="/events/"]').forEach(a => addFromLink(a, null));
  return items;
}

function parseEventDateRange(dateLine) {
  if (!dateLine) return null;
  const parts = dateLine.split(/\s*[-–]\s*/);
  const parsePart = s => {
    const m = s.match(/(\d{1,2}\s+[A-Za-z]+\s+\d{4})\s*(\d{1,2}:\d{2})?/);
    if (!m) return null;
    const dt = new Date((m[1] + (m[2] ? ' ' + m[2] : '')).trim());
    return isNaN(dt) ? null : dt;
  };
  return { start: parsePart(parts[0]), end: parts[1] ? parsePart(parts[1]) : null };
}

const SKELETON_EVENT = `
  <div style="display:grid;grid-template-columns:80px 1fr;border-bottom:1px solid var(--page-border);border-top:1px solid var(--page-border);margin-top:-1px;">
    <div style="padding:32px 0;display:flex;flex-direction:column;align-items:center;gap:8px;border-right:1px solid var(--page-border);">
      <div style="width:40px;height:40px;background:var(--page-border);border-radius:2px;animation:skeletonPulse 1.4s ease infinite;"></div>
      <div style="width:28px;height:10px;background:var(--page-border);border-radius:2px;animation:skeletonPulse 1.4s ease 0.2s infinite;"></div>
    </div>
    <div style="padding:28px 32px;display:flex;flex-direction:column;gap:12px;">
      <div style="width:80px;height:18px;background:var(--page-border);border-radius:2px;animation:skeletonPulse 1.4s ease infinite;"></div>
      <div style="width:65%;height:22px;background:var(--page-border);border-radius:2px;animation:skeletonPulse 1.4s ease 0.1s infinite;"></div>
      <div style="width:45%;height:14px;background:var(--page-border);border-radius:2px;animation:skeletonPulse 1.4s ease 0.2s infinite;"></div>
    </div>
  </div>`;

async function loadSUEvents(opts = {}) {
  const list = document.getElementById('m-events-list');
  const meta = document.getElementById('m-events-meta');
  const err  = document.getElementById('m-events-error');
  const btn  = document.getElementById('m-events-refresh');
  if (!list || !meta) return;

  if (btn && !btn.dataset.bound) {
    btn.dataset.bound = '1';
    btn.addEventListener('click', () => loadSUEvents({ force: true }));
  }

  const now    = Date.now();
  const cached = opts.force ? null : _eventsCache();
  const age    = cached ? (now - cached.ts) : Infinity;
  const fresh  = age < EVENTS_FRESH_MS;

  // ── instant render from cache — no waiting ──
  if (cached && cached.items?.length) {
    renderSUEvents(cached.items, cached.ts, !fresh);
    if (!fresh && !opts.force) _bgRevalidateEvents(); // stale: silently refresh in bg
    return;
  }

  // ── no cache: show skeleton immediately, then fetch ──
  list.innerHTML = SKELETON_EVENT.repeat(4);
  meta.textContent = 'Loading upcoming events…';
  if (err) { err.style.display = 'none'; }

  try {
    const html  = await fetchRace(SU_EVENTS_URL, isHtml, 4500);
    const doc   = new DOMParser().parseFromString(html, 'text/html');
    const items = _parseEventsFromDoc(doc);
    if (!items.length) throw new Error('No events parsed');
    items.sort((a, b) => {
      const da = parseEventDateRange(a.dateLine)?.start?.getTime() || Infinity;
      const db = parseEventDateRange(b.dateLine)?.start?.getTime() || Infinity;
      return da - db;
    });
    _eventsCache({ ts: now, items });
    renderSUEvents(items, now, false);
  } catch(e) {
    list.innerHTML = '';
    if (err) { err.style.display = 'block'; err.textContent = 'Could not load live events. Please try again shortly.'; }
    meta.textContent = 'Events unavailable';
  }
}

async function _bgRevalidateEvents() {
  try {
    const html  = await fetchRace(SU_EVENTS_URL, isHtml, 5000);
    const doc   = new DOMParser().parseFromString(html, 'text/html');
    const items = _parseEventsFromDoc(doc);
    if (!items.length) return;
    items.sort((a, b) => {
      const da = parseEventDateRange(a.dateLine)?.start?.getTime() || Infinity;
      const db = parseEventDateRange(b.dateLine)?.start?.getTime() || Infinity;
      return da - db;
    });
    const ts = Date.now();
    _eventsCache({ ts, items });
    if (document.getElementById('m-events-list')) renderSUEvents(items, ts, false);
  } catch(e) {}
}


function renderSUEvents(items, ts, isStale) {
  const list    = document.getElementById('m-events-list');
  const meta    = document.getElementById('m-events-meta');
  const countEl = document.getElementById('m-events-count');
  const freshEl = document.getElementById('m-events-freshness');
  if (!list || !meta) return;

  meta.textContent = `Updated ${new Date(ts).toLocaleString()} · Source: Stellenbosch University${isStale ? ' (cached)' : ''}`;
  if (countEl) countEl.textContent = `${items.length} Events`;
  if (freshEl) freshEl.textContent = isStale ? 'Cached' : 'Live';

  if (!items.length) {
    list.innerHTML = `<div style="font-family:'Raleway',sans-serif;font-size:0.9rem;color:var(--page-text2);padding:40px 0;border-top:1px solid var(--page-border);">No upcoming events found. Visit the <a href="https://www.su.ac.za/en/events" target="_blank" style="color:var(--su-gold);">SU Events page ↗</a>.</div>`;
    return;
  }

  const cols = { Academic:'var(--su-maroon)', Industry:'#1a3a70', Workshop:'#1a6040', Competition:'#7b3d00', Distinguished:'var(--su-wine)', Lecture:'var(--su-maroon)', Postgraduate:'#1a3a70', Social:'#1a6040', Seminar:'var(--su-maroon)', Colloquium:'#1a3a70', Conference:'#1a6040', Webinar:'#7b3d00' };

  list.innerHTML = items.map((ev, i) => {
    const dr      = parseEventDateRange(ev.dateLine);
    const day     = dr?.start ? String(dr.start.getDate()).padStart(2,'0') : '--';
    const mon     = dr?.start ? dr.start.toLocaleDateString(undefined, { month:'short' }).toUpperCase() : '';
    const weekday = dr?.start ? dr.start.toLocaleDateString(undefined, { weekday:'long' }) : '';
    const fullDate= dr?.start ? dr.start.toLocaleDateString(undefined, { day:'numeric', month:'long', year:'numeric' }) : (ev.dateLine || 'Date TBC');
    const time    = ev.time || (dr?.start ? `${dr.start.toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' })}${dr?.end ? '–' + dr.end.toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }) : ''}` : 'See details');
    const where   = (ev.venue || ev.location || 'Stellenbosch University').trim();
    const tag     = (ev.type || 'Event').trim();
    const c       = cols[tag] || 'var(--su-maroon)';

    return `<div style="display:grid;grid-template-columns:80px 1fr;border-bottom:1px solid var(--page-border);${i===0?'border-top:1px solid var(--page-border);':''}transition:background 0.15s;" onmouseover="this.style.background='rgba(97,34,59,0.04)'" onmouseout="this.style.background=''">
      <div style="padding:28px 0;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding-top:32px;border-right:1px solid var(--page-border);">
        <div style="font-family:'Playfair Display',serif;font-size:2rem;font-weight:700;color:${c};line-height:1;">${day}</div>
        <div style="font-family:'Share Tech Mono',monospace;font-size:0.58rem;color:var(--su-gold-d);letter-spacing:2px;margin-top:2px;">${mon}</div>
      </div>
      <div style="padding:28px 32px;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap;">
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.6rem;padding:2px 8px;background:${c};color:#fff;letter-spacing:1px;text-transform:uppercase;">${tag}</span>
          <span style="font-family:'Share Tech Mono',monospace;font-size:0.62rem;color:var(--su-gold-d);">${weekday}${weekday && fullDate ? ', ' : ''}${fullDate}</span>
        </div>
        <div style="font-family:'Playfair Display',serif;font-size:1.2rem;font-weight:600;color:var(--page-h);line-height:1.35;margin-bottom:12px;">${ev.title || 'Event'}</div>
        <div style="font-family:'Share Tech Mono',monospace;font-size:0.65rem;color:var(--page-text2);display:flex;gap:20px;flex-wrap:wrap;">
          <span>📍 ${where}</span>
          <span>🕐 ${time}</span>
        </div>
        <a href="${ev.link}" target="_blank" rel="noopener" style="display:inline-block;margin-top:16px;font-family:'Share Tech Mono',monospace;font-size:0.62rem;letter-spacing:1.5px;color:var(--su-gold);text-decoration:none;text-transform:uppercase;">More Info →</a>
      </div>
    </div>`;
  }).join('');
}

window.loadSUEvents = loadSUEvents;


/* ── OPENALEX FETCH ── */
async function fetchPubs(url,containerId,limit=5,showCit=false){
  const c=document.getElementById(containerId);if(!c)return;
  try{
    const ctrl=new AbortController();const tid=setTimeout(()=>ctrl.abort(),12000);
    const resp=await fetch(url,{headers:{'Accept':'application/json'},signal:ctrl.signal});
    clearTimeout(tid);
    if(!resp.ok)throw new Error(`HTTP ${resp.status}`);
    const data=await resp.json();const works=(data.results||[]).slice(0,limit);
    if(!works.length){c.innerHTML=`<div class="m-api-err">No publications found matching current filters.</div>`;return;}
    c.innerHTML=works.map(w=>{
      const title=w.title||'Untitled';const year=w.publication_year||'';
      const authors=(w.authorships||[]).slice(0,4).map(a=>a.author?.display_name||'').filter(Boolean).join(', ')+((w.authorships||[]).length>4?', et al.':'');
      const venue=w.primary_location?.source?.display_name||'Unknown Venue';
      const doi=w.doi?w.doi.replace('https://doi.org/',''):null;
      const doiLink=doi?`<a href="https://doi.org/${doi}" target="_blank" style="margin-left:7px;">DOI ↗</a>`:'';
      const cit=showCit&&w.cited_by_count!=null?`<span class="m-tag gold">${w.cited_by_count} citations</span>`:'';
      const topic=w.primary_topic?.display_name?`<span class="m-tag">${w.primary_topic.display_name}</span>`:'';
      return `<div class="m-pub"><h4>${title}</h4><div class="authors">${authors||'Unknown authors'}</div><div class="venue">${venue} (${year})</div>
        <div style="margin-top:10px;display:flex;align-items:center;flex-wrap:wrap;gap:6px;">${topic}${cit}${doiLink}</div></div>`;
    }).join('');
  }catch(e){
    c.innerHTML=`<div class="m-api-err">⚠ OpenAlex API unreachable (${e.name==='AbortError'?'timeout':e.message}). Showing curated highlights.</div>`+
      [pubCard('Adaptive Neural Architectures for Low-Resource African Languages','Dlamini M., Osei F.','Nature Machine Intelligence, 2025','10.1038/s42256-025-00821-x','NLP','ML'),
       pubCard('Post-Quantum Cryptographic Primitives for Constrained IoT Devices','Botha R., van der Merwe K.','IEEE S&P 2024',null,'Cryptography','IoT'),
       pubCard('HPC-Optimised Genomic Assembly Pipelines','Naidoo S., Engelbrecht L., et al.','Bioinformatics (OUP), 2024',null,'Bioinformatics','HPC')].join('');
  }
}
const ALEX_BASE='https://api.openalex.org/works?filter=authorships.institutions.id:I26092322,title.search:machine+learning|deep+learning|neural+network|artificial+intelligence|cybersecurity|cryptography|computer+vision|natural+language+processing|bioinformatics|algorithm|distributed+computing|formal+verification|software+engineering|high+performance+computing|data+science|reinforcement+learning|computer+science';

/* ══════════════════════════════════════════════════
   PAGES
   ══════════════════════════════════════════════════ */
